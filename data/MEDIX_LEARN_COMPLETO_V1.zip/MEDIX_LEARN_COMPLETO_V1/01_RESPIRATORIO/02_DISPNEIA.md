# Trilha Respiratório — Dispneia

## Papel dentro do MEDIX Learn
A dispneia é a síndrome respiratória mais transversal. Ela conecta hipoxemia, ventilação, obstrução, infecção, TEP, pneumotórax e causas cardíacas/metabólicas.

## Objetivo pedagógico
Ensinar o aluno a caracterizar falta de ar, reconhecer gravidade e organizar diagnósticos diferenciais.

## Competências ao final
- Diferenciar dispneia aguda e crônica.
- Reconhecer sinais de gravidade.
- Separar causas respiratórias, cardíacas, metabólicas e psicogênicas.
- Perguntar início, progressão, gatilhos, posição, dor, tosse, febre e fatores de risco.
- Priorizar hipóteses perigosas.

## Sequência didática padrão
1. **Microaula** — conceito central em linguagem simples.
2. **Fisiologia aplicada** — mecanismo que explica o sinal/sintoma.
3. **Semiologia** — como o mecanismo aparece no paciente.
4. **Raciocínio clínico** — como diferenciar causas próximas.
5. **Mini-casos** — aplicação curta, com pergunta e feedback.
6. **Questões ativas** — perguntas que obrigam o aluno a pensar.
7. **Erros comuns** — atalhos mentais perigosos.
8. **Mapa final** — síntese visual/textual.
9. **Ponte para OSCE** — para onde o aluno vai treinar depois.

## Blocos obrigatórios da trilha
- Definição de dispneia.
- Dispneia aguda vs crônica.
- Dispneia respiratória vs cardíaca vs metabólica.
- Fala entrecortada, ortopneia, DPN, tiragem e uso de musculatura acessória.
- Red flags: instabilidade, hipoxemia, alteração de consciência, dor torácica, início súbito.

## Mini-casos sugeridos
- Asma grave: dispneia com sibilos.
- Pneumonia: dispneia com febre/tosse.
- TEP: dispneia súbita com dor pleurítica.
- IC: dispneia com ortopneia/edema.
- Pneumotórax: dispneia súbita com assimetria auscultatória.

## Questões ativas-base
1. Dispneia súbita com ausculta normal exclui doença grave?
2. O que diferencia ortopneia de dispneia aos esforços?
3. Quais sinais indicam que a dispneia é grave mesmo com SpO₂ pouco alterada?

## Erros comuns a corrigir
- Chamar toda dispneia de ansiedade.
- Ignorar início súbito.
- Não perguntar ortopneia/DPN.
- Não medir FR.
- Valorizar só SpO₂ e esquecer esforço respiratório.

## Ponte para OSCE
OSCE Ciclo Básico: anamnese de dispneia e exame físico. OSCE Clínico: evolução da dispneia com intervenções e reavaliação.
