# Matriz Completa — MEDIX Learn

## Módulos

1. Respiratório
2. Cardiovascular
3. Infectologia
4. Neurologia
5. Gastro/Abdome
6. Semiologia Geral
7. Raciocínio Clínico

## Regra de ouro

O MEDIX Learn não deve ser um repositório de resumos. Cada trilha deve ensinar o aluno a passar de:

```text
conceito → mecanismo → achado clínico → hipótese → decisão → OSCE
```

## Ordem sugerida de implementação

1. Respiratório / Hipoxemia
2. Respiratório / Dispneia
3. Respiratório / Exame físico respiratório
4. Respiratório / Sibilância e broncoespasmo
5. Semiologia Geral / Sinais vitais e gravidade
6. Raciocínio Clínico / Síndromes antes de diagnósticos
7. Cardiovascular / Dor torácica
8. Infectologia / Febre e síndrome infecciosa
9. Neurologia / AVC e déficit focal
10. Gastro/Abdome / Dor abdominal
