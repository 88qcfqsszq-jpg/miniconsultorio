import { FonteExamesLaboratoriais } from "@/types/caso-osce-v2";

export const LABS_BASE_NORMAL: FonteExamesLaboratoriais = {
  hemograma: {
    interpretacao: "Hemograma sem alterações relevantes.",
    dados: {
      hemacias: "4,80 mi/mm³",
      hemoglobina: "14,2 g/dL",
      hematocrito: "42,0%",
      vcm: "87,5 fL",
      hcm: "29,5 pg",
      chcm: "33,8 g/dL",
      rdw: "13,0%",
      leucocitos: "7.200/mm³",
      neutrofilos: "58%",
      bastonetes: "2%",
      segmentados: "56%",
      linfocitos: "30%",
      monocitos: "8%",
      eosinofilos: "3%",
      basofilos: "1%",
      plaquetas: "250.000/mm³",
      vpm: "9,0 fL",
      plaquetocrito: "0,22%",
      pdw: "12,0%",
    },
  },
  funcao_renal: {
    interpretacao: "Função renal preservada.",
    dados: { ureia: "32 mg/dL", creatinina: "0,9 mg/dL", etfg: "> 90 mL/min/1,73m²" },
  },
  eletrolitos: {
    interpretacao: "Eletrólitos sem alterações relevantes.",
    dados: { sodio: "139 mEq/L", potassio: "4,2 mEq/L", cloro: "102 mEq/L", magnesio: "2,0 mg/dL", calcio: "9,2 mg/dL" },
  },
  marcadores_inflamatorios: {
    interpretacao: "Marcadores inflamatórios sem elevação relevante.",
    dados: { pcr: "0,4 mg/dL", vhs: "12 mm/h", procalcitonina: "0,05 ng/mL" },
  },
  gasometria: {
    interpretacao: "Gasometria sem distúrbios ácido-base relevantes.",
    dados: { ph: "7,40", paco2: "40 mmHg", pao2: "92 mmHg", hco3: "24 mEq/L", satO2: "97%", lactato: "1,2 mmol/L", be: "0" },
  },
  marcadores_cardiacos: {
    interpretacao: "Marcadores cardíacos sem evidência de necrose miocárdica.",
    dados: { troponina: "<0,04 ng/mL", ckmb: "2,0 ng/mL", bnp: "48 pg/mL" },
  },
  funcao_hepatica: {
    interpretacao: "Função hepática sem alterações relevantes.",
    dados: { tgo: "24 U/L", tgp: "28 U/L", fa: "88 U/L", ggt: "34 U/L", bilirrubina_total: "0,8 mg/dL", bilirrubina_direta: "0,2 mg/dL", albumina: "4,1 g/dL" },
  },
  coagulograma: {
    interpretacao: "Coagulograma sem alterações relevantes.",
    dados: { tp: "12,4 s", inr: "1,0", ttpa: "31 s", fibrinogenio: "320 mg/dL", d_dimero: "<500 ng/mL" },
  },
  urina_tipo_1: {
    interpretacao: "Urina tipo 1 sem alterações relevantes.",
    dados: { densidade: "1,020", ph: "6,0", proteina: "Ausente", glicose: "Ausente", cetonas: "Ausentes", sangue_hemoglobina: "Ausente", nitrito: "Negativo", esterase_leucocitaria: "Negativa", leucocitos: "< 5 p/campo", hemacias: "< 3 p/campo", bacterias: "Raras", cilindros: "Ausentes" },
  },
};

export const LABS_OVERRIDES_BY_ID: Record<string, FonteExamesLaboratoriais> = {
  "1": {
    hemograma: { interpretacao: "Hemograma sem anemia ou plaquetopenia, com discreta leucocitose de estresse.", dados: { hemoglobina: "14,3 g/dL", hematocrito: "42,1%", leucocitos: "11.800/mm³", neutrofilos: "72%", plaquetas: "252.000/mm³" } },
    marcadores_cardiacos: { interpretacao: "Marcadores compatíveis com necrose miocárdica aguda.", dados: { troponina: "2,8 ng/mL", ckmb: "32 ng/mL", bnp: "96 pg/mL" } },
    coagulograma: { interpretacao: "Coagulograma basal sem contraindicação laboratorial evidente para estratégia antitrombótica.", dados: { tp: "12,4 s", inr: "1,0", ttpa: "31 s", d_dimero: "620 ng/mL" } }
  },
  "2": {
    hemograma: { interpretacao: "Leucocitose com neutrofilia, compatível com infecção bacteriana.", dados: { hemoglobina: "13,8 g/dL", leucocitos: "14.000/mm³", neutrofilos: "87%", bastonetes: "7%", linfocitos: "8%", plaquetas: "280.000/mm³" } },
    marcadores_inflamatorios: { interpretacao: "Marcadores inflamatórios elevados.", dados: { pcr: "16,0 mg/dL", vhs: "48 mm/h", procalcitonina: "0,9 ng/mL" } },
    gasometria: { interpretacao: "Hipoxemia leve por acometimento pulmonar.", dados: { ph: "7,44", paco2: "36 mmHg", pao2: "68 mmHg", hco3: "24 mEq/L", satO2: "93%", lactato: "1,4 mmol/L" } }
  },
  "3": {
    hemograma: { interpretacao: "Hemograma sem infecção bacteriana, com discreta eosinofilia.", dados: { leucocitos: "8.600/mm³", neutrofilos: "55%", linfocitos: "29%", eosinofilos: "6%", plaquetas: "260.000/mm³" } },
    gasometria: { interpretacao: "Alteração ventilatória compatível com crise asmática.", dados: { ph: "7,47", paco2: "31 mmHg", pao2: "72 mmHg", hco3: "22 mEq/L", satO2: "94%", lactato: "1,3 mmol/L" } }
  },
  "4": {
    marcadores_cardiacos: { interpretacao: "Marcadores cardíacos sem evidência de necrose miocárdica.", dados: { troponina: "<0,04 ng/mL", ckmb: "2,1 ng/mL", bnp: "62 pg/mL" } }
  },
  "5": {
    funcao_renal: { interpretacao: "Função renal preservada, sem lesão renal aguda.", dados: { ureia: "34 mg/dL", creatinina: "1,0 mg/dL", etfg: "88 mL/min/1,73m²" } },
    urina_tipo_1: { interpretacao: "Urina tipo 1 sem proteinúria significativa.", dados: { proteina: "Traços", hemacias: "< 3 p/campo", leucocitos: "< 5 p/campo", nitrito: "Negativo" } }
  },
  "6": {
    hemograma: { interpretacao: "Leucograma discretamente alterado, compatível com pneumonia atípica.", dados: { leucocitos: "10.200/mm³", neutrofilos: "68%", linfocitos: "20%", monocitos: "9%", plaquetas: "290.000/mm³" } },
    marcadores_inflamatorios: { interpretacao: "Inflamação moderada.", dados: { pcr: "7,8 mg/dL", vhs: "36 mm/h", procalcitonina: "0,18 ng/mL" } }
  },
  "7": {
    marcadores_inflamatorios: { interpretacao: "Inflamação sistêmica presente, compatível com pericardite aguda.", dados: { pcr: "9,5 mg/dL", vhs: "42 mm/h", procalcitonina: "0,10 ng/mL" } },
    marcadores_cardiacos: { interpretacao: "Troponina sem elevação importante.", dados: { troponina: "0,05 ng/mL", ckmb: "3,0 ng/mL", bnp: "58 pg/mL" } }
  },
  "8": {
    marcadores_cardiacos: { interpretacao: "BNP elevado, compatível com sobrecarga cardíaca.", dados: { troponina: "0,04 ng/mL", ckmb: "2,5 ng/mL", bnp: "980 pg/mL" } },
    funcao_renal: { interpretacao: "Função renal a ser acompanhada em contexto cardiovascular.", dados: { ureia: "46 mg/dL", creatinina: "1,2 mg/dL", etfg: "68 mL/min/1,73m²" } }
  },
  "9": {
    hemograma: { interpretacao: "Poliglobulia discreta e leucocitose leve, compatíveis com DPOC.", dados: { hemacias: "5,60 mi/mm³", hemoglobina: "16,8 g/dL", hematocrito: "50,5%", leucocitos: "11.200/mm³", plaquetas: "260.000/mm³" } },
    gasometria: { interpretacao: "Retenção de CO2 com hipoxemia.", dados: { ph: "7,33", paco2: "58 mmHg", pao2: "60 mmHg", hco3: "29 mEq/L", satO2: "89%", lactato: "1,5 mmol/L" } }
  },
  "10": {
    gasometria: { interpretacao: "Hipoxemia com alcalose respiratória, compatível com TEP.", dados: { ph: "7,48", paco2: "30 mmHg", pao2: "64 mmHg", hco3: "22 mEq/L", satO2: "91%", lactato: "2,1 mmol/L" } },
    coagulograma: { interpretacao: "D-dímero elevado.", dados: { tp: "12,8 s", inr: "1,0", ttpa: "30 s", fibrinogenio: "380 mg/dL", d_dimero: "> 4.000 ng/mL" } }
  },
  "11": {
    hemograma: { interpretacao: "Anemia discreta de doença crônica com inflamação persistente.", dados: { hemoglobina: "11,6 g/dL", hematocrito: "35,0%", leucocitos: "9.400/mm³", monocitos: "11%", plaquetas: "420.000/mm³" } },
    marcadores_inflamatorios: { interpretacao: "Marcadores inflamatórios persistentemente elevados.", dados: { pcr: "8,4 mg/dL", vhs: "72 mm/h", procalcitonina: "0,12 ng/mL" } }
  },
  "12": {
    hemograma: { interpretacao: "Leucopenia e plaquetopenia leves, compatíveis com dengue sem sinais de alarme.", dados: { leucocitos: "3.200/mm³", neutrofilos: "42%", linfocitos: "46%", plaquetas: "128.000/mm³", hematocrito: "44,8%" } },
    funcao_hepatica: { interpretacao: "Transaminases discretamente elevadas.", dados: { tgo: "68 U/L", tgp: "52 U/L", bilirrubina_total: "0,9 mg/dL", bilirrubina_direta: "0,2 mg/dL", albumina: "4,0 g/dL" } }
  },
  "13": {
    hemograma: { interpretacao: "Leucocitose com anemia inflamatória discreta.", dados: { hemoglobina: "10,8 g/dL", hematocrito: "33,2%", leucocitos: "15.600/mm³", neutrofilos: "84%", bastonetes: "6%", plaquetas: "410.000/mm³" } },
    marcadores_inflamatorios: { interpretacao: "Inflamação/infecção sistêmica importante.", dados: { pcr: "19,0 mg/dL", vhs: "88 mm/h", procalcitonina: "1,3 ng/mL" } },
    urina_tipo_1: { interpretacao: "Micro-hematúria discreta.", dados: { sangue_hemoglobina: "+", hemacias: "8-10 p/campo", proteina: "Traços", nitrito: "Negativo" } }
  },
  "14": {
    marcadores_cardiacos: { interpretacao: "BNP elevado, compatível com sobrecarga cardíaca.", dados: { troponina: "0,04 ng/mL", ckmb: "2,5 ng/mL", bnp: "980 pg/mL" } },
    funcao_renal: { interpretacao: "Função renal a ser acompanhada em contexto cardiovascular.", dados: { ureia: "46 mg/dL", creatinina: "1,2 mg/dL", etfg: "68 mL/min/1,73m²" } }
  },
  "15": {
    hemograma: { interpretacao: "Hemograma sem alterações relevantes para o quadro vascular estável.", dados: { hemoglobina: "14,0 g/dL", leucocitos: "7.600/mm³", plaquetas: "260.000/mm³" } },
    coagulograma: { interpretacao: "Sem alteração de coagulação basal relevante.", dados: { tp: "12,4 s", inr: "1,0", ttpa: "31 s", fibrinogenio: "330 mg/dL", d_dimero: "540 ng/mL" } }
  },
  "16": {
    hemograma: { interpretacao: "Hemograma sem infecção bacteriana exuberante; correlacionar com etiologia do derrame.", dados: { hemoglobina: "13,4 g/dL", leucocitos: "9.800/mm³", neutrofilos: "66%", plaquetas: "310.000/mm³" } },
    marcadores_inflamatorios: { interpretacao: "Marcadores inflamatórios discretamente elevados.", dados: { pcr: "3,2 mg/dL", vhs: "28 mm/h", procalcitonina: "0,08 ng/mL" } }
  },
  "17": {
    hemograma: { interpretacao: "Anemia microcítica e hipocrômica, compatível com anemia ferropriva.", dados: { hemacias: "3,70 mi/mm³", hemoglobina: "8,7 g/dL", hematocrito: "29,0%", vcm: "68,0 fL", hcm: "22,0 pg", chcm: "31,0 g/dL", rdw: "19,0%", plaquetas: "440.000/mm³" } }
  },
  "18": {
    hemograma: { interpretacao: "Hemograma sem anemia ou plaquetopenia, com discreta leucocitose de estresse.", dados: { hemoglobina: "14,3 g/dL", hematocrito: "42,1%", leucocitos: "11.800/mm³", neutrofilos: "72%", plaquetas: "252.000/mm³" } },
    marcadores_cardiacos: { interpretacao: "Troponina elevada sem supra de ST, compatível com IAM sem supra.", dados: { troponina: "1,4 ng/mL", ckmb: "18 ng/mL", bnp: "110 pg/mL" } },
    coagulograma: { interpretacao: "Coagulograma basal sem contraindicação laboratorial evidente para estratégia antitrombótica.", dados: { tp: "12,4 s", inr: "1,0", ttpa: "31 s", d_dimero: "620 ng/mL" } }
  },
  "19": {
    marcadores_cardiacos: { interpretacao: "Marcadores cardíacos sem evidência de necrose miocárdica.", dados: { troponina: "<0,04 ng/mL", ckmb: "2,1 ng/mL", bnp: "62 pg/mL" } }
  },
  "20": {
    hemograma: { interpretacao: "Hemograma sem anemia ou plaquetopenia, com discreta leucocitose de estresse.", dados: { hemoglobina: "14,3 g/dL", hematocrito: "42,1%", leucocitos: "11.800/mm³", neutrofilos: "72%", plaquetas: "252.000/mm³" } },
    marcadores_cardiacos: { interpretacao: "Marcadores compatíveis com necrose miocárdica aguda.", dados: { troponina: "2,8 ng/mL", ckmb: "32 ng/mL", bnp: "96 pg/mL" } },
    coagulograma: { interpretacao: "Coagulograma basal sem contraindicação laboratorial evidente para estratégia antitrombótica.", dados: { tp: "12,4 s", inr: "1,0", ttpa: "31 s", d_dimero: "620 ng/mL" } }
  },
  "21": {
    eletrolitos: { interpretacao: "Eletrólitos sem distúrbio grave, magnésio discretamente baixo.", dados: { sodio: "139 mEq/L", potassio: "3,8 mEq/L", magnesio: "1,7 mg/dL", calcio: "9,1 mg/dL" } },
    marcadores_cardiacos: { interpretacao: "Sem necrose miocárdica aguda.", dados: { troponina: "<0,04 ng/mL", ckmb: "2,0 ng/mL", bnp: "150 pg/mL" } }
  },
  "22": {
    funcao_renal: { interpretacao: "Creatinina discretamente elevada, sugerindo repercussão hipertensiva.", dados: { ureia: "48 mg/dL", creatinina: "1,4 mg/dL", etfg: "55 mL/min/1,73m²" } },
    urina_tipo_1: { interpretacao: "Proteinúria discreta em contexto hipertensivo.", dados: { proteina: "+", hemacias: "3-5 p/campo", leucocitos: "< 5 p/campo", nitrito: "Negativo" } }
  },
  "23": {
    marcadores_cardiacos: { interpretacao: "BNP elevado, compatível com sobrecarga cardíaca.", dados: { troponina: "0,04 ng/mL", ckmb: "2,5 ng/mL", bnp: "980 pg/mL" } },
    funcao_renal: { interpretacao: "Função renal a ser acompanhada em contexto cardiovascular.", dados: { ureia: "46 mg/dL", creatinina: "1,2 mg/dL", etfg: "68 mL/min/1,73m²" } }
  },
  "24": {
    marcadores_cardiacos: { interpretacao: "BNP elevado, compatível com sobrecarga cardíaca.", dados: { troponina: "0,04 ng/mL", ckmb: "2,5 ng/mL", bnp: "980 pg/mL" } },
    funcao_renal: { interpretacao: "Função renal a ser acompanhada em contexto cardiovascular.", dados: { ureia: "46 mg/dL", creatinina: "1,2 mg/dL", etfg: "68 mL/min/1,73m²" } }
  },
  "25": {
    marcadores_cardiacos: { interpretacao: "BNP elevado, compatível com sobrecarga cardíaca.", dados: { troponina: "0,04 ng/mL", ckmb: "2,5 ng/mL", bnp: "980 pg/mL" } },
    funcao_renal: { interpretacao: "Função renal a ser acompanhada em contexto cardiovascular.", dados: { ureia: "46 mg/dL", creatinina: "1,2 mg/dL", etfg: "68 mL/min/1,73m²" } }
  },
  "26": {
    marcadores_cardiacos: { interpretacao: "BNP elevado, compatível com sobrecarga cardíaca.", dados: { troponina: "0,04 ng/mL", ckmb: "2,5 ng/mL", bnp: "980 pg/mL" } },
    funcao_renal: { interpretacao: "Função renal a ser acompanhada em contexto cardiovascular.", dados: { ureia: "46 mg/dL", creatinina: "1,2 mg/dL", etfg: "68 mL/min/1,73m²" } }
  },
  "27": {
    hemograma: { interpretacao: "Hemograma sem alterações críticas; interpretar conforme contexto clínico do caso.", dados: { hemoglobina: "13,8 g/dL", hematocrito: "41,0%", leucocitos: "7.600/mm³", neutrofilos: "60%", linfocitos: "30%", plaquetas: "260.000/mm³" } }
  },
  "28": {
    hemograma: { interpretacao: "Hemograma sem alterações relevantes para o quadro vascular estável.", dados: { hemoglobina: "14,0 g/dL", leucocitos: "7.600/mm³", plaquetas: "260.000/mm³" } },
    coagulograma: { interpretacao: "Sem alteração de coagulação basal relevante.", dados: { tp: "12,4 s", inr: "1,0", ttpa: "31 s", fibrinogenio: "330 mg/dL", d_dimero: "540 ng/mL" } }
  },
  "29": {
    coagulograma: { interpretacao: "D-dímero elevado, compatível com trombose venosa no contexto clínico.", dados: { tp: "12,8 s", inr: "1,0", ttpa: "30 s", fibrinogenio: "410 mg/dL", d_dimero: "> 3.500 ng/mL" } },
    hemograma: { interpretacao: "Hemograma sem anemia ou plaquetopenia.", dados: { hemoglobina: "13,6 g/dL", leucocitos: "9.200/mm³", plaquetas: "280.000/mm³" } }
  },
  "30": {
    hemograma: { interpretacao: "Hemograma sem alterações relevantes para o quadro vascular estável.", dados: { hemoglobina: "14,0 g/dL", leucocitos: "7.600/mm³", plaquetas: "260.000/mm³" } },
    coagulograma: { interpretacao: "Sem alteração de coagulação basal relevante.", dados: { tp: "12,4 s", inr: "1,0", ttpa: "31 s", fibrinogenio: "330 mg/dL", d_dimero: "540 ng/mL" } }
  },
  "31": {
    hemograma: { interpretacao: "Hemograma sem infecção bacteriana, com discreta eosinofilia.", dados: { leucocitos: "8.600/mm³", neutrofilos: "55%", linfocitos: "29%", eosinofilos: "6%", plaquetas: "260.000/mm³" } },
    gasometria: { interpretacao: "Alteração ventilatória compatível com crise asmática.", dados: { ph: "7,47", paco2: "31 mmHg", pao2: "72 mmHg", hco3: "22 mEq/L", satO2: "94%", lactato: "1,3 mmol/L" } }
  },
  "32": {
    hemograma: { interpretacao: "Hemograma sem infecção bacteriana, com discreta eosinofilia.", dados: { leucocitos: "8.600/mm³", neutrofilos: "55%", linfocitos: "29%", eosinofilos: "6%", plaquetas: "260.000/mm³" } },
    gasometria: { interpretacao: "Alteração ventilatória compatível com crise asmática.", dados: { ph: "7,31", paco2: "50 mmHg", pao2: "58 mmHg", hco3: "22 mEq/L", satO2: "88%", lactato: "1,3 mmol/L" } }
  },
  "33": {
    hemograma: { interpretacao: "Poliglobulia discreta e leucocitose leve, compatíveis com DPOC.", dados: { hemacias: "5,60 mi/mm³", hemoglobina: "16,8 g/dL", hematocrito: "50,5%", leucocitos: "11.200/mm³", plaquetas: "260.000/mm³" } },
    gasometria: { interpretacao: "Retenção de CO2 com hipoxemia.", dados: { ph: "7,33", paco2: "58 mmHg", pao2: "60 mmHg", hco3: "29 mEq/L", satO2: "89%", lactato: "1,5 mmol/L" } }
  },
  "34": {
    hemograma: { interpretacao: "Poliglobulia discreta e leucocitose leve, compatíveis com DPOC.", dados: { hemacias: "5,60 mi/mm³", hemoglobina: "16,8 g/dL", hematocrito: "50,5%", leucocitos: "11.200/mm³", plaquetas: "260.000/mm³" } },
    gasometria: { interpretacao: "Retenção de CO2 com hipoxemia.", dados: { ph: "7,33", paco2: "58 mmHg", pao2: "60 mmHg", hco3: "29 mEq/L", satO2: "89%", lactato: "1,5 mmol/L" } }
  },
  "38": {
    hemograma: { interpretacao: "Leucopenia e plaquetopenia leves, compatíveis com dengue sem sinais de alarme.", dados: { leucocitos: "3.200/mm³", neutrofilos: "42%", linfocitos: "46%", plaquetas: "128.000/mm³", hematocrito: "44,8%" } },
    funcao_hepatica: { interpretacao: "Transaminases discretamente elevadas.", dados: { tgo: "68 U/L", tgp: "52 U/L", bilirrubina_total: "0,9 mg/dL", bilirrubina_direta: "0,2 mg/dL", albumina: "4,0 g/dL" } }
  },
  "39": {
    hemograma: { interpretacao: "Hemoconcentração e plaquetopenia importantes, compatíveis com dengue com sinais de alarme.", dados: { leucocitos: "2.900/mm³", linfocitos: "52%", plaquetas: "62.000/mm³", hematocrito: "49,5%" } },
    funcao_hepatica: { interpretacao: "Transaminases moderadamente elevadas.", dados: { tgo: "126 U/L", tgp: "98 U/L", bilirrubina_total: "1,1 mg/dL", albumina: "3,6 g/dL" } },
    coagulograma: { interpretacao: "Coagulograma com alteração discreta e D-dímero elevado.", dados: { tp: "13,8 s", inr: "1,1", ttpa: "36 s", fibrinogenio: "260 mg/dL", d_dimero: "1.240 ng/mL" } }
  },
  "40": {
    hemograma: { interpretacao: "Leucopenia e plaquetopenia associadas a quadro viral sistêmico.", dados: { leucocitos: "2.600/mm³", neutrofilos: "38%", linfocitos: "50%", plaquetas: "74.000/mm³", hematocrito: "43,0%" } },
    funcao_hepatica: { interpretacao: "Lesão hepatocelular importante compatível com febre amarela.", dados: { tgo: "980 U/L", tgp: "740 U/L", bilirrubina_total: "5,2 mg/dL", bilirrubina_direta: "3,8 mg/dL", albumina: "3,2 g/dL" } },
    coagulograma: { interpretacao: "Coagulopatia por acometimento hepático.", dados: { tp: "20,2 s", inr: "1,8", ttpa: "46 s", fibrinogenio: "170 mg/dL", d_dimero: "2.800 ng/mL" } }
  },
  "41": {
    hemograma: { interpretacao: "Hemograma sem alteração bacteriana relevante.", dados: { hemoglobina: "13,6 g/dL", leucocitos: "5.200/mm³", linfocitos: "42%", plaquetas: "210.000/mm³" } },
    marcadores_inflamatorios: { interpretacao: "Inflamação discreta.", dados: { pcr: "1,2 mg/dL", vhs: "22 mm/h", procalcitonina: "0,04 ng/mL" } }
  },
  "42": {
    hemograma: { interpretacao: "Leucopenia leve e plaquetas preservadas, compatível com arbovirose.", dados: { leucocitos: "3.800/mm³", linfocitos: "45%", plaquetas: "165.000/mm³", hematocrito: "41,5%" } },
    marcadores_inflamatorios: { interpretacao: "Inflamação sistêmica associada à artralgia.", dados: { pcr: "5,6 mg/dL", vhs: "44 mm/h", procalcitonina: "0,06 ng/mL" } }
  },
  "43": {
    hemograma: { interpretacao: "Anemia microcítica e hipocrômica, compatível com anemia ferropriva.", dados: { hemacias: "3,70 mi/mm³", hemoglobina: "8,7 g/dL", hematocrito: "29,0%", vcm: "68,0 fL", hcm: "22,0 pg", chcm: "31,0 g/dL", rdw: "19,0%", plaquetas: "440.000/mm³" } }
  },
  "44": {
    hemograma: { interpretacao: "Anemia hemolítica, com anemia normocítica e padrão regenerativo.", dados: { hemacias: "2,90 mi/mm³", hemoglobina: "8,1 g/dL", hematocrito: "25,8%", vcm: "89,0 fL", rdw: "18,4%", leucocitos: "11.300/mm³", plaquetas: "278.000/mm³" } },
    funcao_hepatica: { interpretacao: "Aumento de bilirrubina indireta em contexto hemolítico.", dados: { tgo: "42 U/L", tgp: "30 U/L", bilirrubina_total: "3,2 mg/dL", bilirrubina_direta: "0,4 mg/dL", albumina: "4,2 g/dL" } },
    urina_tipo_1: { interpretacao: "Urina escurecida com hemoglobina positiva.", dados: { sangue_hemoglobina: "++", hemacias: "0-2 p/campo", urobilinogenio: "Aumentado", proteina: "Ausente" } }
  },
  "45": {
    hemograma: { interpretacao: "Plaquetopenia isolada importante, compatível com PTI.", dados: { hemoglobina: "13,2 g/dL", leucocitos: "6.500/mm³", plaquetas: "18.000/mm³", vpm: "12,5 fL" } },
    coagulograma: { interpretacao: "Coagulograma normal, favorecendo alteração plaquetária primária.", dados: { tp: "12,0 s", inr: "1,0", ttpa: "30 s", fibrinogenio: "310 mg/dL" } }
  },
  "46": {
    hemograma: { interpretacao: "Anemia macrocítica, compatível com deficiência de vitamina B12.", dados: { hemoglobina: "8,9 g/dL", hematocrito: "27,0%", vcm: "116 fL", hcm: "36 pg", rdw: "18,0%", leucocitos: "3.600/mm³", plaquetas: "130.000/mm³" } }
  },
  "47": {
    hemograma: { interpretacao: "Eritrocitose importante, compatível com policitemia vera.", dados: { hemacias: "6,80 mi/mm³", hemoglobina: "19,2 g/dL", hematocrito: "58,5%", leucocitos: "13.000/mm³", plaquetas: "520.000/mm³" } }
  },
  "48": {
    hemograma: { interpretacao: "Anemia normocítica associada a doença hematológica.", dados: { hemoglobina: "9,4 g/dL", hematocrito: "29,0%", leucocitos: "5.900/mm³", plaquetas: "160.000/mm³" } },
    funcao_renal: { interpretacao: "Disfunção renal associada ao mieloma.", dados: { ureia: "76 mg/dL", creatinina: "2,4 mg/dL", etfg: "30 mL/min/1,73m²" } },
    eletrolitos: { interpretacao: "Hipercalcemia associada a doença óssea.", dados: { sodio: "138 mEq/L", potassio: "4,5 mEq/L", calcio: "12,2 mg/dL", magnesio: "2,1 mg/dL" } }
  },
  "49": {
    hemograma: { interpretacao: "Citopenias com leucocitose importante, compatível com leucemia aguda.", dados: { hemacias: "2,80 mi/mm³", hemoglobina: "7,9 g/dL", hematocrito: "24,5%", leucocitos: "32.000/mm³", plaquetas: "48.000/mm³" } }
  },
  "50": {
    hemograma: { interpretacao: "Plaquetopenia associada a consumo sistêmico.", dados: { hemoglobina: "9,8 g/dL", leucocitos: "18.000/mm³", plaquetas: "38.000/mm³" } },
    coagulograma: { interpretacao: "Coagulopatia de consumo compatível com CIVD.", dados: { tp: "18,6 s", inr: "1,6", ttpa: "48 s", fibrinogenio: "110 mg/dL", d_dimero: "> 5.000 ng/mL" } }
  },
  "51": {
    coagulograma: { interpretacao: "TTPA prolongado isolado, compatível com hemofilia A.", dados: { tp: "12,5 s", inr: "1,0", ttpa: "78 s", fibrinogenio: "310 mg/dL", d_dimero: "<500 ng/mL" } },
    hemograma: { interpretacao: "Hemograma sem plaquetopenia.", dados: { hemoglobina: "12,8 g/dL", leucocitos: "7.200/mm³", plaquetas: "260.000/mm³" } }
  },
  "52": {
    coagulograma: { interpretacao: "Alargamento de TP/INR por deficiência de vitamina K.", dados: { tp: "24,0 s", inr: "2,2", ttpa: "42 s", fibrinogenio: "300 mg/dL", d_dimero: "<500 ng/mL" } }
  },
  "53": {
    hemograma: { interpretacao: "Anemia grave microcítica com anisopoquilocitose, compatível com talassemia maior.", dados: { hemacias: "3,10 mi/mm³", hemoglobina: "6,8 g/dL", hematocrito: "22,6%", vcm: "61,0 fL", hcm: "21,5 pg", rdw: "22,0%", plaquetas: "360.000/mm³" } }
  },
  "54": {
    funcao_renal: { interpretacao: "Função renal discretamente reduzida em paciente diabético.", dados: { ureia: "48 mg/dL", creatinina: "1,4 mg/dL", etfg: "56 mL/min/1,73m²" } },
    urina_tipo_1: { interpretacao: "Glicosúria e proteinúria discreta.", dados: { glicose: "++", proteina: "+", cetonas: "Ausentes", hemacias: "< 3 p/campo", leucocitos: "< 5 p/campo" } }
  },
  "55": {
    hemograma: { interpretacao: "Anemia de doença crônica em contexto renal.", dados: { hemoglobina: "9,8 g/dL", hematocrito: "30,1%", leucocitos: "6.800/mm³", plaquetas: "230.000/mm³" } },
    funcao_renal: { interpretacao: "Disfunção renal crônica estágio avançado.", dados: { ureia: "88 mg/dL", creatinina: "3,1 mg/dL", etfg: "22 mL/min/1,73m²" } },
    eletrolitos: { interpretacao: "Distúrbios compatíveis com doença renal crônica.", dados: { sodio: "137 mEq/L", potassio: "5,4 mEq/L", calcio: "8,2 mg/dL", magnesio: "2,4 mg/dL" } }
  },
  "56": {
    hemograma: { interpretacao: "Citopenias leves compatíveis com atividade inflamatória autoimune.", dados: { hemoglobina: "10,6 g/dL", leucocitos: "3.800/mm³", plaquetas: "132.000/mm³" } },
    marcadores_inflamatorios: { interpretacao: "Inflamação ativa.", dados: { pcr: "2,8 mg/dL", vhs: "54 mm/h", procalcitonina: "0,05 ng/mL" } },
    urina_tipo_1: { interpretacao: "Proteinúria e hematúria compatíveis com nefrite lúpica.", dados: { proteina: "++", sangue_hemoglobina: "+", hemacias: "15-20 p/campo", cilindros: "Cilindros hemáticos presentes" } }
  },
  "57": {
    hemograma: { interpretacao: "Linfopenia importante em imunossupressão.", dados: { hemoglobina: "10,9 g/dL", leucocitos: "3.100/mm³", linfocitos: "12%", plaquetas: "180.000/mm³" } },
    gasometria: { interpretacao: "Hipoxemia compatível com pneumocistose.", dados: { ph: "7,45", paco2: "32 mmHg", pao2: "58 mmHg", hco3: "22 mEq/L", satO2: "89%", lactato: "1,6 mmol/L" } }
  },
  "58": {
    hemograma: { interpretacao: "Hemograma sem anemia ou plaquetopenia, com discreta leucocitose de estresse.", dados: { hemoglobina: "14,3 g/dL", hematocrito: "42,1%", leucocitos: "11.800/mm³", neutrofilos: "72%", plaquetas: "252.000/mm³" } },
    marcadores_cardiacos: { interpretacao: "Marcadores compatíveis com necrose miocárdica aguda.", dados: { troponina: "2,8 ng/mL", ckmb: "32 ng/mL", bnp: "96 pg/mL" } },
    coagulograma: { interpretacao: "Coagulograma basal sem contraindicação laboratorial evidente para estratégia antitrombótica.", dados: { tp: "12,4 s", inr: "1,0", ttpa: "31 s", d_dimero: "620 ng/mL" } }
  },
  "59": {
    hemograma: { interpretacao: "Leucocitose neutrofílica importante.", dados: { leucocitos: "21.800/mm³", neutrofilos: "90%", bastonetes: "10%", linfocitos: "4%", plaquetas: "118.000/mm³" } },
    marcadores_inflamatorios: { interpretacao: "Marcadores inflamatórios muito elevados.", dados: { pcr: "28,0 mg/dL", vhs: "76 mm/h", procalcitonina: "12,0 ng/mL" } },
    gasometria: { interpretacao: "Acidose metabólica láctica compatível com choque séptico.", dados: { ph: "7,28", paco2: "30 mmHg", pao2: "78 mmHg", hco3: "14 mEq/L", satO2: "94%", lactato: "4,8 mmol/L" } },
    urina_tipo_1: { interpretacao: "Urina compatível com infecção do trato urinário.", dados: { nitrito: "Positivo", esterase_leucocitaria: "++", leucocitos: "> 50 p/campo", bacterias: "Numerosas", proteina: "+" } }
  },
  "60": {
    gasometria: { interpretacao: "Acidose metabólica com aumento de ânion gap, compatível com cetoacidose.", dados: { ph: "7,18", paco2: "22 mmHg", pao2: "96 mmHg", hco3: "9 mEq/L", satO2: "97%", lactato: "2,2 mmol/L" } },
    eletrolitos: { interpretacao: "Distúrbio hidroeletrolítico da cetoacidose diabética.", dados: { sodio: "130 mEq/L", potassio: "5,6 mEq/L", cloro: "96 mEq/L", magnesio: "1,8 mg/dL", calcio: "8,8 mg/dL" } },
    funcao_renal: { interpretacao: "Azotemia pré-renal por desidratação.", dados: { ureia: "54 mg/dL", creatinina: "1,6 mg/dL", etfg: "52 mL/min/1,73m²" } },
    urina_tipo_1: { interpretacao: "Glicosúria e cetonúria intensas.", dados: { glicose: "+++", cetonas: "+++", proteina: "+", sangue_hemoglobina: "Ausente", nitrito: "Negativo" } }
  },
  "61": {
    marcadores_cardiacos: { interpretacao: "BNP elevado, compatível com sobrecarga cardíaca.", dados: { troponina: "0,04 ng/mL", ckmb: "2,5 ng/mL", bnp: "980 pg/mL" } },
    funcao_renal: { interpretacao: "Função renal a ser acompanhada em contexto cardiovascular.", dados: { ureia: "46 mg/dL", creatinina: "1,2 mg/dL", etfg: "68 mL/min/1,73m²" } }
  },
  "62": {
    gasometria: { interpretacao: "Hipoxemia leve associada ao pneumotórax.", dados: { ph: "7,43", paco2: "34 mmHg", pao2: "70 mmHg", hco3: "23 mEq/L", satO2: "93%", lactato: "1,6 mmol/L" } }
  },
  "63": {
    gasometria: { interpretacao: "Hipoxemia leve por atelectasia.", dados: { ph: "7,42", paco2: "37 mmHg", pao2: "66 mmHg", hco3: "24 mEq/L", satO2: "92%", lactato: "1,3 mmol/L" } }
  },
  "64": {
    hemograma: { interpretacao: "Hemograma com padrão viral inespecífico.", dados: { hemoglobina: "11,2 g/dL", leucocitos: "9.600/mm³", linfocitos: "52%", neutrofilos: "38%", plaquetas: "310.000/mm³" } },
    gasometria: { interpretacao: "Hipoxemia leve em lactente com bronquiolite.", dados: { ph: "7,39", paco2: "42 mmHg", pao2: "68 mmHg", hco3: "24 mEq/L", satO2: "94%", lactato: "1,2 mmol/L" } }
  }
};

export function buildFonteExamesLaboratoriais(caseId: string): FonteExamesLaboratoriais {
  return {
    ...LABS_BASE_NORMAL,
    ...(LABS_OVERRIDES_BY_ID[caseId] ?? {}),
  };
}
