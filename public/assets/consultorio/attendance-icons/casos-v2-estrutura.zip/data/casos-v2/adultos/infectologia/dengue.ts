import { CasoOSCEV2 } from "@/types/caso-osce-v2";

export const casoDengue: CasoOSCEV2 = {} as CasoOSCEV2;
