# MEDIX Learn — Raciocínio Clínico

## Objetivo
Ensinar o aluno a pensar clinicamente: problema, síndrome, hipótese, gravidade, prioridade, conduta e reavaliação.

## Trilhas
1. Sintoma, sinal, síndrome e diagnóstico
2. Diagnóstico diferencial
3. Gravidade e red flags
4. Priorização: o que fazer primeiro
5. Interpretação de exames básicos
6. Erros cognitivos em medicina
7. Raciocínio de conduta e reavaliação
