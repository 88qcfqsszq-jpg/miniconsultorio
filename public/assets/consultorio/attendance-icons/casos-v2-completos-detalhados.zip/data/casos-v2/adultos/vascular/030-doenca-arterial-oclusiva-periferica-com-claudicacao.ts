import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso030DoencaArterialOclusivaPerifericaCom: CasoOSCEV2 = {
// ====== CASO 30: DOENÇA ARTERIAL OCLUSIVA PERIFÉRICA ======
id: "30",
titulo: "Doença Arterial Oclusiva Periférica com Claudicação",
sistema: "Vascular",
tema: "Vasculopatia Periférica",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Diagnosticar DAOP e calcular risco cardiovascular",
dados_visiveis_ao_estudante: {
nome_paciente: "Otávio Gomes",
idade: 68,
sexo: "Masculino",
queixa_principal: "Dor nas pernas ao caminhar",
historia_breve: "Cansaço nas pernas após caminhar uma quadra, melhora com repouso",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "DAOP com Claudicação Intermitente",
diagnosticos_diferenciais: ["Bursite", "Trombose venosa", "Claudicação neurógena"],
sindromes_associadas: ["Aterosclerose generalizada"],
},
descricaoBreve: "Paciente com pulsos periféricos diminuídos, sopro femoral, claudicação reproduzível",
categoria: "Vascular",
paciente: {
id: "pac-030",
nome: "Otávio Gomes",
idade: 68,
sexo: "M",
queixaPrincipal: "Dor ao caminhar",
historicoDoenca: "Limitação funcional há 1 ano",
antecedentes: ["Tabagismo", "HAS", "Diabetes"],
profissao: "Aposentado",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: ["Losartana"],
},
respostas_do_paciente: {
inicial: "Quando caminho, minhas pernas doem",
dor: "Dor nas panturrilhas",
distancia: "Consigo caminhar uns 100 metros",
melhora: "Passa com repouso",
inicio: "Começou há 1 ano",
pés_frios: "Sim, meus pés ficam frios",
},
respostaPaciente: {
inicial: "Dor ao caminhar",
dor: "Panturrilhas",
distancia: "100 metros",
melhora: "Com repouso",
inicio: "1 ano",
pés_frios: "Sim",
},
sinais_vitais: {
corretos: {
pressaoArterial: "160/95 mmHg",
frequenciaCardiaca: 78,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 97,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "160/95 mmHg",
frequenciaCardiaca: 78,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 97,
},
exame_fisico: {
correto: {
inspecao: "Palidez em pés elevados, rubor em pé pendente",
palpacao: "Pulsos femorais diminuídos, ausência de pulso tibial",
ausculta: "Sopro femoral bilateral",
percussao: "Normal",
observacoes: "Temperatura reduzida em extremidades",
regiao: "Membros inferiores",
achados_positivos: ["Pulsos diminuídos", "Sopro"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Palidez em pés elevados",
palpacao: "Pulsos diminuídos",
ausculta: "Sopro vascular",
percussao: "Normal",
observacoes: "Sinais de DAOP",
},
exame_fisico_interativo: {
membros: {
pulsos: "Pulso femoral presente, poplíteo ausente",
perfusao: "Reduzida",
temperatura: "Pés frios",
mobilidade: "Normal",
},
},
exames_complementares_disponiveis: [
{
nome: "Índice Tornozelo-Braquial",
descricao: "Relação pressão tornozelo/braço",
resultado: "0.45",
valor_referencia: ">0.9",
interpretacao: "DAOP moderada a grave",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "DAOP com Claudicação",
probabilidade: 95,
criterios_minimos: [
"Claudicação reproduzível",
"Pulsos diminuídos",
"ABI baixo",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Claudicação neurógena",
criterios_exclusao: ["ABI anormal"],
achados_que_descartam: ["Pulsos normais"],
},
],
examesIndicados: [
"Índice tornozelo-braquial",
"Ultrassom duplex arterial",
],
conduta_esperada: {
imediata: [
"Modificação de fatores de risco",
"Aspirina",
],
curto_prazo: [
"Reabilitação vascular",
"Possível angioplastia",
],
longo_prazo: [
"Acompanhamento angiológico",
"Controle de risco CV",
],
encaminhamentos: ["Angiologia"],
},
condutaCorreta: "ABI, ultrassom duplex, aspirina, modificação de fatores de risco, possível revascularização",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["ABI <0.4", "Claudicação incapacitante"],
descricao: "Risco de perda de membro",
recomendacao: "Considerar revascularização",
},
],
erros_criticos: [
{
erro: "Não investigar risco CV",
descricao: "DAOP indica aterosclerose",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Perguntou sobre claudicação",
realizado: false,
critico: true,
},
{
item: "Palpou pulsos",
realizado: false,
critico: true,
},
{
item: "Solicitou ABI",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de DAOP",
peso: 25,
descricao: "Achados clínicos",
pontuacao_maxima: 25,
},
{
criterio: "Avaliação de risco",
peso: 20,
descricao: "Investigação CV",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Claudicação a distância definida",
"Melhora com repouso",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Pulsos diminuídos",
"ABI reduzido",
"Sopro",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["DAOP"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Aspirina",
"Modificação de fatores",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu DAOP",
"Solicitou ABI",
"Avaliou risco CV",
],
erros_comuns: ["Achar que é muscular"],
orientacoes_pedagogicas: [
"Claudicação: dor ao caminhar que melhora com repouso",
"DAOP é marker de aterosclerose",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar DAOP e avaliar risco CV",
comunicacao: ["explicou relação com tabagismo"],
anamnese: ["investigou distância de claudicação"],
exame_fisico: ["palpou pulsos"],
exames_complementares: ["pediu ABI"],
raciocinio: ["diagnosticou DAOP"],
conduta: ["prescreveu aspirina"],
soap: ["documentou DAOP"],
},
temaOSCE: "Vasculopatia Periférica",
subtopicosOSCE: [
"DAOP",
"Claudicação intermitente",
"ABI baixo",
"Aterosclerose",
],
diagnosticoCorreto: "Doença Arterial Oclusiva Periférica com Claudicação",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("30"),
} as CasoOSCEV2;
