import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso019AnginaInstavel: CasoOSCEV2 = {
// ====== CASO 19: ANGINA INSTÁVEL ======
id: "19",
titulo: "Angina Instável",
sistema: "Cardiovascular",
tema: "Síndrome Coronariana Aguda",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 11,
objetivo_pedagogico: "Diagnosticar angina instável e reconhecer risco de progressão para infarto",
dados_visiveis_ao_estudante: {
nome_paciente: "Fernanda Oliveira",
idade: 62,
sexo: "Feminino",
queixa_principal: "Dor no peito em repouso",
historia_breve: "Dor torácica típica que começou durante a madrugada, paciente nunca teve antes",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Angina Instável",
diagnosticos_diferenciais: ["NSTEMI", "Pericardite", "Embolia Pulmonar"],
sindromes_associadas: ["Síndrome Coronariana Aguda"],
},
descricaoBreve: "Paciente com dor torácica em repouso, ECG com alterações dinâmicas, troponina negativa (ao menos inicialmente)",
categoria: "SCA",
paciente: {
id: "pac-019",
nome: "Fernanda Oliveira",
idade: 62,
sexo: "F",
queixaPrincipal: "Dor no peito em repouso",
historicoDoenca: "Acordou com dor durante madrugada, paciente com histórico de sopro",
antecedentes: ["HAS", "Histórico familiar de infarto"],
profissao: "Enfermeira",
estado_civil: "Viúva",
alergias: ["Penicilina"],
medicamentos_em_uso: ["Losartana 50mg"],
},
respostas_do_paciente: {
inicial: "Acordei com uma dor muito ruim no peito durante a madrugada",
dor: "Dor de aperto no meio do peito, às vezes irradia pro braço esquerdo",
intensidade: "7, muito incômodo, não consigo relaxar",
inicio: "Começou de repente durante o sono",
suor: "Sim, acordei toda suada",
respiracao: "Sim, falta de ar",
repouso: "Melhorou um pouco mas não desapareceu",
frequencia: "Meu filho comentou que tive dores no peito leves semanas atrás",
},
respostaPaciente: {
inicial: "Acordei com uma dor no peito",
dor: "Dor de aperto no peito",
intensidade: "7",
inicio: "Madrugada",
suor: "Sim",
respiracao: "Sim",
repouso: "Melhorou um pouco",
frequencia: "Dores semanas atrás",
},
sinais_vitais: {
corretos: {
pressaoArterial: "160/95 mmHg",
frequenciaCardiaca: 92,
frequenciaRespiratoria: 18,
temperatura: 36.7,
saturacaoOxigenio: 97,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "160/95 mmHg",
frequenciaCardiaca: 92,
frequenciaRespiratoria: 18,
temperatura: 36.7,
saturacaoOxigenio: 97,
},
exame_fisico: {
correto: {
inspecao: "Paciente ansiosa, palidez discreta, aparente desconforto",
palpacao: "Sem alterações significativas, sensibilidade leve em precórdio",
ausculta: "Ritmo regular, FC 92, sem sopros audíveis",
percussao: "Normal",
observacoes: "Sinais compatíveis com desconforto isquêmico",
regiao: "Precórdio",
achados_positivos: ["Ansiedade", "Palidez"],
achados_negativos: ["Sopros", "Arritmias"],
},
},
exameFisicoCorreto: {
inspecao: "Ansiosa, palidez discreta",
palpacao: "Sem alterações relevantes",
ausculta: "Ritmo regular, sem sopros",
percussao: "Normal",
observacoes: "Compatível com isquemia",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Paciente ansiosa, em desconforto",
consciencia: "Lúcida e orientada",
},
cardiovascular: {
inspecao_precordial: "Sem alterações visíveis",
ausculta_cardiaca: "Ritmo regular, FC 92 bpm, sem sopros audíveis",
pulsos: "Presentes e simétricos",
turgencia_jugular: "Normal",
edema: "Ausente",
},
},
exames_complementares_disponiveis: [
{
nome: "ECG (Eletrocardiograma)",
descricao: "12 derivações",
resultado: "Inversão de onda T em D2, D3, aVF; segmento ST no nível ou levemente deprimido",
valor_referencia: "Segmento ST isoelétrico",
interpretacao: "Isquemia inferolateral sem supra",
},
{
nome: "Troponina I inicial",
descricao: "Biomarcador cardíaco",
resultado: "<0.04 ng/mL",
valor_referencia: "<0.04 ng/mL",
interpretacao: "Normal (repetir em 3 horas)",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Angina Instável",
probabilidade: 85,
criterios_minimos: [
"Dor isquêmica em repouso",
"ECG com alterações dinâmicas",
"Troponina negativa",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "NSTEMI",
criterios_exclusao: ["Troponina elevada"],
achados_que_descartam: ["Troponina positiva"],
},
],
examesIndicados: [
"ECG seriado",
"Troponina seriada",
"Hemograma",
"Eletrólitos",
"Creatinina",
"Ecocardiograma",
"Angiografia coronariana",
],
conduta_esperada: {
imediata: [
"Monitorização cardíaca contínua",
"Oxigenioterapia se SpO2 <90%",
"Aspirina 500mg",
"Clopidogrel ou ticagrelor conforme protocolo",
"Heparina",
"Betabloqueador",
"Nitrato sublingual",
],
curto_prazo: [
"Internação em UCO",
"ECG seriado",
"Troponina seriada em 3-6 horas",
"Estratificação de risco",
"Angiografia diagnóstica",
],
longo_prazo: [
"Estatina",
"Reabilitação cardíaca",
"Modificação de fatores de risco",
],
encaminhamentos: ["Cardiologia", "Unidade Coronariana"],
},
condutaCorreta: "Internação, monitorização, ECG seriado, troponina seriada, antiagregantes, angiografia diagnóstica",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["Dor em repouso", "ECG com alterações", "Paciente idosa"],
descricao: "Risco moderado a alto de evolução para IAM",
recomendacao: "Internação em UCO, investigação urgente",
},
],
erros_criticos: [
{
erro: "Não internar para monitorização",
descricao: "Risco de progressão para IAM é alto",
penalidade: 2,
evitavel: true,
},
{
erro: "Não realizar ECG seriado",
descricao: "Mudanças dinâmicas ajudam no diagnóstico",
penalidade: 1.5,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu apresentação de angina instável",
realizado: false,
critico: true,
},
{
item: "Solicitou ECG urgente",
realizado: false,
critico: true,
},
{
item: "Solicitou troponina seriada",
realizado: false,
critico: true,
},
{
item: "Decidiu internar para monitorização",
realizado: false,
critico: true,
},
{
item: "Iniciou dupla antiagregação",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de SCA sem supra",
peso: 25,
descricao: "Diagnóstico diferencial apropriado",
pontuacao_maxima: 25,
},
{
criterio: "Decisão de internação",
peso: 25,
descricao: "Reconhecimento de risco elevado",
pontuacao_maxima: 25,
},
{
criterio: "Manejo inicial",
peso: 15,
descricao: "Antiagregantes e monitorização",
pontuacao_maxima: 15,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dor em repouso ou progressiva",
"Antecedentes de dor leve",
"Fatores de risco",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Sinais vitais",
"ECG com alterações dinâmicas",
"Troponina",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Angina instável",
"Risco de progressão",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Internação em UCO",
"Antiagregação",
"Monitorização",
"Angiografia diagnóstica",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu angina instável",
"Decidiu internar",
"Solicitou ECG e troponina seriada",
"Iniciou dupla antiagregação",
],
erros_comuns: [
"Confundir com gastrite",
"Liberar para casa",
"Esperar resultado de troponina para internar",
],
orientacoes_pedagogicas: [
"Angina instável = dor em repouso ou progressiva = SCA = internação obrigatória",
"Troponina negativa não exclui angina instável",
"ECG com alterações dinâmicas aumenta risco",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer angina instável como forma de SCA e indicar internação, ECG seriado e troponina seriada",
comunicacao: [
"explicou a gravidade",
"tranquilizou a paciente",
"explicou necessidade de internação",
],
anamnese: [
"investigou características da dor",
"pesquisou antecedentes de dor",
"investigou fatores de risco",
],
exame_fisico: [
"mediu sinais vitais",
"realizou ausculta cardíaca",
"avaliou perfusão",
],
exames_complementares: [
"solicitou ECG urgente",
"solicitou troponina seriada",
],
raciocinio: [
"diagnosticou angina instável",
"reconheceu risco de progressão",
],
conduta: [
"decidiu internar",
"iniciou dupla antiagregação",
],
soap: [
"documentou características de SCA",
"planejou investigação apropriada",
],
},
temaOSCE: "Síndrome Coronariana Aguda",
subtopicosOSCE: [
"Angina instável",
"Dor em repouso",
"ECG com alterações dinâmicas",
"SCA sem elevação de ST",
"Risco de progressão",
],
diagnosticoCorreto: "Angina Instável",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("19"),
} as CasoOSCEV2;
