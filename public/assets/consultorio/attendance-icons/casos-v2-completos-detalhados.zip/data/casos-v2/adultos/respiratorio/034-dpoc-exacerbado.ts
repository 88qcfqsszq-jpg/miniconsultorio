import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso034DpocExacerbado: CasoOSCEV2 = {
// ====== CASO 34: DPOC EXACERBADO ======
id: "34",
titulo: "DPOC Exacerbado",
sistema: "Respiratório",
tema: "Doença Obstrutiva",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Diagnosticar exacerbação de DPOC e estabelecer terapia apropriada",
dados_visiveis_ao_estudante: {
nome_paciente: "Roberto Pereira",
idade: 62,
sexo: "Masculino",
queixa_principal: "Falta de ar e tosse piores, com catarro colorido",
historia_breve: "Paciente com DPOC conhecida, agora com piora aguda de sintomas",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Exacerbação Aguda de DPOC",
diagnosticos_diferenciais: ["Pneumonia", "Insuficiência cardíaca", "Pneumotórax"],
sindromes_associadas: ["Bronquite Aguda"],
},
descricaoBreve: "Paciente com aumento de dispneia, tosse com catarro purulento, taquipneia",
categoria: "DPOC",
paciente: {
id: "pac-034",
nome: "Roberto Pereira",
idade: 62,
sexo: "M",
queixaPrincipal: "Falta de ar piora",
historicoDoenca: "DPOC há 10 anos",
antecedentes: ["DPOC", "Tabagismo"],
profissao: "Aposentado",
estado_civil: "Viúvo",
alergias: [],
medicamentos_em_uso: ["Salbutamol", "Tiotropio"],
},
respostas_do_paciente: {
inicial: "Tô pior que o normal, falta de ar de repente",
respiracao: "Muito piora, mal consigo andar",
tosse: "Tosse com catarro verde, mudou de cor",
febre: "Sim, tô com febre",
duracao: "Começou há 3 dias",
gatilho: "Acho que peguei resfriado",
},
respostaPaciente: {
inicial: "Piora de falta de ar",
respiracao: "Muita piora",
tosse: "Catarro verde",
febre: "Sim",
duracao: "3 dias",
gatilho: "Resfriado",
},
sinais_vitais: {
corretos: {
pressaoArterial: "145/90 mmHg",
frequenciaCardiaca: 105,
frequenciaRespiratoria: 24,
temperatura: 38.3,
saturacaoOxigenio: 88,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "145/90 mmHg",
frequenciaCardiaca: 105,
frequenciaRespiratoria: 24,
temperatura: 38.3,
saturacaoOxigenio: 88,
},
exame_fisico: {
correto: {
inspecao: "Taquipneia, uso de musculatura acessória, cianose periférica",
palpacao: "Expansão reduzida",
ausculta: "MV reduzido, roncos e sibilos bilaterais",
percussao: "Hipersonoro",
observacoes: "Achados de exacerbação de DPOC com infecção",
regiao: "Pulmões",
achados_positivos: ["Taquipneia", "Roncos", "Sibilos"],
achados_negativos: ["Crepitações focalizadas"],
},
},
exameFisicoCorreto: {
inspecao: "Taquipneia, cianose",
palpacao: "Expansão reduzida",
ausculta: "MV reduzido, roncos, sibilos",
percussao: "Hipersonoro",
observacoes: "Exacerbação DPOC",
},
exame_fisico_interativo: {
respiratorio: {
inspecao_torax: "Taquipneia 24 ipm, cianose periférica",
padrao_respiratorio: "Rápido, com lábios cerrados na expiração",
expansibilidade: "Reduzida",
ausculta_pulmonar: "MV reduzido bilateralmente, roncos e sibilos",
musculatura_acessoria: "Uso intenso",
},
},
exames_complementares_disponiveis: [
{
nome: "RX Tórax",
descricao: "Avaliação de infiltrados",
resultado: "Hiperinsuflação, sem infiltrado focal",
valor_referencia: "Normal",
interpretacao: "Exacerbação de DPOC sem pneumonia",
},
{
nome: "Hemograma",
descricao: "Leucócitos",
resultado: "12.000/mm³, neutrofilia",
valor_referencia: "<11.000",
interpretacao: "Infecção",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Exacerbação Aguda de DPOC",
probabilidade: 90,
criterios_minimos: [
"Aumento de dispneia",
"Catarro aumentado/mudança cor",
"Taquipneia",
"Hipoxemia",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Pneumonia",
criterios_exclusao: ["Ausência de consolidação"],
achados_que_descartam: ["RX sem infiltrado focal"],
},
],
examesIndicados: [
"RX de tórax",
"Hemograma",
"Gasometria arterial",
"Culturas se indicado",
],
conduta_esperada: {
imediata: [
"Oxigenioterapia",
"Broncodilatadores",
"Corticóide sistêmico",
"Antibiótico se infecção",
],
curto_prazo: [
"Internação se necessário",
"Monitorização",
],
longo_prazo: [
"Otimização de medicações",
"Reabilitação pulmonar",
],
encaminhamentos: ["Pneumologia", "Emergência"],
},
condutaCorreta: "Oxigenioterapia, broncodilatadores, corticóide sistêmico, antibiótico se infecção, possível internação",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["SpO2 <90%", "Taquipneia >24", "Alteração mental"],
descricao: "Risco de insuficiência respiratória",
recomendacao: "Internação e monitorização",
},
],
erros_criticos: [
{
erro: "Não oxigenar adequadamente",
descricao: "Hipoxemia é vida-ameaçadora",
penalidade: 2,
evitavel: true,
},
{
erro: "Não prescrever corticóide sistêmico",
descricao: "Essencial em exacerbação",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu exacerbação de DPOC",
realizado: false,
critico: true,
},
{
item: "Iniciou oxigenioterapia",
realizado: false,
critico: true,
},
{
item: "Prescreveu broncodilatadores",
realizado: false,
critico: true,
},
{
item: "Prescreveu corticóide",
realizado: false,
critico: true,
},
{
item: "Solicitou RX e hemograma",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de exacerbação",
peso: 25,
descricao: "Diferenciação de estável",
pontuacao_maxima: 25,
},
{
criterio: "Manejo da exacerbação",
peso: 25,
descricao: "Medicações e oxigenação",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Aumento de dispneia",
"Catarro mudou de cor",
"Febre",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Taquipneia",
"SpO2 reduzida",
"MV reduzido",
"RX sem infiltrado focal",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Exacerbação DPOC",
"Infecção bacteriana provável",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Oxigenioterapia",
"Broncodilatadores",
"Corticóide sistêmico",
"Antibiótico",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu exacerbação",
"Iniciou oxigenioterapia",
"Prescreveu corticóide sistêmico",
"Solicitou RX e hemograma",
],
erros_comuns: [
"Diagnosticar como pneumonia",
"Não prescrever corticóide sistêmico",
],
orientacoes_pedagogicas: [
"Exacerbação DPOC: aumento de dispneia e mudança de catarro",
"RX sem infiltrado focal descarta pneumonia",
"Sempre usar corticóide sistêmico em exacerbação",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar exacerbação e prescrever manejo apropriado",
comunicacao: ["explicou plano de tratamento"],
anamnese: ["investigou mudanças agudas"],
exame_fisico: ["avaliou nível de desconforto"],
exames_complementares: ["pediu RX e hemograma"],
raciocinio: ["diagnosticou exacerbação"],
conduta: ["prescreveu medicações e oxigenioterapia"],
soap: ["documentou exacerbação"],
},
temaOSCE: "Doença Obstrutiva",
subtopicosOSCE: [
"Exacerbação DPOC",
"Aumento de sintomas",
"Catarro purulento",
"Corticóide sistêmico",
"Antibiótico",
],
diagnosticoCorreto: "Exacerbação Aguda de DPOC",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("34"),
} as CasoOSCEV2;
