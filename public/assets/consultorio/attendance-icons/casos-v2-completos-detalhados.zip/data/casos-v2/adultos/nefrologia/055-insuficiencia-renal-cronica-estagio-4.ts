import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso055InsuficienciaRenalCronicaEstagio4: CasoOSCEV2 = {
// ====== CASO 55: INSUFICIÊNCIA RENAL CRÔNICA COM COMPLICAÇÕES ======
id: "55",
titulo: "Insuficiência Renal Crônica Estágio 4",
sistema: "Nefrologia",
tema: "Casos Integradores",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 13,
objetivo_pedagogico: "Reconhecer IRC avançada com complicações de hipertensão, anemia e alterações eletrolíticas",
dados_visiveis_ao_estudante: {
nome_paciente: "Maria Souza",
idade: 68,
sexo: "Feminino",
queixa_principal: "Fadiga, edema, pressão alta, náusea",
historia_breve: "Paciente com IRC progressiva há 10 anos",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Insuficiência Renal Crônica Estágio 4",
diagnosticos_diferenciais: ["Insuficiência renal aguda", "Nefropatia diabética", "Doença renal policística"],
sindromes_associadas: ["Hipertensão refratária", "Anemia", "Hiperkalemia", "Acidose metabólica"],
},
descricaoBreve: "Paciente com TFG 15, edema, hipertensão, palidez, anemia severa",
categoria: "Casos Integradores",
paciente: {
id: "pac-055",
nome: "Maria Souza",
idade: 68,
sexo: "F",
queixaPrincipal: "Fadiga e edema",
historicoDoenca: "IRC progressiva há 10 anos",
antecedentes: ["Hipertensão", "IRC"],
profissao: "Aposentada",
estado_civil: "Viúva",
alergias: [],
medicamentos_em_uso: ["Losartana", "Furosemida"],
},
respostas_do_paciente: {
inicial: "Muito cansada, corpo inchado, pressão alta",
fadiga: "Intensa, não consigo fazer nada",
edema: "Inchação nos pés e pernas",
pressao: "Pressão sempre alta, difícil controlar",
nausea: "Enjoo constante",
respiracao: "Sem fôlego às vezes",
urina: "Pouca quantidade",
},
respostaPaciente: {
inicial: "Fadiga e edema",
fadiga: "Muito",
edema: "Pés e pernas",
pressao: "Alta",
nausea: "Sim",
respiracao: "Sim",
urina: "Pouca",
},
sinais_vitais: {
corretos: {
pressaoArterial: "170/100 mmHg",
frequenciaCardiaca: 92,
frequenciaRespiratoria: 20,
temperatura: 36.8,
saturacaoOxigenio: 96,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "170/100 mmHg",
frequenciaCardiaca: 92,
frequenciaRespiratoria: 20,
temperatura: 36.8,
saturacaoOxigenio: 96,
},
exame_fisico: {
correto: {
inspecao: "Palidez, edema em membros inferiores e sacro",
palpacao: "Edema com cacifo, sem diurese",
ausculta: "Estertores basais bilaterais",
percussao: "Normal",
observacoes: "Sobrecarga volêmica e insuficiência cardíaca direita",
regiao: "Geral",
achados_positivos: ["Palidez", "Edema", "Estertores"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Pálida, edema",
palpacao: "Edema com cacifo",
ausculta: "Estertores basais",
percussao: "Normal",
observacoes: "IRC com congestão",
},
exame_fisico_interativo: {
geral: {
coloracao: "Pálida, apergaminhada",
consciencia: "Alerta mas cansada",
},
membros: {
edema: "Bilateral, com cacifo",
},
},
exames_complementares_disponiveis: [
{
nome: "Creatinina",
descricao: "Função renal",
resultado: "4.5 mg/dL",
valor_referencia: "<1.2 mg/dL",
interpretacao: "Insuficiência renal severa",
},
{
nome: "Potássio",
descricao: "Eletrólito",
resultado: "6.2 mEq/L",
valor_referencia: "3.5-5.0 mEq/L",
interpretacao: "Hiperkalemia",
},
{
nome: "pH",
descricao: "Acidose",
resultado: "7.28",
valor_referencia: ">7.35",
interpretacao: "Acidose metabólica",
},
{
nome: "Hemoglobina",
descricao: "Anemia",
resultado: "7.5 g/dL",
valor_referencia: ">12 g/dL",
interpretacao: "Anemia severa de doença crônica",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Insuficiência Renal Crônica Estágio 4",
probabilidade: 98,
criterios_minimos: [
"Creatinina elevada",
"TFG <30",
"Anemia",
"Hiperkalemia",
"Acidose",
"Hipertensão refratária",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Insuficiência renal aguda",
criterios_exclusao: ["História crônica de 10 anos"],
achados_que_descartam: ["IRC progressiva"],
},
],
examesIndicados: [
"Creatinina, TFG",
"Eletrólitos (K, Na, Cl, CO2)",
"Hemograma",
"Fósforo, cálcio",
"PTH",
"USG renal",
],
conduta_esperada: {
imediata: [
"Controle de potássio",
"Diálise se TFG <15",
"Controle de pressão arterial",
],
curto_prazo: [
"Nefrologia urgente",
"Preparação para diálise",
],
longo_prazo: [
"Diálise regular",
"Transplante se possível",
],
encaminhamentos: ["Nefrologia", "Vascular para fístula"],
},
condutaCorreta: "Nefrologia urgente, TFG, eletrólitos, diálise se indicado, controle de K",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["TFG <15", "Hiperkalemia", "Acidose"],
descricao: "IRC em estágio avançado com complicações",
recomendacao: "Diálise imediata",
},
],
erros_criticos: [
{
erro: "Não monitorizar potássio",
descricao: "Risco de arritmia cardíaca",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu IRC avançada",
realizado: false,
critico: true,
},
{
item: "Avaliou eletrólitos",
realizado: false,
critico: true,
},
{
item: "Investigou anemia",
realizado: false,
critico: true,
},
{
item: "Encaminhou nefrologia",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de IRC",
peso: 30,
descricao: "Estadiamento e complicações",
pontuacao_maxima: 30,
},
{
criterio: "Manejo de complicações",
peso: 25,
descricao: "Potássio, anemia, pressão",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Fadiga",
"Edema",
"Náusea",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Creatinina 4.5",
"Potássio 6.2",
"Anemia",
"Edema",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["IRC estágio 4"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Nefrologia",
"Diálise",
"Controle de K",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu IRC",
"Avaliou eletrólitos",
"Investigou anemia",
"Encaminhou nefrologia",
],
erros_comuns: ["Focar apenas em pressão"],
orientacoes_pedagogicas: [
"IRC: sempre investigar complicações cardiovasculares e eletrolíticas",
"Potássio >6 é emergência",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer IRC com complicações multissistêmicas",
comunicacao: ["explicou urgência de diálise"],
anamnese: ["investigou sintomas"],
exame_fisico: ["detectou edema e estertores"],
exames_complementares: ["pediu eletrólitos"],
raciocinio: ["diagnosticou IRC"],
conduta: ["encaminhou nefrologia"],
soap: ["documentou IRC"],
},
temaOSCE: "Casos Integradores",
subtopicosOSCE: [
"IRC estágio 4",
"Hiperkalemia",
"Anemia",
"Hipertensão",
"Complicações sistêmicas",
],
diagnosticoCorreto: "Insuficiência Renal Crônica Estágio 4",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("55"),
} as CasoOSCEV2;
