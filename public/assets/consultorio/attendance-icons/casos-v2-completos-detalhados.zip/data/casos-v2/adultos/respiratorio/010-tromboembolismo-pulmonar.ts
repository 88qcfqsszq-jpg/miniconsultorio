import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso010TromboembolismoPulmonar: CasoOSCEV2 = {
// ====== CASO 10: TEP - TROMBOEMBOLISMO PULMONAR ======
id: "10",
titulo: "Tromboembolismo Pulmonar",
sistema: "Respiratório",
tema: "Dispneia Aguda",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 15,
objetivo_pedagogico: "Reconhecer TEP, estratificar risco e prescrever anticoagulação apropriada",
dados_visiveis_ao_estudante: {
nome_paciente: "Helena Gomes",
idade: 45,
sexo: "Feminino",
queixa_principal: "Dor no peito e falta de ar súbita",
historia_breve: "Operada de joelho há 2 semanas, agora com dispneia súbita e dor pleurítica",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Tromboembolismo Pulmonar de Risco Intermediário",
diagnosticos_diferenciais: [
"Infarto Agudo do Miocárdio",
"Pneumonia",
"Pericardite",
"Síncope de outra causa",
],
sindromes_associadas: ["Tromboembolia"],
},
descricaoBreve: "Paciente com dispneia súbita, dor pleurítica, antecedente de cirurgia recente",
categoria: "TEP",
paciente: {
id: "pac-010",
nome: "Helena Gomes",
idade: 45,
sexo: "F",
queixaPrincipal: "Dor no peito e falta de ar súbita",
historicoDoenca: "Operada de joelho há 2 semanas, agora com dispneia súbita",
antecedentes: ["Sem HAS", "Sem DM", "Contraceptivo oral"],
profissao: "Professora",
estado_civil: "Casada",
alergias: [],
medicamentos_em_uso: ["Contraceptivo oral"],
},
respostas_do_paciente: {
inicial: "Doutor, acordei com muita falta de ar, tipo um aperto no peito.",
inicio: "Foi de repente, estava dormindo tranquilo.",
dor: "Sinto uma dor que piora quando respiro fundo.",
intensidade: "8 a 9, muito incômodo.",
cirurgia: "Fiz uma operação no joelho há 2 semanas, tive que ficar de repouso.",
perna: "Minha perna ficou inchada e dolorida depois da cirurgia.",
tosse: "Tenho uma tosse ligeira.",
hemoptise: "Não, não tenho sangue na tosse não.",
suor: "Sim, tô suada, com medo.",
},
respostaPaciente: {
inicial: "Doutor, acordei com muita falta de ar, tipo um aperto no peito.",
inicio: "Foi de repente, estava dormindo tranquilo.",
dor: "Sinto uma dor que piora quando respiro fundo.",
intensidade: "8 a 9, muito incômodo.",
cirurgia: "Fiz uma operação no joelho há 2 semanas, tive que ficar de repouso.",
perna: "Minha perna ficou inchada e dolorida depois da cirurgia.",
tosse: "Tenho uma tosse ligeira.",
hemoptise: "Não, não tenho sangue na tosse não.",
suor: "Sim, tô suada, com medo.",
},
sinais_vitais: {
corretos: {
pressaoArterial: "130/85 mmHg",
frequenciaCardiaca: 115,
frequenciaRespiratoria: 28,
temperatura: 37.0,
saturacaoOxigenio: 91,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "130/85 mmHg",
frequenciaCardiaca: 115,
frequenciaRespiratoria: 28,
temperatura: 37.0,
saturacaoOxigenio: 91,
glicemia: 120,
},
exame_fisico: {
correto: {
inspecao: "Paciente ansiosa, taquipneica, sem cianose no repouso",
palpacao: "Pulsos simétricos, sem edema em MMSS, edema leve em MID (perna operada)",
ausculta: "Murmúrio vesicular presente bilateralmente, sem alterações específicas",
percussao: "Normal",
observacoes:
"Sem achados específicos, edema de perna é fator de risco para TEP",
regiao: "Pulmões e MMII",
achados_positivos: ["Taquicardia", "Taquipneia", "Edema em perna"],
achados_negativos: ["Sopros", "Crepitações"],
},
},
exameFisicoCorreto: {
inspecao: "Paciente ansiosa, taquipneica",
palpacao: "Edema leve em perna operada",
ausculta: "Murmúrio vesicular presente",
percussao: "Normal",
observacoes: "Edema de MMII é fator de risco",
},
exames_complementares_disponiveis: [
{
nome: "ECG",
descricao: "12 derivações",
resultado: "Taquicardia sinusal, padrão S1Q3T3 (onda S em D1, onda Q em D3, onda T negativa em D3)",
valor_referencia: "Normal",
interpretacao: "Compatível com TEP",
},
{
nome: "D-dímero",
descricao: "Marcador de tromboembolia",
resultado: "850 ng/mL",
valor_referencia: "<500 ng/mL",
interpretacao: "Elevado, não exclui TEP em probabilidade alta",
},
{
nome: "Angiografia Pulmonar por TC",
descricao: "Angio-TC de tórax",
resultado: "Defeito de enchimento em artéria pulmonar direita (segmentar)",
valor_referencia: "Normal",
interpretacao: "TEP confirmado",
},
{
nome: "Troponina",
descricao: "Biomarcador cardíaco",
resultado: "0.08 ng/mL",
valor_referencia: "<0.04 ng/mL",
interpretacao: "Elevada, indica dano miocárdico",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Tromboembolismo Pulmonar",
probabilidade: 85,
criterios_minimos: [
"Dispneia súbita",
"Dor pleurítica",
"Fator de risco: cirurgia recente",
"ECG: S1Q3T3",
"Angio-TC positiva",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Infarto Agudo do Miocárdio",
criterios_exclusao: ["ST elevado focal"],
achados_que_descartam: ["Padrão de ECG diferente, angio-TC negativa"],
},
],
examesIndicados: [
"ECG",
"D-dímero se probabilidade baixa",
"Angio-TC de tórax",
"Troponina",
"Ecocardiograma",
],
conduta_esperada: {
imediata: [
"Oxigenioterapia para manter SpO2 >94%",
"Anticoagulação: Heparina não fracionada ou enoxaparina IV",
"Acesso venoso, monitorização",
],
curto_prazo: [
"Confirmar diagnóstico com angio-TC",
"Considerar trombolítico se TEP massiva",
"Transição para warfarina ou anticoagulante direto",
],
longo_prazo: [
"Anticoagulação por 3 meses",
"Investigação de tromboembolia recorrente",
"Profilaxia em futuras cirurgias",
],
encaminhamentos: ["Cirurgia vascular se trombose venosa profunda"],
},
condutaCorreta:
"Oxigenio, anticoagulação imediata, angio-TC para confirmação, considerar trombolítico se massiva",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["SpO2 91-94%", "Taquicardia", "Sem hipotensão"],
descricao: "TEP de risco intermediário",
recomendacao: "Anticoagulação, monitorização, angio-TC",
},
{
severidade: "grave",
sinais: ["SpO2 <90%", "Hipotensão", "Disfunção VD"],
descricao: "TEP de alto risco (massiva)",
recomendacao: "Anticoagulação, trombolítico, possível trombectomia",
},
],
erros_criticos: [
{
erro: "Não iniciar anticoagulação suspeitando de TEP",
descricao: "Atraso em anticoagulação aumenta mortalidade",
penalidade: 2.5,
evitavel: true,
},
{
erro: "Não solicitar angio-TC",
descricao: "Angio-TC é padrão-ouro para diagnóstico",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{ item: "Investigou fatores de risco: cirurgia, edema", realizado: false, critico: true },
{ item: "Mediu SpO2 e gases se possível", realizado: false, critico: true },
{ item: "Solicitou ECG", realizado: false, critico: true },
{ item: "Solicitou D-dímero", realizado: false, critico: true },
{ item: "Solicitou angio-TC de tórax", realizado: false, critico: true },
{ item: "Iniciou anticoagulação", realizado: false, critico: true },
],
rubrica_correcao: [
{
criterio: "Reconhecimento de Fatores de Risco",
peso: 15,
descricao: "Cirurgia, imobilização, contraceptivo",
pontuacao_maxima: 15,
},
{
criterio: "Diagnóstico",
peso: 25,
descricao: "Solicitação de angio-TC apropriada",
pontuacao_maxima: 25,
},
{
criterio: "Terapia Anticoagulante",
peso: 30,
descricao: "Anticoagulação imediata",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dispneia súbita",
"Dor pleurítica",
"Cirurgia recente",
"Edema de perna",
"Contraceptivo oral",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Taquicardia, taquipneia",
"SpO2 reduzida",
"ECG: S1Q3T3",
"D-dímero elevado",
"Angio-TC: defeito de enchimento",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["TEP de risco intermediário", "Fatores de risco presentes"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Oxigenioterapia",
"Heparina IV",
"Angio-TC confirmação",
"Transição para warfarina",
"Seguimento prolongado",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Investigou fatores de risco",
"Solicitou ECG",
"Solicitou angio-TC",
"Iniciou anticoagulação",
"Mediu SpO2",
],
erros_comuns: [
"Atraso em anticoagulação",
"Não solicitar angio-TC",
"Confundir com IAM",
],
orientacoes_pedagogicas: [
"TEP: dispneia súbita + dor pleurítica",
"Fatores de risco: cirurgia, imobilização, contraceptivo, malignidade",
"ECG pode mostrar S1Q3T3 ou apenas taquicardia",
"Angio-TC é padrão-ouro",
"Anticoagular ANTES de confirmar se alta suspeita",
],
},
temaOSCE: "Tuberculose",
subtopicosOSCE: [
"Tosse > 3 semanas",
"Febre vespertina",
"Baciloscopia positiva",
"Esquema RIPE (rifampicina, isoniazida, pirazinamida, etambutol)",
"Isolamento respiratório"
],
diagnosticoCorreto: "Tromboembolismo Pulmonar",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("10"),
} as CasoOSCEV2;
