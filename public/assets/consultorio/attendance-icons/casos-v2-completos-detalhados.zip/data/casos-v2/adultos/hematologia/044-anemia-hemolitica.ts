import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso044AnemiaHemolitica: CasoOSCEV2 = {
// ====== CASO 44: ANEMIA HEMOLÍTICA ======
id: "44",
titulo: "Anemia Hemolítica",
sistema: "Hematologia",
tema: "Anemias",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 11,
objetivo_pedagogico: "Diagnosticar anemia hemolítica por achados de hemólise",
dados_visiveis_ao_estudante: {
nome_paciente: "João Pereira",
idade: 38,
sexo: "Masculino",
queixa_principal: "Cansaço, febre e urina escura",
historia_breve: "Anemia aguda com icterícia, hemoglobinúria",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Anemia Hemolítica",
diagnosticos_diferenciais: ["Hepatite", "Insuficiência hepática", "Talassemia"],
sindromes_associadas: ["Hemólise intravascular"],
},
descricaoBreve: "Paciente com icterícia, esplenomegalia, hemoglobina baixa com reticulocitose elevada",
categoria: "Anemias",
paciente: {
id: "pac-044",
nome: "João Pereira",
idade: 38,
sexo: "M",
queixaPrincipal: "Cansaço e icterícia",
historicoDoenca: "Sintomas agudos há 3 dias",
antecedentes: [],
profissao: "Mecânico",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Ficou tudo amarelado, tô muito cansado",
ictericia: "Sim, tudo amarelo",
urina: "Urina muito escura, quase preta",
febre: "Sim, febre alta",
dor: "Dor nos flancos",
cansaco: "Muito cansaço",
pele_escurecida: "Amarelada muito mesmo",
},
respostaPaciente: {
inicial: "Icterícia e urina escura",
ictericia: "Sim",
urina: "Muito escura",
febre: "Sim",
dor: "Nos flancos",
cansaco: "Muita",
pele_escurecida: "Sim",
},
sinais_vitais: {
corretos: {
pressaoArterial: "115/75 mmHg",
frequenciaCardiaca: 100,
frequenciaRespiratoria: 18,
temperatura: 38.5,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "115/75 mmHg",
frequenciaCardiaca: 100,
frequenciaRespiratoria: 18,
temperatura: 38.5,
saturacaoOxigenio: 98,
},
exame_fisico: {
correto: {
inspecao: "Icterícia com escleras ictéricas, palidez",
palpacao: "Esplenomegalia palpável",
ausculta: "MV normal",
percussao: "Baço aumentado",
observacoes: "Sinais de hemólise",
regiao: "Geral",
achados_positivos: ["Icterícia", "Esplenomegalia", "Palidez"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Ictérico",
palpacao: "Esplenomegalia",
ausculta: "Normal",
percussao: "Baço aumentado",
observacoes: "Hemólise",
},
exame_fisico_interativo: {
geral: {
coloracao: "Ictérico",
consciencia: "Alerta",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemograma",
descricao: "Série vermelha",
resultado: "Hb 7.5, RET 15%, VCM 90",
valor_referencia: "RET 0.5-2%",
interpretacao: "Anemia com reticulocitose",
},
{
nome: "Bilirrubina indireta",
descricao: "Fração não-conjugada",
resultado: "6.5 mg/dL",
valor_referencia: "<0.3 mg/dL",
interpretacao: "Hiperbilirrubinemia indireta",
},
{
nome: "LDH",
descricao: "Desidrogenase lática",
resultado: "850 U/L",
valor_referencia: "<480 U/L",
interpretacao: "Hemólise",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Anemia Hemolítica",
probabilidade: 95,
criterios_minimos: [
"Anemia",
"Reticulocitose elevada",
"Bilirrubina indireta elevada",
"LDH elevado",
"Icterícia",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Hepatite",
criterios_exclusao: ["Bilirrubina predominantemente indireta"],
achados_que_descartam: ["TGO/TGP baixas"],
},
],
examesIndicados: [
"Hemograma com reticulócitos",
"Bilirrubina total e frações",
"LDH, haptoglobina",
"Teste de Coombs",
],
conduta_esperada: {
imediata: [
"Transfusão se Hb <7",
"Internação",
],
curto_prazo: [
"Investigação de causa",
"Possível corticóide",
],
longo_prazo: [
"Acompanhamento hematológico",
],
encaminhamentos: ["Hematologia"],
},
condutaCorreta: "Hemograma com reticulócitos, bilirrubina, Coombs, transfusão se necessário, hematologia",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["Hb <7", "Febre", "Hemoglobinúria"],
descricao: "Hemólise aguda grave",
recomendacao: "Internação e transfusão",
},
],
erros_criticos: [
{
erro: "Não solicitar reticulócitos",
descricao: "Diferencia hemólise de outras anemias",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu hemólise",
realizado: false,
critico: true,
},
{
item: "Solicitou reticulócitos",
realizado: false,
critico: true,
},
{
item: "Avaliou bilirrubina",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de hemólise",
peso: 30,
descricao: "Achados de hemólise",
pontuacao_maxima: 30,
},
{
criterio: "Investigação apropriada",
peso: 20,
descricao: "Exames de hemólise",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Cansaço",
"Icterícia aguda",
"Urina escura",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Icterícia",
"Esplenomegalia",
"Bilirrubina elevada",
"Reticulocitose",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Anemia hemolítica"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Coombs test",
"Transfusão se necessário",
"Hematologia",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu hemólise",
"Solicitou reticulócitos",
"Pesquisou bilirrubina indireta",
],
erros_comuns: ["Confundir com hepatite"],
orientacoes_pedagogicas: [
"Hemólise: bilirrubina indireta + reticulocitose + LDH elevado",
"Hepatite: bilirrubina direta + TGO/TGP muito elevada",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer hemólise pelos achados",
comunicacao: ["explicou urgência"],
anamnese: ["investigou icterícia aguda"],
exame_fisico: ["detectou esplenomegalia"],
exames_complementares: ["pediu reticulócitos e bilirrubina"],
raciocinio: ["diagnosticou hemólise"],
conduta: ["encaminhou hematologia"],
soap: ["documentou hemólise"],
},
temaOSCE: "Anemias",
subtopicosOSCE: [
"Anemia hemolítica",
"Reticulocitose",
"Hiperbilirrubinemia indireta",
"LDH elevado",
"Esplenomegalia",
],
diagnosticoCorreto: "Anemia Hemolítica",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("44"),
} as CasoOSCEV2;
