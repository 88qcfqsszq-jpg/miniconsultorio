import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso027FebreReumaticaAguda: CasoOSCEV2 = {
// ====== CASO 27: FEBRE REUMÁTICA AGUDA ======
id: "27",
titulo: "Febre Reumática Aguda",
sistema: "Cardiovascular",
tema: "Inflamação Cardíaca",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Diagnosticar febre reumática aguda e iniciar tratamento anti-inflamatório",
dados_visiveis_ao_estudante: {
nome_paciente: "Mariana Silva",
idade: 12,
sexo: "Feminino",
queixa_principal: "Febre, dor nas articulações e rash",
historia_breve: "Inflamação articular após infecção de garganta, rash na pele",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Febre Reumática Aguda",
diagnosticos_diferenciais: ["Artrite reumatoide", "Lúpus", "Endocardite"],
sindromes_associadas: ["Síndrome de Sydenham"],
},
descricaoBreve: "Criança com febre, poliartrite migratória, cardite, erupção evanescente, nódulos subcutâneos",
categoria: "FR",
paciente: {
id: "pac-027",
nome: "Mariana Silva",
idade: 12,
sexo: "F",
queixaPrincipal: "Febre e dor nas articulações",
historicoDoenca: "Infecção de garganta 1 mês atrás",
antecedentes: ["Infecção estreptocócica prévia"],
profissao: "Estudante",
estado_civil: "Solteira",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Tô com febre e minhas articulações estão muito doidas",
articulacoes: "Dor em vários lugares, que muda de local",
duracao: "Começou há uma semana",
rash: "Sim, aparecem manchas vermelhas que desaparecem",
movimentos: "Tô fazendo uns movimentos que não consigo controlar",
garganta: "Tive inflamação de garganta há um mês",
},
respostaPaciente: {
inicial: "Febre e dor nas articulações",
articulacoes: "Sim, vários locais",
duracao: "1 semana",
rash: "Sim",
movimentos: "Sim, involuntários",
garganta: "Sim, há um mês",
},
sinais_vitais: {
corretos: {
pressaoArterial: "110/70 mmHg",
frequenciaCardiaca: 108,
frequenciaRespiratoria: 20,
temperatura: 39.2,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "110/70 mmHg",
frequenciaCardiaca: 108,
frequenciaRespiratoria: 20,
temperatura: 39.2,
saturacaoOxigenio: 98,
},
exame_fisico: {
correto: {
inspecao: "Erupção evanescente, nódulos subcutâneos em cotovelos, movimentos involuntários",
palpacao: "Joelhos e tornozelos edemaciados e dolorosos",
ausculta: "Sopro mitral sistólico, atrito pericárdico",
percussao: "Normal",
observacoes: "Poliartrite migratória com cardite",
regiao: "Geral",
achados_positivos: ["Artrite", "Cardite", "Erupção"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Erupção e movimentos involuntários",
palpacao: "Articulações edemaciadas",
ausculta: "Sopro mitral, atrito pericárdico",
percussao: "Normal",
observacoes: "Achados de FR",
},
exame_fisico_interativo: {
cardiovascular: {
ausculta_cardiaca: "Sopro sistólico em ápice, atrito pericárdico presente",
},
},
exames_complementares_disponiveis: [
{
nome: "Anti-Estreptolisina O (ASO)",
descricao: "Marcador de infecção",
resultado: ">500 UI/mL",
valor_referencia: "<200",
interpretacao: "Infecção estreptocócica recente",
},
{
nome: "Ecocardiograma",
descricao: "Avaliação cardíaca",
resultado: "Espessamento de mitral, regurgitação leve",
valor_referencia: "Normal",
interpretacao: "Cardite reumática",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Febre Reumática Aguda",
probabilidade: 90,
criterios_minimos: [
"Poliartrite migratória",
"Febre",
"ASO elevado",
"Cardite",
"Erupção evanescente",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Artrite reumatoide juvenil",
criterios_exclusao: ["ASO elevado"],
achados_que_descartam: ["Cardite reumática"],
},
],
examesIndicados: [
"ASO",
"Ecocardiograma",
"Radiografia de tórax",
"Teste de streptococo",
],
conduta_esperada: {
imediata: [
"Penicilina IM para erradicar bactéria",
"Aspirina em altas doses",
"Corticoides se cardite",
],
curto_prazo: [
"Repouso",
"Monitorização cardíaca",
],
longo_prazo: [
"Profilaxia com penicilina",
"Acompanhamento cardiológico",
],
encaminhamentos: ["Cardiologia", "Reumatologia"],
},
condutaCorreta: "Penicilina IM, aspirina em altas doses, corticoides se cardite, profilaxia secundária",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["Cardite com murmúrio", "Cardiomegalia"],
descricao: "Risco de sequela valvular",
recomendacao: "Uso de corticóide",
},
],
erros_criticos: [
{
erro: "Não prescrever penicilina",
descricao: "Essencial para erradicar estreptococo",
penalidade: 2,
evitavel: true,
},
{
erro: "Não iniciar profilaxia secundária",
descricao: "Prevenção de recorrência é crítica",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Investigou infecção prévia de garganta",
realizado: false,
critico: true,
},
{
item: "Reconheceu poliartrite migratória",
realizado: false,
critico: true,
},
{
item: "Solicitou ASO e ecocardiograma",
realizado: false,
critico: true,
},
{
item: "Prescreveu penicilina",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de FR",
peso: 30,
descricao: "Critérios de Jones",
pontuacao_maxima: 30,
},
{
criterio: "Tratamento apropriado",
peso: 25,
descricao: "Penicilina e profilaxia",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Poliartrite migratória",
"Infecção de garganta prévia",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Erupção evanescente",
"Cardite",
"ASO elevado",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Febre reumática aguda"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Penicilina IM",
"Aspirina",
"Profilaxia",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu FR pelos critérios",
"Prescreveu penicilina",
"Iniciou profilaxia",
],
erros_comuns: ["Confundir com artrite reumatoide"],
orientacoes_pedagogicas: [
"Critérios maiores de Jones: cardite, poliartrite, coréia, eritema marginado, nódulos",
"Sempre prescrever profilaxia secundária",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar FR pelos critérios clínicos e iniciar tratamento urgente",
comunicacao: ["explicou importância de profilaxia"],
anamnese: ["investigou infecção prévia de garganta"],
exame_fisico: ["detectou artrite, erupção, cardite"],
exames_complementares: ["pediu ASO e ecocardiograma"],
raciocinio: ["diagnosticou FR"],
conduta: ["prescreveu penicilina e profilaxia"],
soap: ["documentou FR"],
},
temaOSCE: "Febre Reumática",
subtopicosOSCE: [
"Febre reumática aguda",
"Critérios de Jones",
"Poliartrite migratória",
"Cardite",
"Profilaxia secundária",
],
diagnosticoCorreto: "Febre Reumática Aguda",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("27"),
} as CasoOSCEV2;
