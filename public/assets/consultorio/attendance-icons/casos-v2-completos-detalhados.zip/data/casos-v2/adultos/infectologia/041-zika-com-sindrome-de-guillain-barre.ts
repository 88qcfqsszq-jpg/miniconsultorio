import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso041ZikaComSindromeDeGuillain: CasoOSCEV2 = {
// ====== CASO 41: ZIKA COM SÍNDROME GUILLAIN-BARRÉ ======
id: "41",
titulo: "Zika com Síndrome de Guillain-Barré",
sistema: "Infectologia",
tema: "Arboviroses",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Reconhecer complicação neurológica de Zika e instituir manejo apropriado",
dados_visiveis_ao_estudante: {
nome_paciente: "Mariana Costa",
idade: 30,
sexo: "Feminino",
queixa_principal: "Fraqueza progressiva das pernas, dificuldade para caminhar",
historia_breve: "Febre e exantema há 10 dias, agora com fraqueza ascendente",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Zika com Síndrome de Guillain-Barré",
diagnosticos_diferenciais: ["Paralisia flácida", "Polineuropatia periférica", "Mielite"],
sindromes_associadas: ["Insuficiência respiratória potencial"],
},
descricaoBreve: "Paciente com história de Zika e paralisia flácida ascendente com arreflexia",
categoria: "Arboviroses",
paciente: {
id: "pac-041",
nome: "Mariana Costa",
idade: 30,
sexo: "F",
queixaPrincipal: "Fraqueza progressiva",
historicoDoenca: "Zika confirmada 10 dias atrás",
antecedentes: ["Zika"],
profissao: "Enfermeira",
estado_civil: "Grávida",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Tive dengue ou Zika, agora não consigo mais caminhar",
exantema_anterior: "Sim, tive febre e exantema há 10 dias",
fraqueza: "Começou pelas pernas, agora subiu para os braços",
ascensao: "Piora cada dia, sinto que tá subindo",
dor: "Dor nas costas, formigamento",
respiracao: "Um pouco de falta de ar ao deitar",
sensibilidade: "Sinto formigamento nas mãos e pés",
},
respostaPaciente: {
inicial: "Fraqueza progressiva",
exantema_anterior: "Sim",
fraqueza: "Ascendente",
ascensao: "Sim",
dor: "Sim",
respiracao: "Leve",
sensibilidade: "Sim",
},
sinais_vitais: {
corretos: {
pressaoArterial: "115/75 mmHg",
frequenciaCardiaca: 85,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 96,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "115/75 mmHg",
frequenciaCardiaca: 85,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 96,
},
exame_fisico: {
correto: {
inspecao: "Paciente com déficit motor progressivo, fraqueza em MMII > MMSS",
palpacao: "Tônus muscular reduzido, reflexos ausentes em MMII",
ausculta: "MV simétrico bilateral",
percussao: "Normal",
observacoes: "Paralisia flácida ascendente com arreflexia",
regiao: "Sistema nervoso periférico",
achados_positivos: ["Fraqueza proximal e distal", "Arreflexia"],
achados_negativos: ["Sinal de Babinski negativo"],
},
},
exameFisicoCorreto: {
inspecao: "Fraqueza ascendente",
palpacao: "Tônus reduzido, arreflexia",
ausculta: "MV normal",
percussao: "Normal",
observacoes: "SGB em evolução",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Déficit motor progressivo em MMII e MMSS",
marcha: "Impossível caminhar",
},
membros: {
mobilidade: "Grau 2-3/5 MMII, 4/5 MMSS com arreflexia",
edema: "Polineuropatia sensitiva simétrica",
},
},
exames_complementares_disponiveis: [
{
nome: "Ressonância Magnética Coluna",
descricao: "Avaliação de medula",
resultado: "Normal, sem sinais de mielite",
valor_referencia: "Sem alterações",
interpretacao: "Descarta mielite",
},
{
nome: "Eletroneuromiografia",
descricao: "Padrão de desmielinização",
resultado: "Desmielinização segmentar",
valor_referencia: "Normal",
interpretacao: "Compatível com SGB",
},
{
nome: "Sorologia Zika",
descricao: "IgM anti-Zika",
resultado: "Positivo",
valor_referencia: "Negativo",
interpretacao: "Infecção recente por Zika",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Zika com Síndrome de Guillain-Barré",
probabilidade: 90,
criterios_minimos: [
"História de Zika",
"Paralisia flácida ascendente",
"Arreflexia",
"Desmielinização em ENMG",
"Sorologia Zika positiva",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Mielite",
criterios_exclusao: ["RM normal"],
achados_que_descartam: ["Ressonância magnética normal"],
},
],
examesIndicados: [
"Sorologia Zika",
"RM coluna/cérebro",
"ENMG",
"Punção lombar se indicado",
"Espirometria (avaliar insuficiência respiratória)",
],
conduta_esperada: {
imediata: [
"Internação",
"Monitorização respiratória",
"Espirometria",
],
curto_prazo: [
"Imunoglobulina IV ou plasmaférese",
"Suporte respiratório se necessário",
"Fisioterapia",
],
longo_prazo: [
"Reabilitação neurológica",
],
encaminhamentos: ["Neurologia", "Unidade de terapia intensiva"],
},
condutaCorreta: "Internação, ENMG urgente, imunoglobulina IV ou plasmaférese, monitorização respiratória",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: [
"Fraqueza ascendente",
"Envolvimento respiratório",
"Arreflexia",
],
descricao: "SGB com risco de insuficiência respiratória",
recomendacao: "Internação em unidade de terapia intensiva",
},
],
erros_criticos: [
{
erro: "Não investigar insuficiência respiratória",
descricao: "Risco de necessidade de intubação",
penalidade: 2,
evitavel: true,
},
{
erro: "Não solicitar ENMG",
descricao: "Confirmação diagnóstica necessária",
penalidade: 1.5,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu complicação neurológica",
realizado: false,
critico: true,
},
{
item: "Solicitou ENMG",
realizado: false,
critico: true,
},
{
item: "Avaliou respiração",
realizado: false,
critico: true,
},
{
item: "Encaminhou para neurologia",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de SGB",
peso: 30,
descricao: "Complicação de Zika",
pontuacao_maxima: 30,
},
{
criterio: "Urgência e investigação",
peso: 25,
descricao: "ENMG e monitorização respiratória",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Zika há 10 dias",
"Fraqueza ascendente",
"Dor nas costas",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Paralisia flácida",
"Arreflexia",
"Desmielinização em ENMG",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Zika com SGB",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Internação",
"ENMG urgente",
"Imunoglobulina ou plasmaférese",
"Monitorização respiratória",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu SGB",
"Solicitou ENMG",
"Avaliou respiração",
"Encaminhou neurologia",
],
erros_comuns: ["Confundir com paralisia central"],
orientacoes_pedagogicas: [
"SGB: paralisia flácida ascendente + arreflexia",
"Sempre avaliar respiração em SGB",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer complicação neurológica de Zika",
comunicacao: ["explicou necessidade de internação"],
anamnese: ["investigou progressão"],
exame_fisico: ["testou força e reflexos"],
exames_complementares: ["pediu ENMG"],
raciocinio: ["diagnosticou SGB"],
conduta: ["encaminhou neurologia"],
soap: ["documentou SGB"],
},
temaOSCE: "Arboviroses",
subtopicosOSCE: [
"Zika",
"Síndrome Guillain-Barré",
"Paralisia flácida",
"Complicação neurológica",
"Insuficiência respiratória",
],
diagnosticoCorreto: "Zika com Síndrome de Guillain-Barré",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("41"),
} as CasoOSCEV2;
