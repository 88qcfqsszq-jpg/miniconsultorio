import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso047PolicitemiaVera: CasoOSCEV2 = {
// ====== CASO 47: POLICITEMIA VERA ======
id: "47",
titulo: "Policitemia Vera",
sistema: "Hematologia",
tema: "Eritropoese",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 11,
objetivo_pedagogico: "Diagnosticar policitemia vera pelos achados clínicos",
dados_visiveis_ao_estudante: {
nome_paciente: "Marcelo Costa",
idade: 55,
sexo: "Masculino",
queixa_principal: "Rubor facial, coceira na pele após banho",
historia_breve: "Homem com face avermelhada, cianose de extremidades",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Policitemia Vera",
diagnosticos_diferenciais: ["Policitemia secundária", "Síndrome de Cushing", "Tumor renal"],
sindromes_associadas: ["Neoplasia mieloproliferativa"],
},
descricaoBreve: "Paciente com eritrocitose, rubor plétórico, esplenomegalia, risco tromboembólico",
categoria: "Mieloproliferação",
paciente: {
id: "pac-047",
nome: "Marcelo Costa",
idade: 55,
sexo: "M",
queixaPrincipal: "Rubor facial e coceira",
historicoDoenca: "Sintomas progressivos há 1 ano",
antecedentes: [],
profissao: "Advogado",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Minha face fica muito vermelha, coço muito o corpo depois do banho",
rubor: "Sim, rosto muito vermelho",
coceira: "Muita coceira, principalmente com água quente",
cianose: "Mãos e pés ficam azulados",
cefaleia: "Dores de cabeça frequentes",
tontura: "Tonto às vezes",
sangramento: "Facilidade para roxear",
},
respostaPaciente: {
inicial: "Rubor e coceira",
rubor: "Sim",
coceira: "Muito",
cianose: "Sim",
cefaleia: "Frequente",
tontura: "Sim",
sangramento: "Fácil",
},
sinais_vitais: {
corretos: {
pressaoArterial: "150/90 mmHg",
frequenciaCardiaca: 88,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "150/90 mmHg",
frequenciaCardiaca: 88,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 98,
},
exame_fisico: {
correto: {
inspecao: "Rubor plétórico facial, cianose de extremidades",
palpacao: "Esplenomegalia palpável",
ausculta: "Normal",
percussao: "Baço aumentado",
observacoes: "Sinais de policitemia",
regiao: "Geral",
achados_positivos: ["Rubor plétórico", "Esplenomegalia", "Cianose"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Rubor plétórico",
palpacao: "Esplenomegalia",
ausculta: "Normal",
percussao: "Baço aumentado",
observacoes: "Policitemia",
},
exame_fisico_interativo: {
geral: {
coloracao: "Plétora, rubor facial",
consciencia: "Alerta",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemograma",
descricao: "Série vermelha",
resultado: "Hb 18.5, Ht 56%, RBC 6.2 × 10⁶",
valor_referencia: "Hb 13.5-17.5, RBC 4.5-5.9",
interpretacao: "Eritrocitose",
},
{
nome: "Eritropoetina (EPO)",
descricao: "Nível sérico",
resultado: "2.5 mIU/mL",
valor_referencia: "4-26 mIU/mL",
interpretacao: "EPO baixa (típico de policitemia vera)",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Policitemia Vera",
probabilidade: 90,
criterios_minimos: [
"Eritrocitose",
"EPO baixa",
"Esplenomegalia",
"Rubor plétórico",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Policitemia secundária",
criterios_exclusao: ["EPO baixa"],
achados_que_descartam: ["EPO elevada"],
},
],
examesIndicados: [
"Hemograma completo",
"EPO sérica",
"Teste JAK2 V617F",
"Plaquetas e leucócitos",
],
conduta_esperada: {
imediata: [
"Flebotomia",
"Hidratação",
"Aspirina de baixa dose",
],
curto_prazo: [
"Controle hematológico",
"Avaliação de risco tromboembólico",
],
longo_prazo: [
"Monitorização contínua",
"Possível citorredutor",
],
encaminhamentos: ["Hematologia"],
},
condutaCorreta: "Hemograma, EPO, flebotomia, aspirina, hematologia para acompanhamento",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["Hb >18", "Esplenomegalia", "Risco tromboembólico"],
descricao: "Policitemia vera confirmada",
recomendacao: "Acompanhamento hematológico especializado",
},
],
erros_criticos: [
{
erro: "Não solicitar EPO",
descricao: "Diferencia vera de secundária",
penalidade: 1.5,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu policitemia",
realizado: false,
critico: true,
},
{
item: "Solicitou hemograma",
realizado: false,
critico: true,
},
{
item: "Pesquisou EPO",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de policitemia",
peso: 25,
descricao: "Achados clínicos",
pontuacao_maxima: 25,
},
{
criterio: "Diferenciação de secundária",
peso: 20,
descricao: "EPO baixa confirma vera",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Rubor facial",
"Coceira pós-banho",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Rubor plétórico",
"Esplenomegalia",
"Eritrocitose",
"EPO baixa",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Policitemia vera"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Flebotomia",
"EPO",
"JAK2",
"Hematologia",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu policitemia",
"Solicitou EPO",
"Pediu JAK2",
],
erros_comuns: ["Confundir com policitemia secundária"],
orientacoes_pedagogicas: [
"Policitemia vera: EPO baixa",
"Policitemia secundária: EPO elevada",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar policitemia vera",
comunicacao: ["explicou necessidade de flebotomia"],
anamnese: ["investigou rubor e coceira"],
exame_fisico: ["detectou esplenomegalia"],
exames_complementares: ["pediu EPO e JAK2"],
raciocinio: ["diagnosticou vera"],
conduta: ["prescreveu flebotomia"],
soap: ["documentou policitemia"],
},
temaOSCE: "Eritropoese",
subtopicosOSCE: [
"Policitemia vera",
"Eritrocitose",
"EPO baixa",
"Rubor plétórico",
"Esplenomegalia",
],
diagnosticoCorreto: "Policitemia Vera",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("47"),
} as CasoOSCEV2;
