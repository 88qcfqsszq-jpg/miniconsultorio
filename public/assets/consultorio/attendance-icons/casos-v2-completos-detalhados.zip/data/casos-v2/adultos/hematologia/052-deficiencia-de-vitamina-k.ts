import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso052DeficienciaDeVitaminaK: CasoOSCEV2 = {
// ====== CASO 52: DEFICIÊNCIA DE VITAMINA K ======
id: "52",
titulo: "Deficiência de Vitamina K",
sistema: "Hematologia",
tema: "Coagulopatias",
nivel: "iniciante",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Diagnosticar deficiência de vitamina K e institui reposição",
dados_visiveis_ao_estudante: {
nome_paciente: "Débora Mendes",
idade: 70,
sexo: "Feminino",
queixa_principal: "Equimoses fáceis, sangramento gengival",
historia_breve: "Mulher idosa com icterícia e problemas de coagulação",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Deficiência de Vitamina K",
diagnosticos_diferenciais: ["Hepatopatia", "Overdose de anticoagulante", "DIC"],
sindromes_associadas: ["Má absorção intestinal"],
},
descricaoBreve: "Paciente com sangramento, TP prolongado, TTPa normal, tempo de sangramento normal",
categoria: "Coagulopatias",
paciente: {
id: "pac-052",
nome: "Débora Mendes",
idade: 70,
sexo: "F",
queixaPrincipal: "Sangramento e equimoses",
historicoDoenca: "Diarreia crônica há meses",
antecedentes: ["Diarreia crônica", "Má absorção"],
profissao: "Aposentada",
estado_civil: "Viúva",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Tenho roxo fácil e sangramento na gengiva",
hematomas: "Sim, roxo muito fácil",
sangramento: "Gengivite, sangramento de pequenos ferimentos",
fezes: "Fezes soltas há muito tempo",
ictericia: "Um pouco de amarelão",
sangramento_GI: "Não notei",
abdome: "Sem dor, mas diarreia crônica",
},
respostaPaciente: {
inicial: "Hematomas e sangramento",
hematomas: "Fácil",
sangramento: "Gengival",
fezes: "Diarreia crônica",
ictericia: "Leve",
sangramento_GI: "Não",
abdome: "Diarreia",
},
sinais_vitais: {
corretos: {
pressaoArterial: "120/75 mmHg",
frequenciaCardiaca: 78,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "120/75 mmHg",
frequenciaCardiaca: 78,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 98,
},
exame_fisico: {
correto: {
inspecao: "Equimoses, icterícia leve, sangramento gengival",
palpacao: "Sem hepatomegalia, sem esplenomegalia",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Coagulopatia periférica",
regiao: "Geral",
achados_positivos: ["Equimoses", "Sangramento gengival", "Icterícia leve"],
achados_negativos: ["Hepatomegalia"],
},
},
exameFisicoCorreto: {
inspecao: "Equimoses, icterícia",
palpacao: "Sem hepatomegalia",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Deficiência de K",
},
exame_fisico_interativo: {
geral: {
coloracao: "Leve icterícia",
consciencia: "Alerta",
},
},
exames_complementares_disponiveis: [
{
nome: "TP",
descricao: "Tempo de protrombina",
resultado: "18 segundos",
valor_referencia: "11-13.5 segundos",
interpretacao: "Prolongado",
},
{
nome: "TTPa",
descricao: "Tempo de tromboplastina parcial ativada",
resultado: "32 segundos",
valor_referencia: "25-35 segundos",
interpretacao: "Normal",
},
{
nome: "INR",
descricao: "International Normalized Ratio",
resultado: "1.8",
valor_referencia: "<1.1",
interpretacao: "Prolongado",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Deficiência de Vitamina K",
probabilidade: 90,
criterios_minimos: [
"TP prolongado",
"TTPa normal",
"INR elevado",
"Diarreia crônica",
"Resposta a vitamina K",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Hepatopatia",
criterios_exclusao: ["Sem hepatomegalia", "TTPa normal"],
achados_que_descartam: ["Sem liver disease"],
},
],
examesIndicados: [
"TP, TTPa, PT",
"INR",
"Testes de função hepática se suspeita de hepatopatia",
],
conduta_esperada: {
imediata: [
"Vitamina K1 oral ou IV",
"Investigação de diarreia",
],
curto_prazo: [
"Repetição de TP em 24-48h",
"Avaliação de causa de má absorção",
],
longo_prazo: [
"Suplementação contínua",
],
encaminhamentos: ["Hematologia", "Gastroenterologia"],
},
condutaCorreta: "TP/TTPa/INR, vitamina K1 IV, investigação de diarreia, repetir TP 24-48h",
criterios_de_gravidade: [
{
severidade: "leve",
sinais: ["TP prolongado", "INR <2.5"],
descricao: "Deficiência moderada de vitamina K",
recomendacao: "Reposição oral",
},
],
erros_criticos: [
{
erro: "Não investigar diarreia",
descricao: "Causa de deficiência de K",
penalidade: 1,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu deficiência de K",
realizado: false,
critico: true,
},
{
item: "Solicitou TP e INR",
realizado: false,
critico: true,
},
{
item: "Prescreveu vitamina K",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de deficiência de K",
peso: 25,
descricao: "TP prolongado com TTPa normal",
pontuacao_maxima: 25,
},
{
criterio: "Tratamento apropriado",
peso: 20,
descricao: "Vitamina K",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Hematomas",
"Diarreia crônica",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Equimoses",
"TP prolongado",
"INR elevado",
"TTPa normal",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Deficiência de vitamina K"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Vitamina K1",
"Investigação de diarreia",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu deficiência de K",
"Solicitou TP/INR",
"Prescreveu vitamina K",
],
erros_comuns: ["Confundir com hepatopatia"],
orientacoes_pedagogicas: [
"Deficiência K: TP prolongado com TTPa normal",
"Hepatopatia: TP e TTPa prolongados",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar e repor vitamina K",
comunicacao: ["explicou causa da diarreia"],
anamnese: ["investigou diarreia"],
exame_fisico: ["detectou sangramento"],
exames_complementares: ["pediu TP/INR"],
raciocinio: ["diagnosticou deficiência K"],
conduta: ["prescreveu vitamina K"],
soap: ["documentou deficiência"],
},
temaOSCE: "Coagulopatias",
subtopicosOSCE: [
"Deficiência de vitamina K",
"TP prolongado",
"INR elevado",
"Diarreia crônica",
"Má absorção",
],
diagnosticoCorreto: "Deficiência de Vitamina K",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("52"),
} as CasoOSCEV2;
