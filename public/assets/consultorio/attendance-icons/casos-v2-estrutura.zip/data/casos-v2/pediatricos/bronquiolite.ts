import { CasoOSCEV2 } from "@/types/caso-osce-v2";

export const casoBronquiolite: CasoOSCEV2 = {} as CasoOSCEV2;
