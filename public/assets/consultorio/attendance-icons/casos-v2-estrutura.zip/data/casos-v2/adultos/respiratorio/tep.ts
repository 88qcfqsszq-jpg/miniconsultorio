import { CasoOSCEV2 } from "@/types/caso-osce-v2";

export const casoTEP: CasoOSCEV2 = {} as CasoOSCEV2;
