# Trilha Gastro/Abdome — Icterícia

## Objetivo da trilha

Ensinar bilirrubina, colestase, hepatite e obstrução biliar com foco em base, semiologia e raciocínio clínico, preparando o aluno para reconhecer padrões, avaliar gravidade e transferir o aprendizado para OSCE.

A trilha deve sempre conectar três camadas:

```text
conceito de base → manifestação clínica → decisão no atendimento
```

O aluno não deve terminar a trilha apenas decorando nomes. Ele deve conseguir olhar para um paciente, reconhecer padrões, explicar o mecanismo provável e decidir o próximo passo com segurança proporcional ao nível de formação.

---

## Competências ao final

O aluno deve conseguir:

1. Explicar os conceitos centrais de icterícia.
2. Reconhecer achados semiológicos relevantes.
3. Separar apresentações leves de sinais de gravidade.
4. Construir hipóteses por mecanismo.
5. Aplicar o raciocínio em mini-casos.

---

# 1. Microaula — Ideia central

Icterícia é uma trilha de integração entre conhecimento de base e decisão clínica. O aluno deve entender o mecanismo antes de decorar condutas.

## Conceitos obrigatórios

- **Icterícia**: Icterícia é uma trilha de integração entre conhecimento de base e decisão clínica. O aluno deve entender o mecanismo antes de decorar condutas.
- **Gravidade**: A primeira pergunta em qualquer atendimento é se o paciente está instável ou possui sinal de alarme.
- **Transferência**: O conteúdo deve ser aplicado em mini-casos e depois levado ao OSCE.

## Frase didática

```text
Icterícia: não é uma lista de sinais; é um padrão clínico que precisa ser explicado por mecanismo.
```

---

# 2. Fisiologia / fisiopatologia aplicada

## 1. Mecanismo principal

Em icterícia, o aluno deve identificar o mecanismo dominante e como ele aparece no paciente.

```text
mecanismo → sinal/sintoma → hipótese → decisão
```

## 2. Semiologia aplicada

Os sinais não são decorados isoladamente: cada achado deve responder a uma pergunta clínica.

```text
observação → interpretação → conduta
```

## 3. Risco e priorização

Sinais de alarme mudam a ordem do atendimento e podem exigir ação antes de investigação completa.

```text
red flag → estabilizar/encaminhar → investigar
```

---

# 3. Semiologia essencial

O aluno deve aprender a observar antes de decorar conduta.

## Achados que precisam ser procurados

- Sinais vitais e estado geral.
- Início, duração e progressão.
- Fatores precipitantes e antecedentes.
- Exame físico direcionado.
- Sinais de alarme.
- Impacto funcional.
- Resposta a medidas iniciais.

## Sinais de alarme

- Instabilidade hemodinâmica.
- Alteração de consciência.
- Dor intensa ou progressiva.
- Sinais neurológicos focais quando aplicável.

---

# 4. Raciocínio clínico

A pergunta-guia desta trilha é:

```text
Qual mecanismo explica melhor o conjunto de sintomas, sinais e dados objetivos?
```

O raciocínio deve seguir:

```text
1. reconhecer a síndrome;
2. avaliar gravidade;
3. formular hipóteses por mecanismo;
4. procurar achados que confirmem ou afastem hipóteses;
5. escolher exames que mudam conduta;
6. iniciar medidas prioritárias quando houver risco.
```

## Erros comuns

- Pular sinais vitais.
- Pedir exames sem hipótese.
- Não reavaliar.

---

# 5. Mini-casos

## Mini-caso 1 — Hepatite

### Cenário
Paciente com apresentação típica relacionada a hepatite, exigindo que o aluno conecte queixa, sinais vitais e exame físico.

### Mecanismo principal
Mecanismo dominante de hepatite dentro da trilha icterícia.

```text
queixa → achados → mecanismo → decisão
```

### Achados-chave
- queixa principal
- sinal objetivo
- achado de exame
- contexto clínico

### Pergunta central
Qual mecanismo explica hepatite?

### Resposta esperada
O aluno deve identificar o mecanismo provável, sinais de gravidade e próximo passo seguro.

### Erro comum
Decorar o diagnóstico sem justificar por sinais e mecanismos.

### Ponte para OSCE
Treinar atendimento dirigido e feedback no MEDIX OSCE.
## Mini-caso 2 — Coledocolitíase

### Cenário
Paciente com apresentação típica relacionada a coledocolitíase, exigindo que o aluno conecte queixa, sinais vitais e exame físico.

### Mecanismo principal
Mecanismo dominante de coledocolitíase dentro da trilha icterícia.

```text
queixa → achados → mecanismo → decisão
```

### Achados-chave
- queixa principal
- sinal objetivo
- achado de exame
- contexto clínico

### Pergunta central
Qual mecanismo explica coledocolitíase?

### Resposta esperada
O aluno deve identificar o mecanismo provável, sinais de gravidade e próximo passo seguro.

### Erro comum
Decorar o diagnóstico sem justificar por sinais e mecanismos.

### Ponte para OSCE
Treinar atendimento dirigido e feedback no MEDIX OSCE.
## Mini-caso 3 — Hemólise

### Cenário
Paciente com apresentação típica relacionada a hemólise, exigindo que o aluno conecte queixa, sinais vitais e exame físico.

### Mecanismo principal
Mecanismo dominante de hemólise dentro da trilha icterícia.

```text
queixa → achados → mecanismo → decisão
```

### Achados-chave
- queixa principal
- sinal objetivo
- achado de exame
- contexto clínico

### Pergunta central
Qual mecanismo explica hemólise?

### Resposta esperada
O aluno deve identificar o mecanismo provável, sinais de gravidade e próximo passo seguro.

### Erro comum
Decorar o diagnóstico sem justificar por sinais e mecanismos.

### Ponte para OSCE
Treinar atendimento dirigido e feedback no MEDIX OSCE.
## Mini-caso 4 — Colangite

### Cenário
Paciente com apresentação típica relacionada a colangite, exigindo que o aluno conecte queixa, sinais vitais e exame físico.

### Mecanismo principal
Mecanismo dominante de colangite dentro da trilha icterícia.

```text
queixa → achados → mecanismo → decisão
```

### Achados-chave
- queixa principal
- sinal objetivo
- achado de exame
- contexto clínico

### Pergunta central
Qual mecanismo explica colangite?

### Resposta esperada
O aluno deve identificar o mecanismo provável, sinais de gravidade e próximo passo seguro.

### Erro comum
Decorar o diagnóstico sem justificar por sinais e mecanismos.

### Ponte para OSCE
Treinar atendimento dirigido e feedback no MEDIX OSCE.

---

# 6. Questões ativas

## Questão ativa 1

**Pergunta:** Qual é a primeira pergunta diante de icterícia?

**Resposta esperada:** Há instabilidade ou sinal de alarme que muda a prioridade?

**Por que importa:** Segurança antes de diagnóstico definitivo.
## Questão ativa 2

**Pergunta:** Como evitar decorar listas?

**Resposta esperada:** Explicando cada achado por mecanismo e aplicando em mini-casos.

**Por que importa:** Forma raciocínio clínico.
## Questão ativa 3

**Pergunta:** Quando exames entram?

**Resposta esperada:** Quando ajudam a confirmar hipótese ou mudam conduta, sem atrasar medida prioritária.

**Por que importa:** Evita investigação inútil.

---

# 7. Mapa final

```text
ICTERÍCIA
├── conceito de base
├── semiologia
├── gravidade
├── mini-casos
└── ponte para OSCE
```

---

# 8. Ponte para OSCE

## MEDIX OSCE Ciclo Básico

O aluno deve treinar:

- perguntas dirigidas
- exame físico focal
- diagnóstico sindrômico
- conduta inicial
- comunicação

## MEDIX OSCE Clínico

No módulo clínico, essa trilha pode ser aprofundada com:

- evolução temporal dos sinais vitais;
- resposta a intervenção;
- piora por atraso terapêutico;
- comparação entre o raciocínio MEDIX e a fisiologia dinâmica.

---

# 9. Checklist de curadoria

- [ ] A trilha ensina mecanismo, e não apenas definição?
- [ ] Há conexão explícita entre fisiologia e semiologia?
- [ ] Os mini-casos cobrem apresentações diferentes?
- [ ] Existem erros comuns bem destacados?
- [ ] O aluno consegue transferir o conteúdo para um atendimento OSCE?
- [ ] A linguagem é adequada para estudante em formação?
- [ ] Há alerta para situações em que atraso terapêutico é perigoso?
