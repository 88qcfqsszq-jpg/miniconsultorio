import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso040FebreAmarela: CasoOSCEV2 = {
// ====== CASO 40: FEBRE AMARELA ======
id: "40",
titulo: "Febre Amarela",
sistema: "Infectologia",
tema: "Arboviroses",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Diagnosticar febre amarela e reconhecer sinais de gravidade",
dados_visiveis_ao_estudante: {
nome_paciente: "Roberto Silva",
idade: 45,
sexo: "Masculino",
queixa_principal: "Febre alta, vômito com sangue, dor abdominal intensa",
historia_breve: "Viajou para Amazônia, febre iniciou 5 dias atrás, piorou muito",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Febre Amarela",
diagnosticos_diferenciais: ["Dengue grave", "Malária", "Hepatite viral"],
sindromes_associadas: ["Insuficiência Hepática Fulminante"],
},
descricaoBreve: "Paciente com febre bifásica, hematemese, icterícia progressiva, sinais de insuficiência hepática",
categoria: "Arboviroses",
paciente: {
id: "pac-040",
nome: "Roberto Silva",
idade: 45,
sexo: "M",
queixaPrincipal: "Febre, vômito com sangue",
historicoDoenca: "Viagem à Amazônia 10 dias atrás",
antecedentes: ["Viagem a área de febre amarela", "Não vacinado"],
profissao: "Pesquisador",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Tive febre muito alta, melhorou 1 dia, agora voltou pior",
febre: "Febre bifásica, voltou com muito calafrio",
vomito: "Sim, vomitei sangue, muito assustador",
dor_abdominal: "Dor muito intensa em todo abdome",
ictericia: "Fiquei amarelado",
sangramento: "Vômito com sangue, possível melena",
confusao: "Tô muito confuso, desorientado",
},
respostaPaciente: {
inicial: "Febre bifásica e vômito com sangue",
febre: "Bifásica",
vomito: "Sim, com sangue",
dor_abdominal: "Muito intensa",
ictericia: "Sim",
sangramento: "Hematemese",
confusao: "Sim",
},
sinais_vitais: {
corretos: {
pressaoArterial: "90/55 mmHg",
frequenciaCardiaca: 125,
frequenciaRespiratoria: 20,
temperatura: 40.2,
saturacaoOxigenio: 96,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "90/55 mmHg",
frequenciaCardiaca: 125,
frequenciaRespiratoria: 20,
temperatura: 40.2,
saturacaoOxigenio: 96,
},
exame_fisico: {
correto: {
inspecao: "Paciente febril, ictérico, bradicardia relativa, petéquias",
palpacao: "Hepatomegalia intensa 5cm, baço palpável, abdome rígido",
ausculta: "Murmúrio vesicular reduzido, sopro hemodinâmico",
percussao: "Macicez em flancos (ascite)",
observacoes: "Sinais de insuficiência hepática, coagulação e choque",
regiao: "Geral",
achados_positivos: ["Icterícia", "Hepatomegalia", "Petéquias", "Bradicardia relativa"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Ictérico, petéquias, bradicardia relativa",
palpacao: "Hepatomegalia 5cm, ascite",
ausculta: "MV reduzido",
percussao: "Macicez",
observacoes: "Insuficiência hepática grave",
},
exame_fisico_interativo: {
geral: {
coloracao: "Ictérico com petéquias múltiplas",
facies: "Ictérica intensamente",
},
abdominal: {
visceromegalias: "Hepatomegalia grau IV",
inspecao: "Ascite presente",
defesa: "Rigidez abdominal presente",
},
},
exames_complementares_disponiveis: [
{
nome: "Transaminases",
descricao: "ALT e AST",
resultado: "ALT 2800 U/L, AST 3200 U/L",
valor_referencia: "<40 U/L",
interpretacao: "Hepatite fulminante",
},
{
nome: "Bilirrubina total",
descricao: "Bilirrubina",
resultado: "12 mg/dL",
valor_referencia: "<1.2 mg/dL",
interpretacao: "Icterícia grave",
},
{
nome: "INR",
descricao: "Índice de normalizado internacional",
resultado: "4.5",
valor_referencia: "<1.1",
interpretacao: "Coagulopatia grave",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Febre Amarela",
probabilidade: 95,
criterios_minimos: [
"Viagem a área endêmica",
"Febre bifásica",
"Hepatomegalia acentuada",
"Icterícia progressiva",
"Hemorrágias",
"Transaminases muito elevadas",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Hepatite viral fulminante",
criterios_exclusao: ["Viagem a área de febre amarela"],
achados_que_descartam: ["Histórico epidemiológico"],
},
],
examesIndicados: [
"Sorologia febre amarela (IgM, IgG)",
"PCR para febre amarela",
"Hemograma completo",
"Testes de coagulação",
"Função hepática seriada",
],
conduta_esperada: {
imediata: [
"Encaminhar para CTI/Hospital terciário URGENTEMENTE",
"Internação em unidade de terapia intensiva",
"Suporte hemodinâmico",
],
curto_prazo: [
"Monitorização invasiva",
"Transfusão se necessário",
"Manejo de coagulopatia",
],
longo_prazo: [
"Suporte de órgão",
"Possível transplante hepático",
],
encaminhamentos: ["CTI", "Hepatologia"],
},
condutaCorreta: "CTI urgente, suporte hemodinâmico e respiratório, manejo de coagulopatia, hepatologia urgente",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: [
"Icterícia",
"Coagulopatia",
"Choque",
"ALT/AST >1000",
],
descricao: "Insuficiência hepática fulminante com risco de morte",
recomendacao: "CTI e transplante hepático de emergência",
},
],
erros_criticos: [
{
erro: "Não encaminhar para CTI",
descricao: "Mortalidade >50% sem manejo intensivo",
penalidade: 3,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu febre amarela",
realizado: false,
critico: true,
},
{
item: "Identificou insuficiência hepática",
realizado: false,
critico: true,
},
{
item: "Encaminhou para CTI",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de febre amarela",
peso: 30,
descricao: "Quadro clínico e epidemiologia",
pontuacao_maxima: 30,
},
{
criterio: "Urgência e conduta",
peso: 25,
descricao: "CTI imediato",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Febre bifásica",
"Viagem à Amazônia",
"Hemorrágias",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Icterícia",
"Hepatomegalia acentuada",
"Transaminases muito elevadas",
"Coagulopatia",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Febre amarela",
"Insuficiência hepática fulminante",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"CTI urgente",
"Sorologia febre amarela",
"Suporte hemodinâmico",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu febre amarela",
"Identificou insuficiência hepática",
"Encaminhou para CTI",
],
erros_comuns: ["Confundir com dengue grave"],
orientacoes_pedagogicas: [
"Febre amarela: febre bifásica + icterícia progressiva + hepatomegalia",
"Sempre perguntar sobre viagens a área de risco",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer febre amarela como emergência máxima",
comunicacao: ["explicou gravidade"],
anamnese: ["investigou viagens"],
exame_fisico: ["detectou icterícia e hepatomegalia"],
exames_complementares: ["pediu sorologias"],
raciocinio: ["diagnosticou febre amarela"],
conduta: ["encaminhou CTI"],
soap: ["documentou emergência"],
},
temaOSCE: "Arboviroses",
subtopicosOSCE: [
"Febre amarela",
"Icterícia",
"Insuficiência hepática",
"Coagulopatia",
"Emergência máxima",
],
diagnosticoCorreto: "Febre Amarela",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("40"),
} as CasoOSCEV2;
