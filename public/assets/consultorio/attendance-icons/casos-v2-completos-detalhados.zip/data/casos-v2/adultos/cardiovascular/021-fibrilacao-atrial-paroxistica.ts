import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso021FibrilacaoAtrialParoxistica: CasoOSCEV2 = {
// ====== CASO 21: FIBRILAÇÃO ATRIAL ======
id: "21",
titulo: "Fibrilação Atrial Paroxística",
sistema: "Cardiovascular",
tema: "Arritmia",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Reconhecer fibrilação atrial, avaliar urgência, controlar frequência e considerar anticoagulação",
dados_visiveis_ao_estudante: {
nome_paciente: "Valter Pereira",
idade: 68,
sexo: "Masculino",
queixa_principal: "Palpitações e falta de ar",
historia_breve: "Começou há 2 horas com sensação de batidas aceleradas irregulares, dispneia leve",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Fibrilação Atrial Paroxística com resposta ventricular rápida",
diagnosticos_diferenciais: ["Taquicardia supraventricular", "Flutter atrial", "Taquicardia sinusal"],
sindromes_associadas: ["Arritmia supraventricular"],
},
descricaoBreve: "Paciente com pulso irregularmente irregular, ECG sem onda P organizada, fibrilação atrial de resposta rápida",
categoria: "Arritmia",
paciente: {
id: "pac-021",
nome: "Valter Pereira",
idade: 68,
sexo: "M",
queixaPrincipal: "Palpitações",
historicoDoenca: "Primeiro episódio de palpitações, paciente com HAS há anos",
antecedentes: ["HAS", "Obesidade", "Ronco"],
profissao: "Comerciante",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: ["Losartana 50mg", "Sinvastatina 20mg"],
},
respostas_do_paciente: {
inicial: "Tô sentindo meu coração batendo acelerado e irregular",
palpitacoes: "Sim, sinto como se pulasse batidas, muito desagradável",
duracao: "Começou há umas 2 horas de repente",
respiracao: "Sim, um pouco de falta de ar",
tontura: "Um pouco, tô leve",
dor_peito: "Não, mas incômodo no peito por causa da taquicardia",
sincope: "Não, mas tive pavor",
gatilho: "Não fiz nada diferente, começou do nada",
},
respostaPaciente: {
inicial: "Tô sentindo meu coração acelerado",
palpitacoes: "Sim, irregular",
duracao: "2 horas",
respiracao: "Sim, um pouco",
tontura: "Um pouco",
dor_peito: "Não",
sincope: "Não",
gatilho: "Do nada",
},
sinais_vitais: {
corretos: {
pressaoArterial: "145/88 mmHg",
frequenciaCardiaca: 118,
frequenciaRespiratoria: 20,
temperatura: 36.8,
saturacaoOxigenio: 95,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "145/88 mmHg",
frequenciaCardiaca: 118,
frequenciaRespiratoria: 20,
temperatura: 36.8,
saturacaoOxigenio: 95,
},
exame_fisico: {
correto: {
inspecao: "Paciente ansioso, leve diaforese",
palpacao: "Pulso irregularmente irregular, amplitude variável, frequência 110-120",
ausculta: "Ritmo completamente irregular, sem sopros ou murmúrios adicionais",
percussao: "Normal",
observacoes: "Achados compatíveis com fibrilação atrial de resposta rápida",
regiao: "Precórdio",
achados_positivos: ["Pulso irregularmente irregular"],
achados_negativos: ["Sopros", "Murmúrios"],
},
},
exameFisicoCorreto: {
inspecao: "Ansioso",
palpacao: "Pulso irregularmente irregular",
ausculta: "Ritmo completamente irregular",
percussao: "Normal",
observacoes: "Fibrilação atrial evidente",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Ansioso, leve diaforese",
consciencia: "Lúcido e orientado",
},
cardiovascular: {
inspecao_precordial: "Sem alterações estruturais",
ausculta_cardiaca: "Ritmo completamente irregular, FC média 118 bpm, amplitude de bulhas variável, sem sopros",
pulsos: "Pulso apical >pulso radial (pulso deficitário), movimento irregular",
turgencia_jugular: "Normal",
edema: "Ausente",
},
},
exames_complementares_disponiveis: [
{
nome: "ECG (Eletrocardiograma)",
descricao: "12 derivações",
resultado: "Ausência de onda P organizada; ondas f de fibrilação em linha de base; ritmo ventricular irregular, FC média 110-120",
valor_referencia: "Ritmo sinusal regular com onda P",
interpretacao: "Fibrilação atrial com resposta ventricular rápida",
},
{
nome: "Troponina I",
descricao: "Biomarcador cardíaco",
resultado: "<0.04 ng/mL",
valor_referencia: "<0.04 ng/mL",
interpretacao: "Normal - sem infarto associado",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Fibrilação Atrial",
probabilidade: 95,
criterios_minimos: [
"Pulso irregularmente irregular",
"Ausência de onda P no ECG",
"Ritmo ventricular irregular",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Flutter atrial",
criterios_exclusao: ["Pulso completamente irregular"],
achados_que_descartam: ["Ritmo geralmente mais regular"],
},
],
examesIndicados: [
"ECG",
"Troponina",
"TSH",
"Eletrólitos",
"Hemograma",
"Função renal",
"Ecocardiograma conforme risco",
],
conduta_esperada: {
imediata: [
"Monitorização cardíaca contínua",
"Acesso venoso",
"Avaliar estabilidade hemodinâmica",
"Oxigenioterapia se SpO2 <90%",
"Controle de frequência com beta-bloqueador IV ou digoxina",
"Avaliar risco tromboembólico (CHA2DS2-VASc)",
],
curto_prazo: [
"Internação para monitorização",
"Estratificação de risco para AVC",
"Avaliação de causa desencadeante",
"Possível cardioversão elétrica se instável",
],
longo_prazo: [
"Anticoagulação conforme risco (CHA2DS2-VASc ≥2 em homens, ≥3 em mulheres)",
"Controle de frequência crônico",
"Investigação e tratamento de causa subjacente",
"Possível ablação se recorrências",
],
encaminhamentos: ["Cardiologia"],
},
condutaCorreta: "Controle de frequência com beta-bloqueador, avaliar risco de AVC, iniciar anticoagulação conforme CHA2DS2-VASc",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["FC >120", "Dispneia", "Tontura"],
descricao: "FA de resposta rápida com sintomas",
recomendacao: "Controle de frequência urgente, monitorização",
},
],
erros_criticos: [
{
erro: "Não reconhecer fibrilação atrial",
descricao: "Erro diagnóstico fundamental",
penalidade: 2,
evitavel: true,
},
{
erro: "Não anticoagular quando indicado",
descricao: "Risco altíssimo de AVC",
penalidade: 3,
evitavel: true,
},
{
erro: "Não controlar frequência cardíaca",
descricao: "FC rápida pode precipitar IC",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu fibrilação atrial no exame físico",
realizado: false,
critico: true,
},
{
item: "Solicitou ECG",
realizado: false,
critico: true,
},
{
item: "Interpretou ECG corretamente",
realizado: false,
critico: true,
},
{
item: "Iniciou controle de frequência",
realizado: false,
critico: true,
},
{
item: "Calculou CHA2DS2-VASc para avaliar risco de AVC",
realizado: false,
critico: true,
},
{
item: "Indicou anticoagulação apropriadamente",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de FA",
peso: 25,
descricao: "Achados clínicos e ECG",
pontuacao_maxima: 25,
},
{
criterio: "Controle de frequência",
peso: 20,
descricao: "Beta-bloqueador ou digoxina apropriados",
pontuacao_maxima: 20,
},
{
criterio: "Anticoagulação",
peso: 30,
descricao: "Avaliação de risco e prescrição apropriada",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Palpitações",
"Duração do episódio",
"Sintomas associados",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Pulso irregularmente irregular",
"ECG com ondas f",
"Ausência de onda P",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Fibrilação atrial",
"CHA2DS2-VASc score",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Controle de frequência",
"Anticoagulação conforme risco",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu FA no exame físico",
"Solicitou ECG",
"Iniciou controle de frequência",
"Avaliou risco de AVC",
"Prescreveu anticoagulação",
],
erros_comuns: [
"Confundir com taquicardia sinusal",
"Atrasar anticoagulação",
"Não considerar causas desencadeantes",
],
orientacoes_pedagogicas: [
"FA: pulso irregularmente irregular + ECG sem onda P = diagnóstico certo",
"CHA2DS2-VASc ≥2 em homens = anticoagular obrigatoriamente",
"Controle de frequência com beta-bloqueador ou digoxina",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer FA, iniciar controle de frequência, avaliar risco de AVC e prescrever anticoagulação apropriada",
comunicacao: [
"explicou o diagnóstico",
"tranquilizou o paciente",
"explicou importância de anticoagulação",
],
anamnese: [
"investigou duração de sintomas",
"perguntou sobre antecedentes",
"investigou fatores de risco para AVC",
],
exame_fisico: [
"detectou pulso irregularmente irregular",
"reconheceu FA clinicamente",
],
exames_complementares: [
"solicitou ECG urgente",
"interpretou corretamente",
],
raciocinio: [
"diagnosticou FA",
"calculou CHA2DS2-VASc",
],
conduta: [
"iniciou beta-bloqueador",
"prescreveu anticoagulante apropriado",
],
soap: [
"documentou palpitações e duração",
"registrou achados de FA",
"planejou anticoagulação",
],
},
temaOSCE: "Arritmias",
subtopicosOSCE: [
"Fibrilação atrial",
"Pulso irregularmente irregular",
"ECG sem onda P",
"Controle de frequência",
"Prevenção de AVC",
"Anticoagulação",
],
diagnosticoCorreto: "Fibrilação Atrial Paroxística",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("21"),
} as CasoOSCEV2;
