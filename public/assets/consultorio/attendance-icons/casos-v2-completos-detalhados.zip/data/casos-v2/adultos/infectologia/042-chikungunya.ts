import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso042Chikungunya: CasoOSCEV2 = {
// ====== CASO 42: CHIKUNGUNYA ======
id: "42",
titulo: "Chikungunya",
sistema: "Infectologia",
tema: "Arboviroses",
nivel: "iniciante",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Diagnosticar Chikungunya e diferenciar de Dengue",
dados_visiveis_ao_estudante: {
nome_paciente: "Juliana Ferreira",
idade: 35,
sexo: "Feminino",
queixa_principal: "Dor nas articulações muito intensa, febre",
historia_breve: "Febre há 2 dias com dor articular extremamente intensa, principalmente nas mãos",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Chikungunya",
diagnosticos_diferenciais: ["Dengue", "Artrite reumatoide", "Lúpus"],
sindromes_associadas: ["Poliartralgias persistentes"],
},
descricaoBreve: "Paciente com febre, exantema e dor articular debilitante, particularmente em pequenas articulações",
categoria: "Arboviroses",
paciente: {
id: "pac-042",
nome: "Juliana Ferreira",
idade: 35,
sexo: "F",
queixaPrincipal: "Dor articular intensa",
historicoDoenca: "Febre e dor há 2 dias",
antecedentes: ["Vive em área com Chikungunya"],
profissao: "Professora",
estado_civil: "Solteira",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Tenho febre e uma dor nas articulações que não consigo fazer nada",
febre: "Sim, febre moderada",
dor_articular: "Dor muito intensa, principalmente nas mãos, pés, joelhos",
exantema: "Sim, exantema pequenino",
edema_articular: "Sim, inchação nas mãos",
movimento: "Não consigo fazer nada, dói demais ao mexer",
duracao_esperada: "Há 2 dias",
},
respostaPaciente: {
inicial: "Dor articular intensa e febre",
febre: "Sim",
dor_articular: "Muito intensa",
exantema: "Sim",
edema_articular: "Sim",
movimento: "Movimento limitado",
duracao_esperada: "2 dias",
},
sinais_vitais: {
corretos: {
pressaoArterial: "120/75 mmHg",
frequenciaCardiaca: 88,
frequenciaRespiratoria: 16,
temperatura: 38.5,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "120/75 mmHg",
frequenciaCardiaca: 88,
frequenciaRespiratoria: 16,
temperatura: 38.5,
saturacaoOxigenio: 98,
},
exame_fisico: {
correto: {
inspecao: "Paciente febril, exantema maculopapular fino, edema em mãos",
palpacao: "Edema simétrico em articulações de mãos, pés e joelhos, dor importante",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Poliartrite simétrica de pequenas articulações",
regiao: "Articulações",
achados_positivos: ["Febre", "Exantema", "Poliartrite", "Edema"],
achados_negativos: ["Hepatomegalia"],
},
},
exameFisicoCorreto: {
inspecao: "Febril, exantema fino, edema articular",
palpacao: "Poliartrite simétrica",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Dor articular debilitante",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Incapacitado pela dor",
coloracao: "Maculopapular fino",
},
membros: {
edema: "Mãos, pés, joelhos com muita dor",
mobilidade: "Movimento muito limitado por dor",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemograma",
descricao: "Contagem de células",
resultado: "Hb 13, Leucócitos 6.500, Plaquetas 180.000",
valor_referencia: "Plaquetas >150.000",
interpretacao: "Sem alterações hematológicas",
},
{
nome: "Sorologia Chikungunya IgM",
descricao: "Anticorpo IgM anti-Chikungunya",
resultado: "Positivo",
valor_referencia: "Negativo",
interpretacao: "Infecção recente por Chikungunya",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Chikungunya",
probabilidade: 92,
criterios_minimos: [
"Febre",
"Poliartrite simétrica",
"Dor articular debilitante",
"Exantema",
"IgM Chikungunya positivo",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Dengue",
criterios_exclusao: ["Dor articular tão intensa", "Poliartrite"],
achados_que_descartam: ["IgM Chikungunya positivo"],
},
],
examesIndicados: [
"Sorologia Chikungunya (IgM/IgG)",
"Hemograma",
"Se dúvida: sorologia dengue",
],
conduta_esperada: {
imediata: [
"Repouso",
"Analgesia (paracetamol ou ibuprofeno)",
"Hidratação",
],
curto_prazo: [
"Fisioterapia se dor persistir",
"Educação sobre prognóstico",
],
longo_prazo: [
"Suporte para artralgia crônica",
],
encaminhamentos: ["Acompanhamento clínico"],
},
condutaCorreta: "Analgesia, hidratação, repouso, sorologia Chikungunya, educação sobre evolução",
criterios_de_gravidade: [
{
severidade: "leve",
sinais: ["Febre", "Artrite", "Sem manifestações hemorrágicas"],
descricao: "Chikungunya sem complicações",
recomendacao: "Manejo ambulatorial com suporte",
},
],
erros_criticos: [
{
erro: "Não solicitar sorologia Chikungunya",
descricao: "Confirmação diagnóstica",
penalidade: 1,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu Chikungunya",
realizado: false,
critico: true,
},
{
item: "Diferenciou de Dengue",
realizado: false,
critico: true,
},
{
item: "Solicitou sorologia",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de Chikungunya",
peso: 25,
descricao: "Dor articular debilitante",
pontuacao_maxima: 25,
},
{
criterio: "Diferenciação diagnóstica",
peso: 20,
descricao: "Dengue vs Chikungunya",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Febre",
"Dor articular intensa",
"Início há 2 dias",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Poliartrite simétrica",
"Edema articular",
"Exantema",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Chikungunya"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Sorologia Chikungunya",
"Analgesia",
"Repouso",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu Chikungunya",
"Diferenciou de Dengue",
"Solicitou sorologia",
],
erros_comuns: ["Achar que é Dengue"],
orientacoes_pedagogicas: [
"Chikungunya: dor articular MUITO intensa, incapacitante",
"Dengue: dor muscular predomina",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer Chikungunya e diferenciar de Dengue",
comunicacao: ["explicou prognóstico"],
anamnese: ["investigou intensidade de dor"],
exame_fisico: ["detectou poliartrite"],
exames_complementares: ["pediu sorologia"],
raciocinio: ["diagnosticou Chikungunya"],
conduta: ["prescreveu analgesia"],
soap: ["documentou Chikungunya"],
},
temaOSCE: "Arboviroses",
subtopicosOSCE: [
"Chikungunya",
"Poliartrite",
"Artralgia",
"Febre",
"Diferenciação",
],
diagnosticoCorreto: "Chikungunya",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("42"),
} as CasoOSCEV2;
