# MEDIX Learn — Respiratório

## Objetivo do módulo

Ensinar o aluno a conectar fisiologia respiratória, semiologia e raciocínio clínico.

O aluno deve sair do módulo Respiratório entendendo:

- por que o paciente sente falta de ar;
- por que a saturação cai;
- como diferenciar obstrução, infecção, embolia, colapso pulmonar e congestão;
- como interpretar achados do exame físico respiratório;
- quando oxigênio é suficiente e quando não é;
- quando a situação é grave e exige ação imediata.

## Trilhas do módulo

```text
Respiratório
├── Hipoxemia
├── Dispneia
├── Sibilância e broncoespasmo
├── Tosse e febre
├── Dor torácica pleurítica
├── Exame físico respiratório
└── Gasometria básica
```

## Ordem pedagógica recomendada

1. **Hipoxemia** — base fisiológica da saturação e mecanismos de queda.
2. **Dispneia** — síndrome central do respiratório.
3. **Exame físico respiratório** — transformar achado em hipótese.
4. **Sibilância e broncoespasmo** — asma/DPOC e obstrução.
5. **Tosse e febre** — infecção respiratória.
6. **Dor torácica pleurítica** — TEP, pneumotórax, pneumonia, pleurite.
7. **Gasometria básica** — oxigenação, ventilação e acidose/alcalose.

## Casos que reaparecem em camadas

- **Asma**: hipoxemia, sibilância, dispneia, gasometria.
- **Pneumonia**: hipoxemia, tosse/febre, dor pleurítica.
- **TEP**: hipoxemia, dispneia súbita, dor pleurítica.
- **Pneumotórax**: hipoxemia, dor pleurítica, exame físico.
- **DPOC**: sibilância, hipercapnia, gasometria.

A repetição é intencional. O aluno vê a mesma doença por ângulos diferentes, construindo raciocínio clínico real.
