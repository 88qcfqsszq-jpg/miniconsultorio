import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso056LupusEritematosoSistemicoComNefrite: CasoOSCEV2 = {
// ====== CASO 56: LÚPUS ERITEMATOSO SISTÊMICO ======
id: "56",
titulo: "Lúpus Eritematoso Sistêmico com Nefrite",
sistema: "Imunologia",
tema: "Casos Integradores",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 13,
objetivo_pedagogico: "Diagnosticar LES por achados clínicos multissistêmicos e laboratoriais",
dados_visiveis_ao_estudante: {
nome_paciente: "Carolina Silva",
idade: 32,
sexo: "Feminino",
queixa_principal: "Febre, artrite, edema facial, erupção em rosto",
historia_breve: "Mulher jovem com sintomas multissistêmicos",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Lúpus Eritematoso Sistêmico com Nefrite Lúpica",
diagnosticos_diferenciais: ["Artrite reumatoide", "Síndrome de Sjögren", "Esclerodermia"],
sindromes_associadas: ["Glomerulonefrite lúpica", "Vasculite", "Trombocitopenia"],
},
descricaoBreve: "Paciente com rash malar, artrite, nefrite, ANA positivo, anti-DNA elevado",
categoria: "Casos Integradores",
paciente: {
id: "pac-056",
nome: "Carolina Silva",
idade: 32,
sexo: "F",
queixaPrincipal: "Febre e artrite",
historicoDoenca: "Sintomas há 2 meses",
antecedentes: ["Fotossensibilidade"],
profissao: "Professora",
estado_civil: "Solteira",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Tenho febre, dor nas articulações e uma erupção no rosto",
febre: "Febre recorrente",
artrite: "Dor nas mãos e joelhos",
rash: "Vermelhidão no rosto em forma de borboleta",
edema_facial: "Inchaço no rosto",
fadiga: "Muito cansaço",
urina: "Urina escura às vezes",
},
respostaPaciente: {
inicial: "Febre e artrite",
febre: "Sim",
artrite: "Mãos e joelhos",
rash: "Malar",
edema_facial: "Sim",
fadiga: "Muito",
urina: "Escura às vezes",
},
sinais_vitais: {
corretos: {
pressaoArterial: "130/85 mmHg",
frequenciaCardiaca: 92,
frequenciaRespiratoria: 18,
temperatura: 38.5,
saturacaoOxigenio: 97,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "130/85 mmHg",
frequenciaCardiaca: 92,
frequenciaRespiratoria: 18,
temperatura: 38.5,
saturacaoOxigenio: 97,
},
exame_fisico: {
correto: {
inspecao: "Rash malar, edema facial, úlceras orais",
palpacao: "Articulações das mãos dolorosas, sem deformidade",
ausculta: "Sopro sistólico",
percussao: "Normal",
observacoes: "Sinais de LES sistêmico",
regiao: "Geral",
achados_positivos: ["Rash malar", "Artrite", "Úlceras orais"],
achados_negativos: ["Sem deformidade"],
},
},
exameFisicoCorreto: {
inspecao: "Rash malar",
palpacao: "Artrite simétrica",
ausculta: "Sopro sistólico",
percussao: "Normal",
observacoes: "LES",
},
exame_fisico_interativo: {
geral: {
coloracao: "Rash em região malar",
consciencia: "Alerta",
},
},
exames_complementares_disponiveis: [
{
nome: "ANA",
descricao: "Anticorpo antinúcleo",
resultado: "Positivo (padrão homogêneo)",
valor_referencia: "Negativo",
interpretacao: "Altamente sugestivo de LES",
},
{
nome: "Anti-DNA dupla fita",
descricao: "Anticorpo anti-DNA",
resultado: "1280 IU/mL",
valor_referencia: "<100 IU/mL",
interpretacao: "Muito elevado",
},
{
nome: "Complemento C3",
descricao: "Complemento",
resultado: "65 mg/dL",
valor_referencia: ">90 mg/dL",
interpretacao: "Consumo de complemento",
},
{
nome: "Proteinúria",
descricao: "Proteína em urina",
resultado: "2+ (nefrite lúpica)",
valor_referencia: "Negativa",
interpretacao: "Envolvimento renal",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Lúpus Eritematoso Sistêmico",
probabilidade: 95,
criterios_minimos: [
"Rash malar",
"Artrite",
"ANA positivo",
"Anti-DNA elevado",
"Proteinúria",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Artrite reumatoide",
criterios_exclusao: ["ANA positivo", "Anti-DNA elevado"],
achados_que_descartam: ["Rash malar"],
},
],
examesIndicados: [
"ANA, anti-DNA",
"Complemento (C3, C4)",
"CBC, proteínas",
"Urinálise, proteinúria",
"Creatinina",
],
conduta_esperada: {
imediata: [
"Corticóide sistêmico",
"AINE se não houver nefrite",
"Proteção solar",
],
curto_prazo: [
"Imunossupressor se nefrite",
"Reumatologia",
],
longo_prazo: [
"Acompanhamento multidisciplinar",
],
encaminhamentos: ["Reumatologia", "Nefrologia"],
},
condutaCorreta: "Corticóide sistêmico, imunossupressor se nefrite, reumatologia, nefrologia",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["Nefrite", "Anti-DNA >500", "Complemento baixo"],
descricao: "LES com nefrite ativa",
recomendacao: "Imunossupressão agressiva",
},
],
erros_criticos: [
{
erro: "Não investigar envolvimento renal",
descricao: "Essencial para prognóstico",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu LES",
realizado: false,
critico: true,
},
{
item: "Solicitou ANA e anti-DNA",
realizado: false,
critico: true,
},
{
item: "Investigou nefrite",
realizado: false,
critico: true,
},
{
item: "Encaminhou reumatologia",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de LES",
peso: 30,
descricao: "Achados clínicos multissistêmicos",
pontuacao_maxima: 30,
},
{
criterio: "Investigação de órgão-alvo",
peso: 25,
descricao: "Nefrite lúpica",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Febre",
"Artrite",
"Rash",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Rash malar",
"ANA positivo",
"Anti-DNA elevado",
"Proteinúria",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["LES com nefrite"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Corticóide",
"Imunossupressor",
"Reumatologia",
"Nefrologia",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu LES",
"Solicitou sorologia",
"Investigou nefrite",
"Encaminhou especialistas",
],
erros_comuns: ["Confundir com artrite reumatoide"],
orientacoes_pedagogicas: [
"LES: multissistêmico, ANA positivo",
"AR: artrite erosiva, RF/anti-CCP",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar LES e reconhecer nefrite",
comunicacao: ["explicou importância de seguimento"],
anamnese: ["investigou sintomas sistêmicos"],
exame_fisico: ["detectou rash malar"],
exames_complementares: ["pediu sorologia"],
raciocinio: ["diagnosticou LES"],
conduta: ["prescreveu corticóide"],
soap: ["documentou LES"],
},
temaOSCE: "Casos Integradores",
subtopicosOSCE: [
"LES",
"Rash malar",
"Nefrite lúpica",
"ANA/anti-DNA",
"Doença autoimune",
],
diagnosticoCorreto: "Lúpus Eritematoso Sistêmico com Nefrite Lúpica",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("56"),
} as CasoOSCEV2;
