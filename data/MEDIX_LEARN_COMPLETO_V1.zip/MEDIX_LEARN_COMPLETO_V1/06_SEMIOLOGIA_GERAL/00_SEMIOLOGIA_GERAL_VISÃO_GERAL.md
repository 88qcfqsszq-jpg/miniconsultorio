# MEDIX Learn — Semiologia Geral

## Objetivo
Ensinar o aluno a coletar dados clínicos e transformar observação em raciocínio.

## Trilhas
1. Como colher uma boa história clínica
2. Queixa principal e HDA
3. Sinais vitais
4. Estado geral e nível de consciência
5. Dor: caracterização semiológica
6. Exame físico geral
7. Comunicação clínica inicial
