import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso004DorToracicaAnginaTipica: CasoOSCEV2 = {
// ====== CASO 4: SCA - ANGINA TÍPICA ======
id: "4",
titulo: "Dor Torácica - Angina Típica",
sistema: "Cardiovascular",
tema: "Dor Torácica",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Reconhecer angina estável, investigar fatores de risco cardiovascular e estabelecer conduta conservadora",
dados_visiveis_ao_estudante: {
nome_paciente: "João Oliveira",
idade: 58,
sexo: "Masculino",
queixa_principal: "Dor no peito aos esforços",
historia_breve: "Sente aperto no peito quando caminha rápido ou sobe escadas, passa em repouso",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Angina Estável",
diagnosticos_diferenciais: [
"Angina Instável",
"Infarto Agudo do Miocárdio",
"Pericardite",
"Refluxo Gastroesofágico",
"Espasmo Esofágico",
],
sindromes_associadas: ["Isquemia Miocárdica Transitória"],
},
descricaoBreve: "Paciente com dor precordial reproduzível ao esforço, alívio com repouso",
categoria: "SCA",
paciente: {
id: "pac-004",
nome: "João Oliveira",
idade: 58,
sexo: "M",
queixaPrincipal: "Dor no peito aos esforços",
historicoDoenca: "Sente aperto no peito quando caminha rápido ou sobe escadas, passa em repouso",
antecedentes: ["Hipertensão", "Dislipidemia", "Histórico familiar positivo para infarto"],
profissao: "Advogado",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: ["Losartana 50mg", "Atorvastatina 20mg"],
},
respostas_do_paciente: {
inicial: "Doutor, tô sentindo um aperto no peito quando faço esforço.",
dor: "Aqui no meio do peito, tipo uma banda apertando.",
intensidade: "De 6 a 7, bem incômodo.",
inicio: "Começou umas 3 semanas atrás, quando subo escada.",
duracao: "Passa em uns 5 minutos quando paro de andar.",
fatores_piora: "Caminhada rápida, subir escada, emocional.",
fatores_melhora: "Repouso, ficar sentado tranquilo.",
suor: "Não, não sou de suar.",
respiracao: "Um pouco, fico cansado.",
},
respostaPaciente: {
inicial: "Doutor, tô sentindo um aperto no peito quando faço esforço.",
dor: "Aqui no meio do peito, tipo uma banda apertando.",
intensidade: "De 6 a 7, bem incômodo.",
inicio: "Começou umas 3 semanas atrás, quando subo escada.",
duracao: "Passa em uns 5 minutos quando paro de andar.",
fatores_piora: "Caminhada rápida, subir escada, emocional.",
fatores_melhora: "Repouso, ficar sentado tranquilo.",
suor: "Não, não sou de suar.",
respiracao: "Um pouco, fico cansado.",
},
sinais_vitais: {
corretos: {
pressaoArterial: "145/90 mmHg",
frequenciaCardiaca: 78,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "145/90 mmHg",
frequenciaCardiaca: 78,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 98,
glicemia: 100,
},
exame_fisico: {
correto: {
inspecao: "Paciente calmo, sem desconforto aparente no momento, normocolorado",
palpacao: "Ictus cordis não desviado, pulsos simétricos e amplos",
ausculta: "Ritmo cardíaco regular, sem sopros, sem atrito",
percussao: "Normal",
observacoes: "Exame cardiovascular normal no repouso, história muito sugestiva de angina estável",
regiao: "Precórdio",
achados_positivos: ["Fatores de risco cardiovascular presentes"],
achados_negativos: ["Sopros", "Alterações em repouso"],
},
},
exameFisicoCorreto: {
inspecao: "Paciente calmo, sem desconforto aparente",
palpacao: "Ictus cordis não desviado, pulsos simétricos",
ausculta: "Ritmo cardíaco regular, sem sopros",
percussao: "Normal",
observacoes: "Exame cardiovascular normal no repouso",
},
exames_complementares_disponiveis: [
{
nome: "ECG em repouso",
descricao: "12 derivações",
resultado: "Normal",
valor_referencia: "Normal",
interpretacao: "ECG basal normal, não afasta angina estável",
},
{
nome: "ECG sob esforço",
descricao: "Teste ergométrico",
resultado: "Infradesnível de ST em V4-V5 com dor",
valor_referencia: "Normal",
interpretacao: "Positividade para isquemia miocárdica",
},
{
nome: "Troponina I",
descricao: "Biomarcador cardíaco",
resultado: "<0.04 ng/mL",
valor_referencia: "<0.04 ng/mL",
interpretacao: "Negativa - sem infarto agudo",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Angina Estável",
probabilidade: 85,
criterios_minimos: [
"Dor precordial ao esforço",
"Duração 2-10 minutos",
"Alívio com repouso",
"ECG com isquemia ao esforço",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Refluxo Gastroesofágico",
criterios_exclusao: ["Dor ao esforço típica"],
achados_que_descartam: ["Teste ergométrico positivo para isquemia"],
},
],
examesIndicados: [
"ECG basal",
"Teste ergométrico",
"Troponina",
"Perfil lipídico",
],
conduta_esperada: {
imediata: [
"Prescrever betabloqueador ou bloqueador de cálcio",
"Nitroglicerina SL para crises",
"Asparina 100mg/dia",
],
curto_prazo: [
"Investigar com teste ergométrico",
"Considerar cateterismo se esforço limitante",
],
longo_prazo: [
"Modificação de fatores de risco",
"Reabilitação cardiovascular",
"Seguimento cardiológico",
],
encaminhamentos: ["Cardiologia"],
},
condutaCorreta: "Prescrever betabloqueador, nitrato para crise, aspirina, modificar fatores de risco",
criterios_de_gravidade: [
{
severidade: "leve",
sinais: ["Dor ao esforço", "ECG positivo ao esforço"],
descricao: "Angina estável com esforço significativo",
recomendacao: "Tratamento conservador com investigação para revascularização",
},
],
erros_criticos: [
{
erro: "Não investigar com teste ergométrico",
descricao: "ECG em repouso pode ser normal em angina estável",
penalidade: 1.5,
evitavel: true,
},
{
erro: "Não prescrever terapia antiagregante",
descricao: "Aspirina reduz risco de infarto em pacientes com angina",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{ item: "Investigou relação com esforço e repouso", realizado: false, critico: true },
{ item: "Mediu sinais vitais completos", realizado: false, critico: true },
{ item: "Realizou ausculta cardíaca completa", realizado: false, critico: true },
{ item: "Solicitou ECG basal", realizado: false, critico: true },
{ item: "Indicou teste ergométrico", realizado: false, critico: true },
{ item: "Prescreveu betabloqueador", realizado: false, critico: true },
],
rubrica_correcao: [
{
criterio: "Diagnóstico Diferencial",
peso: 20,
descricao: "Distinção entre angina estável e instável",
pontuacao_maxima: 20,
},
{
criterio: "Estratificação de Risco",
peso: 20,
descricao: "Identificação correta de fatores de risco",
pontuacao_maxima: 20,
},
{
criterio: "Terapia",
peso: 30,
descricao: "Prescrição de betabloqueador e nitrato",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Relação com esforço",
"Duração típica",
"Alívio com repouso",
"Fatores de risco cardiovascular",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Sinais vitais completos",
"Exame cardiovascular",
"ECG basal",
"Teste ergométrico",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Diagnóstico: Angina estável",
"Classificação de risco",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Betabloqueador",
"Nitrato",
"Aspirina",
"Modificação de fatores de risco",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Investigou fatores de risco cardiovascular",
"Solicitou ECG e teste ergométrico",
"Prescreveu betabloqueador",
"Indicou nitroglicerina",
],
erros_comuns: [
"Não usar betabloqueador",
"Ignorar a relação com esforço",
"Não encaminhar para cardiologia",
],
orientacoes_pedagogicas: [
"Angina estável é previsível, relacionada a esforço",
"ECG em repouso pode ser normal",
"Teste ergométrico é fundamental para diagnóstico",
"Betabloqueador é primeira linha de tratamento",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer:
"Diferenciar angina estável de instável: padrão previsível relacionado a esforço, alívio com repouso/nitroglicerina. ECG em repouso pode ser normal. Solicit teste ergométrico. Iniciar betabloqueador. Encaminhar para cardiologia para teste de isquemia.",
comunicacao: [
"se apresentou e tranquilizou o paciente",
"perguntou detalhes sobre a dor",
"explicou próximos passos",
],
anamnese: [
"investigou relação com esforço",
"perguntou sobre duração dos episódios",
"investigou alívio com repouso/nitroglicerina",
"perguntou sobre fatores de risco cardiovascular",
],
exame_fisico: [
"solicitou sinais vitais",
"realizou ausculta cardíaca",
"avaliou perfusão",
],
exames_complementares: [
"solicitou ECG em repouso",
"solicitou teste ergométrico",
"solicitou marcadores cardíacos",
],
raciocinio: [
"reconheceu padrão de angina estável",
"diferenciou de infarto (sem troponina elevada)",
"formulou diagnóstico apropriado",
],
conduta: [
"iniciou betabloqueador",
"prescreveu nitroglicerina SOS",
"encaminhou para cardiologia",
"instruiu sobre quando procurar emergência",
],
soap: [
"registrou dor relacionada a esforço",
"documentou ECG de repouso",
"reconheceu angina estável",
"planejou investigação com teste de isquemia",
],
},
temaOSCE: "Coronariopatias/SCA",
subtopicosOSCE: [
"Angina estável",
"Dor ao esforço reproduzível",
"ECG positivo ao esforço",
"Teste ergométrico",
"Betabloqueador de primeira linha"
],
diagnosticoCorreto: "Angina Estável",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("4"),
} as CasoOSCEV2;
