import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso013EndocarditeInfecciosa: CasoOSCEV2 = {
// ====== CASO 13: ENDOCARDITE INFECCIOSA ======
id: "13",
titulo: "Endocardite Infecciosa",
sistema: "Cardiovascular",
tema: "Infecção Cardíaca",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 15,
objetivo_pedagogico: "Diagnosticar endocardite usando critérios de Duke e prescrever antibioticoterapia",
dados_visiveis_ao_estudante: {
nome_paciente: "Gustavo Ferreira",
idade: 48,
sexo: "Masculino",
queixa_principal: "Febre prolongada com sopro cardíaco",
historia_breve: "Febre há 3 semanas após procedimento odontológico, descoberto sopro novo",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Endocardite Infecciosa Subaguda",
diagnosticos_diferenciais: [
"Infecção de cateter",
"Tuberculose",
"Linfoma",
"Pneumonia com sepse",
],
sindromes_associadas: ["Bacteremia contínua"],
},
descricaoBreve: "Paciente com febre prolongada, novo sopro, esplenomegalia, petéquias",
categoria: "Endocardite",
paciente: {
id: "pac-013",
nome: "Gustavo Ferreira",
idade: 48,
sexo: "M",
queixaPrincipal: "Febre prolongada com sopro cardíaco",
historicoDoenca:
"Febre há 3 semanas após procedimento odontológico, descoberto sopro novo",
antecedentes: ["Valva aórtica bicúspide"],
profissao: "Professor universitário",
estado_civil: "Casado",
alergias: ["Penicilina (alergia leve)"],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Doutor, tô com febre já faz umas 3 semanas que não passa.",
febre: "Febre que vem e vai, mais à noite.",
inicio: "Começou umas 3 semanas atrás, depois que fiz um tratamento de dente.",
suor: "Acordo à noite todo suado.",
cansaco: "Estou muito fraco, sem ânimo nenhum.",
sopro: "Disseram que descobriram um sopro novo no meu coração.",
ossos: "Tenho dores nas articulações.",
pele: "Apareceram umas manchinhas vermelhas nas mãos.",
unhas: "As unhas ficaram estranhas.",
},
respostaPaciente: {
inicial: "Doutor, tô com febre já faz umas 3 semanas que não passa.",
febre: "Febre que vem e vai, mais à noite.",
inicio: "Começou umas 3 semanas atrás, depois que fiz um tratamento de dente.",
suor: "Acordo à noite todo suado.",
cansaco: "Estou muito fraco, sem ânimo nenhum.",
sopro: "Disseram que descobriram um sopro novo no meu coração.",
ossos: "Tenho dores nas articulações.",
pele: "Apareceram umas manchinhas vermelhas nas mãos.",
unhas: "As unhas ficaram estranhas.",
},
sinais_vitais: {
corretos: {
pressaoArterial: "135/80 mmHg",
frequenciaCardiaca: 98,
frequenciaRespiratoria: 20,
temperatura: 38.2,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "135/80 mmHg",
frequenciaCardiaca: 98,
frequenciaRespiratoria: 20,
temperatura: 38.2,
saturacaoOxigenio: 98,
glicemia: 112,
},
exame_fisico: {
correto: {
inspecao: "Petéquias em palato duro e palmas, hemorragia em astilha subungueal",
palpacao: "Esplenomegalia (baço aumentado 2cm), nódulos de Osler em polpas digitais",
ausculta:
"Novo sopro sistólico (insuficiência aórtica), estertores pulmonares se embolia",
percussao: "Normal",
observacoes: "Critérios maiores: febre, novo sopro, embolia; menores: esplenomegalia",
regiao: "Coração, baço, pele",
achados_positivos: [
"Novo sopro",
"Petéquias",
"Esplenomegalia",
"Nódulos de Osler",
],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Petéquias em palmas",
palpacao: "Esplenomegalia, nódulos de Osler",
ausculta: "Novo sopro sistólico",
percussao: "Normal",
observacoes: "Múltiplos critérios de Duke presentes",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Paciente em regular estado geral, febril, pálido.",
coloracao: "Petéquias em palmas e solas dos pés.",
},
cardiovascular: {
ausculta_cardiaca: "Novo sopro sistólico em foco aórtico, rude.",
pulsos: "Pulsos presentes, porém assimétricos em membros superiores.",
},
abdominal: {
palpacao_profunda: "Esplenomegalia evidente, indolor, borda regular.",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemocultura (3 amostras)",
descricao: "Pesquisa de bacteremia",
resultado: "Streptococcus viridans positivo",
valor_referencia: "Negativa",
interpretacao: "Bacteremia contínua",
},
{
nome: "ECG",
descricao: "12 derivações",
resultado: "Sopro, possível bloqueio AV em desenvolvimento",
valor_referencia: "Normal",
interpretacao: "Complicação de endocardite",
},
{
nome: "Ecocardiograma Transesofágico",
descricao: "Ultrassom cardíaco avançado",
resultado: "Vegetação em valva aórtica, insuficiência aórtica moderada",
valor_referencia: "Normal",
interpretacao: "Endocardite confirmada",
},
{
nome: "Hemograma",
descricao: "Série de glóbulos",
resultado: "Leucocitose 13.500/mm³, anemia normocítica",
valor_referencia: "4.500-11.000/mm³",
interpretacao: "Infecção sistêmica",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Endocardite Infecciosa",
probabilidade: 95,
criterios_minimos: [
"Febre >2 semanas",
"Novo sopro",
"Hemocultura positiva",
"Achados ecocardiográficos",
"Critérios de Duke: 2 maiores + 1 menor = definitiva",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Febre de Origem Indeterminada",
criterios_exclusao: ["Novo sopro + hemocultura positiva"],
achados_que_descartam: ["Ecocardiograma com vegetação"],
},
],
examesIndicados: [
"Hemocultura (3 amostras antes de antibiótico)",
"ECG",
"Ecocardiograma transtorácico",
"Ecocardiograma transesofágico",
"Hemograma, PCR, velocidade de sedimentação",
],
conduta_esperada: {
imediata: [
"Coletar 3 hemoculturas antes de antibiótico",
"Iniciar antibioticoterapia: Cefalosporina 3ª geração + Gentamicina IV",
"Internação hospitalar",
],
curto_prazo: [
"Ecocardiograma transesofágico",
"Avaliação cardíaca frequente",
"Consulta com cirurgião cardíaco se indicado",
],
longo_prazo: [
"Antibioticoterapia IV por 4-6 semanas",
"Possível cirurgia de troca valvar",
"Seguimento cardiológico",
],
encaminhamentos: [
"Cardiologia cirúrgica se insuficiência cardíaca",
"Infectologia",
],
},
condutaCorreta:
"Coletar hemoculturas (3), iniciar antibióticos IV (cefalosporina + gentamicina), ecocardiograma transesofágico",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["Novo sopro", "Embolia sem insuficiência cardíaca"],
descricao: "Endocardite com complicação embólica",
recomendacao: "Antibiótico IV, ecocardiograma, avaliação cirúrgica",
},
{
severidade: "grave",
sinais: ["Insuficiência cardíaca", "Bloqueio AV", "Embolia múltipla"],
descricao: "Endocardite com complicações graves",
recomendacao: "Internação UTI, cirurgia urgente",
},
],
erros_criticos: [
{
erro: "Iniciar antibiótico sem coletar hemoculturas",
descricao: "Hemoculturas são essenciais para identificar agente e sensibilidade",
penalidade: 2.5,
evitavel: true,
},
{
erro: "Não solicitar ecocardiograma transesofágico",
descricao: "ETE é mais sensível que ETT para vegetações",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{ item: "Investigou febre prolongada", realizado: false, critico: true },
{ item: "Perguntou sobre procedimentos dentários/invasivos", realizado: false, critico: true },
{ item: "Procurou novos sopros cardíacos", realizado: false, critico: true },
{ item: "Investigou sinais de embolia (petéquias, Osler)", realizado: false, critico: true },
{ item: "Mediu sinais vitais", realizado: false, critico: true },
{ item: "Coletou 3 hemoculturas", realizado: false, critico: true },
{ item: "Solicitou ECG e ecocardiograma", realizado: false, critico: true },
{ item: "Iniciou antibiótico apropriado", realizado: false, critico: true },
],
rubrica_correcao: [
{
criterio: "Diagnóstico Diferencial",
peso: 15,
descricao: "Investigação apropriada de febre prolongada",
pontuacao_maxima: 15,
},
{
criterio: "Achados Clínicos",
peso: 20,
descricao: "Reconhecimento de petéquias, sopros, esplenomegalia",
pontuacao_maxima: 20,
},
{
criterio: "Investigação Diagnóstica",
peso: 25,
descricao: "Hemoculturas, ecocardiograma transesofágico",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Febre >2 semanas",
"Procedimento invasivo prévio",
"Artralgias",
"Sudorese noturna",
"Desconforto geral",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Febre contínua",
"Novo sopro cardíaco",
"Petéquias, hemorragia subungueal",
"Esplenomegalia, nódulos de Osler",
"Hemocultura positiva",
"Ecocardiograma com vegetação",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Endocardite infecciosa",
"Critérios de Duke: 2 maiores confirmados",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Internação hospitalar",
"Antibiótico IV (cefalosporina + gentamicina)",
"Duração 4-6 semanas",
"Ecocardiograma de seguimento",
"Avaliação cirúrgica",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Investigou febre prolongada sistematicamente",
"Procurou novos sopros",
"Coletou hemoculturas antes de antibiótico",
"Solicitou ecocardiograma transesofágico",
"Prescreveu antibioticoterapia apropriada",
],
erros_comuns: [
"Iniciar antibiótico sem hemoculturas",
"Não procurar sopros novos",
"Não investigar sinais de embolia",
],
orientacoes_pedagogicas: [
"Endocardite: febre >2 semanas + novo sopro + embolia",
"Critérios de Duke: 2 maiores = definitiva",
"SEMPRE coletar 3 hemoculturas ANTES de antibiótico",
"Ecocardiograma transesofágico é mais sensível",
"Antibiótico IV por 4-6 semanas",
],
},
temaOSCE: "Conteúdos transversais",
subtopicosOSCE: [
"Endocardite infecciosa",
"Febre prolongada com sopro novo",
"Critérios de Duke",
"Hemoculturas antes de antibiótico",
"Antibiótico prolongado (4-6 semanas)"
],
diagnosticoCorreto: "Endocardite Infecciosa",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("13"),
} as CasoOSCEV2;
