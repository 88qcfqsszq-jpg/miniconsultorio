# MEDIX Learn — Cardiovascular

## Objetivo do módulo
Ensinar o aluno a conectar sintomas cardiovasculares, hemodinâmica, exame físico e risco de gravidade.

## Trilhas
1. Dor torácica
2. Dispneia cardíaca e congestão
3. Edema e insuficiência cardíaca
4. Hipertensão e risco cardiovascular
5. Síncope e palpitações
6. Exame físico cardiovascular
7. ECG básico para clínico iniciante

## Casos recorrentes
SCA, insuficiência cardíaca, crise hipertensiva, arritmias, valvopatias, pericardite, TEP como diferencial.
