import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso022EmergenciaHipertensivaSuspeita: CasoOSCEV2 = {
// ====== CASO 22: EMERGÊNCIA HIPERTENSIVA ======
id: "22",
titulo: "Emergência Hipertensiva Suspeita",
sistema: "Cardiovascular",
tema: "Hipertensão Arterial",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Diferenciar urgência de emergência hipertensiva, pesquisar lesão de órgão-alvo, indicar manejo apropriado",
dados_visiveis_ao_estudante: {
nome_paciente: "Cláudio Mendez",
idade: 55,
sexo: "Masculino",
queixa_principal: "Pressão muito alta com dor de cabeça intensa",
historia_breve: "PA muito elevada, cefaleia occipital, visão turva, paciente com HAS não controlada",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Emergência Hipertensiva com Evidência de Lesão de Órgão-Alvo (Encefalopatia Hipertensiva)",
diagnosticos_diferenciais: ["Urgência hipertensiva", "AVC isquêmico", "Hemorragia intracraniana"],
sindromes_associadas: ["Hipertensão maligna"],
},
descricaoBreve: "Paciente com PA muito elevada (>180/120), sintomas de lesão de órgão-alvo (cefaleia intensa, visão turva), necessário controle urgente",
categoria: "HTA",
paciente: {
id: "pac-022",
nome: "Cláudio Mendez",
idade: 55,
sexo: "M",
queixaPrincipal: "Pressão muito alta com dor de cabeça",
historicoDoenca: "HAS há 10 anos, não controla com medicações, não usa anti-hipertensivo há 2 meses",
antecedentes: ["HAS não controlada", "Tabagismo ativo", "Consumo excessivo de álcool"],
profissao: "Encanador",
estado_civil: "Separado",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Tô com uma dor de cabeça que não aguento mais, meu coração tá acelerado",
cabeca: "Dor pulsante no occipício, pior dor que já tive na cabeça",
visao: "Tá tudo embaçado, especialmente agora, nunca tive isso",
nausea: "Sim, sinto muito enjoo, já vomitei duas vezes",
respiracao: "Sim, tô ofegante",
consiencia: "Um pouco confuso, tô lento pra pensar",
stress: "Sim, tive muitos problemas no trabalho essa semana",
medicacao: "Não tomo nada, parei com os remédios há 2 meses",
},
respostaPaciente: {
inicial: "Dor de cabeça muito intensa e pressão alta",
cabeca: "Dor pulsante no occipício",
visao: "Embaçado",
nausea: "Sim, vomitei",
respiracao: "Sim",
conciencia: "Um pouco confuso",
stress: "Sim",
medicacao: "Parei há 2 meses",
},
sinais_vitais: {
corretos: {
pressaoArterial: "210/135 mmHg",
frequenciaCardiaca: 115,
frequenciaRespiratoria: 24,
temperatura: 37.1,
saturacaoOxigenio: 92,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "210/135 mmHg",
frequenciaCardiaca: 115,
frequenciaRespiratoria: 24,
temperatura: 37.1,
saturacaoOxigenio: 92,
},
exame_fisico: {
correto: {
inspecao: "Paciente ansioso, agitado, palidez, sudorese profusa, tremor fino",
palpacao: "Pulso forte e acelerado, bounding",
ausculta: "Taquicardia, sopro cardíaco sistólico, estertores em bases pulmonares bilateralmente",
percussao: "Normal",
observacoes: "Sinais de lesão de órgão-alvo: encefalopatia hipertensiva com insuficiência cardíaca aguda",
regiao: "Geral",
achados_positivos: ["Taquicardia", "Sopro sistólico", "Estertores", "Agitação"],
achados_negativos: ["Déficit neurológico focal focinho não examinado"],
},
},
exameFisicoCorreto: {
inspecao: "Agitado, palidez, sudorese profusa",
palpacao: "Pulso forte e acelerado",
ausculta: "Taquicardia, sopro sistólico, estertores bibasais",
percussao: "Normal",
observacoes: "Sinais de lesão de múltiplos órgãos",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Paciente agitado, em aparente desconforto, palidez discreta, sudorese profusa",
consciencia: "Lúcido mas confuso, lentificado",
},
cardiovascular: {
inspecao_precordial: "Sem alterações estruturais",
ausculta_cardiaca: "Taquicardia FC 115 bpm, som S4 audível, sopro sistólico ejetivo suave em foco aórtico",
pulsos: "Pulsos fortes e simétricos bilateralmente, amplitude aumentada",
turgencia_jugular: "Elevada",
edema: "Ausente em MMII",
},
respiratorio: {
ausculta_pulmonar: "Estertores crepitantes em bases bilateralmente",
padrao_respiratorio: "Taquipneia 24 ipm",
},
},
exames_complementares_disponiveis: [
{
nome: "Pressão Arterial",
descricao: "Medição cuidadosa",
resultado: "PA sístólica >180 mmHg, PA diastólica >120 mmHg",
valor_referencia: "<120/<80 mmHg",
interpretacao: "Hipertensão severa",
},
{
nome: "ECG (Eletrocardiograma)",
descricao: "12 derivações",
resultado: "Hipertrofia ventricular esquerda, possível onda T em T wave inversion em V4-V6",
valor_referencia: "Normal",
interpretacao: "Efeitos crônicos de HAS + isquemia",
},
{
nome: "Fundoscopia (se realizada)",
descricao: "Exame do fundo de olho",
resultado: "Papiledema, hemorragias em chama, exudatos",
valor_referencia: "Fundo de olho normal",
interpretacao: "Retinopatia hipertensiva maligna",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Emergência Hipertensiva com Encefalopatia",
probabilidade: 90,
criterios_minimos: [
"PA >180/120",
"Cefaleia intensa",
"Alteração visual",
"Alteração mental",
"Insuficiência cardíaca aguda",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "AVC isquêmico",
criterios_exclusao: ["Papiledema", "Estertores"],
achados_que_descartam: ["Presença de sinais de lesão de múltiplos órgãos"],
},
],
examesIndicados: [
"ECG",
"Troponina",
"Creatinina e BUN",
"Eletrólitos",
"Hemograma",
"EAS com microscópio",
"RX de tórax",
"TC ou RM de crânio se déficit focal",
"Fundoscopia",
],
conduta_esperada: {
imediata: [
"Encaminhar para emergência/UTI",
"Monitorização cardíaca e PA contínuas",
"Acesso venoso",
"Redução controlada de PA: meta 10-20% na primeira hora",
"Anti-hipertensivo IV: nitroprussiato, nitroglicerina, labetalol ou esmolol conforme disponibilidade",
"NÃO fazer redução brusca (risco de AVC)",
"Oxigenioterapia se SpO2 <90%",
],
curto_prazo: [
"Investigação de lesão de órgão-alvo",
"TC/RM de crânio se suspeita de AVC ou hemorragia",
"Internação em UTI",
"Avaliação oftalmológica",
],
longo_prazo: [
"Investigação de causa secundária de HAS",
"Controle anti-hipertensivo crônico",
"Educação do paciente",
],
encaminhamentos: ["Emergência", "UTI", "Oftalmologia"],
},
condutaCorreta: "Emergência hipertensiva - encaminhar para UTI, redução controlada de PA 10-20% primeira hora, anti-hipertensivo IV, investigar lesão de órgão-alvo",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: [
"PA >180/120",
"Cefaleia intensa",
"Alteração visual",
"Confusão mental",
"Insuficiência cardíaca aguda",
],
descricao: "Emergência hipertensiva com lesão de múltiplos órgãos, risco iminente de morte",
recomendacao: "Hospitalização em UTI, redução controlada de PA, investigação urgente",
},
],
erros_criticos: [
{
erro: "Fazer redução brusca de PA",
descricao: "Risco de AVC isquêmico por hipoperfusão",
penalidade: 3,
evitavel: true,
},
{
erro: "Não reconhecer como emergência",
descricao: "Lesão de órgão-alvo requer hospitalização urgente",
penalidade: 2.5,
evitavel: true,
},
{
erro: "Não investigar lesão de órgão-alvo",
descricao: "Necessário para guiar tratamento",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Mediu PA corretamente",
realizado: false,
critico: true,
},
{
item: "Reconheceu PA >180/120 como emergência",
realizado: false,
critico: true,
},
{
item: "Pesquisou sinais de lesão de órgão-alvo (cérebro, coração, rins, olhos)",
realizado: false,
critico: true,
},
{
item: "Solicitou exames apropriados (ECG, creatinina, EAS, RX, fundoscopia)",
realizado: false,
critico: true,
},
{
item: "Decidiu encaminhar para emergência/UTI",
realizado: false,
critico: true,
},
{
item: "Explicou necessidade de redução controlada de PA",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de emergência",
peso: 30,
descricao: "Diferenciação urgência vs emergência",
pontuacao_maxima: 30,
},
{
criterio: "Avaliação de lesão de órgão-alvo",
peso: 25,
descricao: "Exame físico e investigação apropriados",
pontuacao_maxima: 25,
},
{
criterio: "Decisão de encaminhamento",
peso: 20,
descricao: "Indicação apropriada de UTI",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Cefaleia intensa",
"Sintomas de lesão de órgão-alvo",
"Não-aderência ao tratamento",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"PA >180/120",
"Sinais de lesão múltipla",
"ECG, creatinina, EAS alterados",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Emergência hipertensiva",
"Encefalopatia hipertensiva suspeita",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Encaminhamento urgente para UTI",
"Redução controlada de PA",
"Investigação de causa",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu PA >180/120 como emergência",
"Pesquisou sinais de lesão de órgão-alvo",
"Encaminhou para UTI",
"Explicou necessidade de redução controlada",
"Solicitou investigação apropriada",
],
erros_comuns: [
"Fazer redução brusca de PA",
"Confundir urgência com emergência",
"Tentar tratar ambulatorialmente",
],
orientacoes_pedagogicas: [
"Emergência hipertensiva: PA >180/120 + sintomas de lesão de órgão-alvo = hospitalização urgente",
"Redução de PA: meta 10-20% primeira hora, depois mais gradual",
"Nunca reduzir PA em >30% nas primeiras 24h",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diferenciar urgência de emergência hipertensiva, pesquisar lesão de órgão-alvo, encaminhar para tratamento apropriado",
comunicacao: [
"explicou a gravidade",
"tranquilizou o paciente",
"explicou necessidade de hospitalização",
],
anamnese: [
"investigou antecedentes de HAS",
"perguntou sobre aderência ao tratamento",
"investigou sintomas de lesão de órgão-alvo",
],
exame_fisico: [
"mediu PA cuidadosamente",
"pesquisou neurológico",
"pesquisou edema pulmonar",
"avaliou fundo de olho",
],
exames_complementares: [
"solicitou ECG",
"solicitou creatinina e eletrólitos",
"solicitou EAS",
"solicitou fundoscopia",
],
raciocinio: [
"diagnosticou emergência hipertensiva",
"identificou encefalopatia e insuficiência cardíaca",
],
conduta: [
"encaminhou para UTI",
"explicou redução controlada de PA",
],
soap: [
"documentou cefaleia e sintomas",
"registrou PA e achados de lesão múltipla",
"planejou investigação urgente",
],
},
temaOSCE: "Hipertensão Arterial",
subtopicosOSCE: [
"Emergência hipertensiva",
"Encefalopatia hipertensiva",
"PA >180/120",
"Lesão de órgão-alvo",
"Redução controlada de PA",
"Diferenciação urgência vs emergência",
],
diagnosticoCorreto: "Emergência Hipertensiva com Encefalopatia",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("22"),
} as CasoOSCEV2;
