import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso009DpocExacerbacaoAguda: CasoOSCEV2 = {
// ====== CASO 9: DPOC - DOENÇA PULMONAR OBSTRUTIVA CRÔNICA ======
id: "9",
titulo: "DPOC - Exacerbação Aguda",
sistema: "Respiratório",
tema: "Dispneia Crônica",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Diagnosticar DPOC em exacerbação e prescrever broncodilatadores e corticosteroide",
dados_visiveis_ao_estudante: {
nome_paciente: "Antônio Silva",
idade: 72,
sexo: "Masculino",
queixa_principal: "Falta de ar e tosse com escarro",
historia_breve: "Tabagista crônico com tosse habitual, piorou nos últimos dias",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "DPOC - Exacerbação Aguda",
diagnosticos_diferenciais: [
"Asma",
"Pneumonia",
"Insuficiência Cardíaca",
"TEP",
],
sindromes_associadas: ["Obstrução crônica das vias aéreas"],
},
descricaoBreve: "Paciente com tosse crônica produtiva, dispneia progressiva, tabagista",
categoria: "DPOC",
paciente: {
id: "pac-009",
nome: "Antônio Silva",
idade: 72,
sexo: "M",
queixaPrincipal: "Falta de ar e tosse com escarro",
historicoDoenca: "Tabagista crônico com tosse habitual, piorou nos últimos dias",
antecedentes: ["Tabagismo 40 anos (60 maços/ano)", "HAS", "DPOC há 10 anos"],
profissao: "Aposentado",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: [
"Salbutamol inalado",
"Tiotropio",
"Losartana 50mg",
],
},
respostas_do_paciente: {
inicial: "Doutor, tô muito mal, a falta de ar piorou muito.",
tosse: "Tenho essa tosse toda hora, tá saindo bem amarelado, mais que o de costume.",
duracao: "Essa tosse tenho faz anos, mas nos últimos dias ficou pior.",
atividade: "Antes conseguia caminhar um pouco, agora mal consigo ficar em pé.",
dormir: "Não consigo dormir deitado, tenho que ficar sentado.",
chiado: "Tenho aquele chiado no peito o tempo todo.",
fumo: "Fumava 2 maços por dia, parei faz uns anos.",
ambiente: "Trabalhei em obra por muito tempo, respirava pó o tempo todo.",
},
respostaPaciente: {
inicial: "Doutor, tô muito mal, a falta de ar piorou muito.",
tosse: "Tenho essa tosse toda hora, tá saindo bem amarelado, mais que o de costume.",
duracao: "Essa tosse tenho faz anos, mas nos últimos dias ficou pior.",
atividade: "Antes conseguia caminhar um pouco, agora mal consigo ficar em pé.",
dormir: "Não consigo dormir deitado, tenho que ficar sentado.",
chiado: "Tenho aquele chiado no peito o tempo todo.",
fumo: "Fumava 2 maços por dia, parei faz uns anos.",
ambiente: "Trabalhei em obra por muito tempo, respirava pó o tempo todo.",
},
sinais_vitais: {
corretos: {
pressaoArterial: "140/85 mmHg",
frequenciaCardiaca: 105,
frequenciaRespiratoria: 32,
temperatura: 37.2,
saturacaoOxigenio: 85,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "140/85 mmHg",
frequenciaCardiaca: 105,
frequenciaRespiratoria: 32,
temperatura: 37.2,
saturacaoOxigenio: 85,
glicemia: 180,
},
exame_fisico: {
correto: {
inspecao: "Paciente com tórax em tonel, cianose ligeira, uso acentuado de musculatura acessória",
palpacao: "Expansão torácica reduzida bilateralmente, frêmito diminuído",
ausculta:
"Murmúrio vesicular muito reduzido bilateralmente, sibilos e roncos espalhados",
percussao: "Hipersonoridade difusa",
observacoes: "Sinais típicos de DPOC avançada em exacerbação",
regiao: "Pulmões",
achados_positivos: [
"Tórax em tonel",
"Sibilos",
"Roncos",
"Hipersonoridade",
],
achados_negativos: ["Crepitações consolidativas"],
},
},
exameFisicoCorreto: {
inspecao: "Tórax em tonel, cianose ligeira, musculatura acessória ativa",
palpacao: "Expansão reduzida",
ausculta: "Murmúrio vesicular reduzido, sibilos e roncos",
percussao: "Hipersonoridade",
observacoes: "DPOC avançada",
},
exames_complementares_disponiveis: [
{
nome: "Radiografia de Tórax PA e Perfil",
descricao: "Avaliação pulmonar",
resultado: "Hiperinsuflação pulmonar, aumento do espaço retroesternal, flattening de diafragma",
valor_referencia: "Normal",
interpretacao: "DPOC com hiperinsuflação",
},
{
nome: "Hemograma",
descricao: "Série de glóbulos",
resultado: "Leucocitose 13.000/mm³, neutrofilia 78%",
valor_referencia: "4.500-11.000/mm³",
interpretacao: "Exacerbação infecciosa",
},
{
nome: "Gasometria Arterial",
descricao: "Avaliação de ventilação",
resultado: "pH 7.32, pCO2 52, pO2 65 com O2",
valor_referencia: "pH 7.35-7.45, pCO2 35-45, pO2 >80 com O2",
interpretacao: "Acidose respiratória leve com hipoxemia",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "DPOC em Exacerbação",
probabilidade: 90,
criterios_minimos: [
"Tosse crônica produtiva",
"Tabagismo significativo",
"Dispneia progressiva",
"Sibilos e roncos",
"Hipersonoridade",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Asma",
criterios_exclusao: ["Tabagismo crônico", "Tórax em tonel"],
achados_que_descartam: ["História de tabagismo, idade"],
},
],
examesIndicados: [
"Radiografia de tórax",
"Hemograma",
"Gasometria arterial",
"Espirometria quando estável",
],
conduta_esperada: {
imediata: [
"Oxigenioterapia para atingir SpO2 88-92%",
"Broncodilatadores: salbutamol nebulizado",
"Corticosteroide sistêmico: prednisona 40-60mg",
],
curto_prazo: [
"Avaliar necessidade de antibiótico",
"Monitorização de SpO2 e gasometria",
"Fisioterapia respiratória",
],
longo_prazo: [
"Vacinação pneumocócica e influenza",
"Reabilitação pulmonar",
"Cessação de tabagismo",
],
encaminhamentos: ["Pneumologia se sintomas persistirem"],
},
condutaCorreta:
"Oxigenioterapia (SpO2 88-92%), salbutamol nebulizado, corticosteroide sistêmico, avaliação de antibiótico",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["SpO2 85-90%", "FR 25-32", "pH 7.30-7.35"],
descricao: "DPOC em exacerbação moderada",
recomendacao: "Broncodilatadores, corticosteroide, oxigenio controlado",
},
{
severidade: "grave",
sinais: ["SpO2 <85%", "FR >35", "Acidose respiratória pH <7.30"],
descricao: "DPOC em exacerbação grave",
recomendacao: "Internação, possível ventilação não-invasiva",
},
],
erros_criticos: [
{
erro: "Dar oxigenioterapia sem controle (SpO2 >95%)",
descricao: "Pode remover o estímulo respiratório hipóxico, causar hipercapnia",
penalidade: 2.5,
evitavel: true,
},
{
erro: "Não prescrever corticosteroide sistêmico",
descricao: "Corticosteroide reduz duração de exacerbação",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{ item: "Investigou tabagismo e exposição ocupacional", realizado: false, critico: true },
{ item: "Mediu SpO2 e gases arteriais", realizado: false, critico: true },
{ item: "Ausculta: identificou sibilos", realizado: false, critico: true },
{ item: "Solicitou radiografia de tórax", realizado: false, critico: true },
{ item: "Prescreveu broncodilatador nebulizado", realizado: false, critico: true },
{ item: "Prescreveu corticosteroide sistêmico", realizado: false, critico: true },
{ item: "Titulou oxigenio para SpO2 88-92%", realizado: false, critico: true },
],
rubrica_correcao: [
{
criterio: "Diagnóstico Diferencial",
peso: 15,
descricao: "Diferenciação com asma",
pontuacao_maxima: 15,
},
{
criterio: "Controle de Oxigenação",
peso: 25,
descricao: "Titulação apropriada de SpO2",
pontuacao_maxima: 25,
},
{
criterio: "Terapia Broncodilatadora",
peso: 30,
descricao: "Prescrição de salbutamol e corticosteroide",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Tosse crônica com escarro",
"Tabagismo prévio significativo",
"Dispneia progressiva",
"Dyspnea at rest",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"SpO2 baixa",
"Taquipneia",
"Sibilos e roncos",
"Hipersonoridade",
"RX: hiperinsuflação",
"Gasometria: hipoxemia e hipercapnia",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"DPOC em exacerbação",
"Avaliação de gravidade",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Oxigenioterapia controlada",
"Broncodilatadores",
"Corticosteroide sistêmico",
"Possível antibiótico",
"Fisioterapia",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Investigou tabagismo",
"Mediu SpO2 e gases",
"Prescreveu broncodilatador",
"Prescreveu corticosteroide",
"Titulou oxigenio corretamente",
],
erros_comuns: [
"Não controlar SpO2 (deixar >95%)",
"Não prescrever corticosteroide",
"Confundir com asma",
],
orientacoes_pedagogicas: [
"DPOC: tosse crônica produtiva + tabagismo",
"Exacerbação: aumento súbito de sintomas",
"Oxigenio: sempre titular para SpO2 88-92%",
"Broncodilatadores + corticosteroide são pilares",
"Gasometria guia intensidade de tratamento",
],
},
temaOSCE: "TVP/TEP/Insuficiência venosa",
subtopicosOSCE: [
"Tromboembolismo pulmonar (TEP)",
"Dispneia súbita",
"Score de Wells >4",
"D-dímero elevado",
"AngioTC pulmonar"
],
diagnosticoCorreto: "DPOC em Exacerbação",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("9"),
} as CasoOSCEV2;
