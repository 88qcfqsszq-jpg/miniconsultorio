# Trilha Semiologia Geral — Pediatria — sinais de gravidade

## Objetivo da trilha

Ensinar diferenças pediátricas em respiração, hidratação, febre e estado geral com foco em base, semiologia e raciocínio clínico, preparando o aluno para reconhecer padrões, avaliar gravidade e transferir o aprendizado para OSCE.

A trilha deve sempre conectar três camadas:

```text
conceito de base → manifestação clínica → decisão no atendimento
```

O aluno não deve terminar a trilha apenas decorando nomes. Ele deve conseguir olhar para um paciente, reconhecer padrões, explicar o mecanismo provável e decidir o próximo passo com segurança proporcional ao nível de formação.

---

## Competências ao final

O aluno deve conseguir:

1. Explicar os conceitos centrais de pediatria — sinais de gravidade.
2. Reconhecer achados semiológicos relevantes.
3. Separar apresentações leves de sinais de gravidade.
4. Construir hipóteses por mecanismo.
5. Aplicar o raciocínio em mini-casos.

---

# 1. Microaula — Ideia central

Pediatria — sinais de gravidade é uma trilha de integração entre conhecimento de base e decisão clínica. O aluno deve entender o mecanismo antes de decorar condutas.

## Conceitos obrigatórios

- **Pediatria — sinais de gravidade**: Pediatria — sinais de gravidade é uma trilha de integração entre conhecimento de base e decisão clínica. O aluno deve entender o mecanismo antes de decorar condutas.
- **Gravidade**: A primeira pergunta em qualquer atendimento é se o paciente está instável ou possui sinal de alarme.
- **Transferência**: O conteúdo deve ser aplicado em mini-casos e depois levado ao OSCE.

## Frase didática

```text
Pediatria — sinais de gravidade: não é uma lista de sinais; é um padrão clínico que precisa ser explicado por mecanismo.
```

---

# 2. Fisiologia / fisiopatologia aplicada

## 1. Mecanismo principal

Em pediatria — sinais de gravidade, o aluno deve identificar o mecanismo dominante e como ele aparece no paciente.

```text
mecanismo → sinal/sintoma → hipótese → decisão
```

## 2. Semiologia aplicada

Os sinais não são decorados isoladamente: cada achado deve responder a uma pergunta clínica.

```text
observação → interpretação → conduta
```

## 3. Risco e priorização

Sinais de alarme mudam a ordem do atendimento e podem exigir ação antes de investigação completa.

```text
red flag → estabilizar/encaminhar → investigar
```

---

# 3. Semiologia essencial

O aluno deve aprender a observar antes de decorar conduta.

## Achados que precisam ser procurados

- Sinais vitais e estado geral.
- Início, duração e progressão.
- Fatores precipitantes e antecedentes.
- Exame físico direcionado.
- Sinais de alarme.
- Impacto funcional.
- Resposta a medidas iniciais.

## Sinais de alarme

- Instabilidade hemodinâmica.
- Alteração de consciência.
- Dor intensa ou progressiva.
- Sinais neurológicos focais quando aplicável.

---

# 4. Raciocínio clínico

A pergunta-guia desta trilha é:

```text
Qual mecanismo explica melhor o conjunto de sintomas, sinais e dados objetivos?
```

O raciocínio deve seguir:

```text
1. reconhecer a síndrome;
2. avaliar gravidade;
3. formular hipóteses por mecanismo;
4. procurar achados que confirmem ou afastem hipóteses;
5. escolher exames que mudam conduta;
6. iniciar medidas prioritárias quando houver risco.
```

## Erros comuns

- Pular sinais vitais.
- Pedir exames sem hipótese.
- Não reavaliar.

---

# 5. Mini-casos

## Mini-caso 1 — Lactente febril

### Cenário
Paciente com apresentação típica relacionada a lactente febril, exigindo que o aluno conecte queixa, sinais vitais e exame físico.

### Mecanismo principal
Mecanismo dominante de lactente febril dentro da trilha pediatria — sinais de gravidade.

```text
queixa → achados → mecanismo → decisão
```

### Achados-chave
- queixa principal
- sinal objetivo
- achado de exame
- contexto clínico

### Pergunta central
Qual mecanismo explica lactente febril?

### Resposta esperada
O aluno deve identificar o mecanismo provável, sinais de gravidade e próximo passo seguro.

### Erro comum
Decorar o diagnóstico sem justificar por sinais e mecanismos.

### Ponte para OSCE
Treinar atendimento dirigido e feedback no MEDIX OSCE.
## Mini-caso 2 — Bronquiolite

### Cenário
Paciente com apresentação típica relacionada a bronquiolite, exigindo que o aluno conecte queixa, sinais vitais e exame físico.

### Mecanismo principal
Mecanismo dominante de bronquiolite dentro da trilha pediatria — sinais de gravidade.

```text
queixa → achados → mecanismo → decisão
```

### Achados-chave
- queixa principal
- sinal objetivo
- achado de exame
- contexto clínico

### Pergunta central
Qual mecanismo explica bronquiolite?

### Resposta esperada
O aluno deve identificar o mecanismo provável, sinais de gravidade e próximo passo seguro.

### Erro comum
Decorar o diagnóstico sem justificar por sinais e mecanismos.

### Ponte para OSCE
Treinar atendimento dirigido e feedback no MEDIX OSCE.
## Mini-caso 3 — Desidratação infantil

### Cenário
Paciente com apresentação típica relacionada a desidratação infantil, exigindo que o aluno conecte queixa, sinais vitais e exame físico.

### Mecanismo principal
Mecanismo dominante de desidratação infantil dentro da trilha pediatria — sinais de gravidade.

```text
queixa → achados → mecanismo → decisão
```

### Achados-chave
- queixa principal
- sinal objetivo
- achado de exame
- contexto clínico

### Pergunta central
Qual mecanismo explica desidratação infantil?

### Resposta esperada
O aluno deve identificar o mecanismo provável, sinais de gravidade e próximo passo seguro.

### Erro comum
Decorar o diagnóstico sem justificar por sinais e mecanismos.

### Ponte para OSCE
Treinar atendimento dirigido e feedback no MEDIX OSCE.
## Mini-caso 4 — Criança prostrada

### Cenário
Paciente com apresentação típica relacionada a criança prostrada, exigindo que o aluno conecte queixa, sinais vitais e exame físico.

### Mecanismo principal
Mecanismo dominante de criança prostrada dentro da trilha pediatria — sinais de gravidade.

```text
queixa → achados → mecanismo → decisão
```

### Achados-chave
- queixa principal
- sinal objetivo
- achado de exame
- contexto clínico

### Pergunta central
Qual mecanismo explica criança prostrada?

### Resposta esperada
O aluno deve identificar o mecanismo provável, sinais de gravidade e próximo passo seguro.

### Erro comum
Decorar o diagnóstico sem justificar por sinais e mecanismos.

### Ponte para OSCE
Treinar atendimento dirigido e feedback no MEDIX OSCE.

---

# 6. Questões ativas

## Questão ativa 1

**Pergunta:** Qual é a primeira pergunta diante de pediatria — sinais de gravidade?

**Resposta esperada:** Há instabilidade ou sinal de alarme que muda a prioridade?

**Por que importa:** Segurança antes de diagnóstico definitivo.
## Questão ativa 2

**Pergunta:** Como evitar decorar listas?

**Resposta esperada:** Explicando cada achado por mecanismo e aplicando em mini-casos.

**Por que importa:** Forma raciocínio clínico.
## Questão ativa 3

**Pergunta:** Quando exames entram?

**Resposta esperada:** Quando ajudam a confirmar hipótese ou mudam conduta, sem atrasar medida prioritária.

**Por que importa:** Evita investigação inútil.

---

# 7. Mapa final

```text
PEDIATRIA — SINAIS DE GRAVIDADE
├── conceito de base
├── semiologia
├── gravidade
├── mini-casos
└── ponte para OSCE
```

---

# 8. Ponte para OSCE

## MEDIX OSCE Ciclo Básico

O aluno deve treinar:

- perguntas dirigidas
- exame físico focal
- diagnóstico sindrômico
- conduta inicial
- comunicação

## MEDIX OSCE Clínico

No módulo clínico, essa trilha pode ser aprofundada com:

- evolução temporal dos sinais vitais;
- resposta a intervenção;
- piora por atraso terapêutico;
- comparação entre o raciocínio MEDIX e a fisiologia dinâmica.

---

# 9. Checklist de curadoria

- [ ] A trilha ensina mecanismo, e não apenas definição?
- [ ] Há conexão explícita entre fisiologia e semiologia?
- [ ] Os mini-casos cobrem apresentações diferentes?
- [ ] Existem erros comuns bem destacados?
- [ ] O aluno consegue transferir o conteúdo para um atendimento OSCE?
- [ ] A linguagem é adequada para estudante em formação?
- [ ] Há alerta para situações em que atraso terapêutico é perigoso?
