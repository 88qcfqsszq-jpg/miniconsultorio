# MEDIX Learn Completo v2.0

Este pacote contém a matriz completa e detalhada do MEDIX Learn em arquivos `.md`, organizada por sistemas e frentes transversais.

## Estrutura

```text
MEDIX Learn
├── Respiratório
├── Cardiovascular
├── Infectologia
├── Neurologia
├── Gastro/Abdome
├── Semiologia Geral
└── Raciocínio Clínico
```

Cada trilha segue o padrão pedagógico:

```text
microaula → fisiologia/fisiopatologia aplicada → semiologia → raciocínio clínico → mini-casos → questões ativas → mapa final → ponte para OSCE
```

## Observação de curadoria

A trilha Hipoxemia foi preservada como modelo detalhado fornecido/validado. As demais trilhas foram expandidas com o mesmo formato pedagógico para servir como fonte de verdade antes da implementação.
