# MEDIX Learn — Gastro/Abdome

## Objetivo
Ensinar dor abdominal e síndromes digestivas com base em anatomia, semiologia e sinais de gravidade.

## Trilhas
1. Dor abdominal
2. Náuseas, vômitos e desidratação
3. Diarreia
4. Icterícia
5. Sangramento digestivo
6. Exame físico abdominal
7. Abdome agudo: raciocínio inicial
