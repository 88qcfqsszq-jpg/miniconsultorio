# Trilha Respiratório — Dor Torácica Pleurítica

## Papel dentro do MEDIX Learn
Trilha para diferenciar dor respiratória de outras dores torácicas e reconhecer causas graves.

## Objetivo pedagógico
Ensinar o aluno a identificar dor que piora com respiração e conectá-la a pleura, TEP, pneumonia e pneumotórax.

## Competências ao final
- Caracterizar dor pleurítica.
- Diferenciar de dor anginosa.
- Associar dor a dispneia, febre, tosse, início súbito e fatores de risco.
- Reconhecer TEP e pneumotórax como diagnósticos perigosos.

## Sequência didática padrão
1. **Microaula** — conceito central em linguagem simples.
2. **Fisiologia aplicada** — mecanismo que explica o sinal/sintoma.
3. **Semiologia** — como o mecanismo aparece no paciente.
4. **Raciocínio clínico** — como diferenciar causas próximas.
5. **Mini-casos** — aplicação curta, com pergunta e feedback.
6. **Questões ativas** — perguntas que obrigam o aluno a pensar.
7. **Erros comuns** — atalhos mentais perigosos.
8. **Mapa final** — síntese visual/textual.
9. **Ponte para OSCE** — para onde o aluno vai treinar depois.

## Blocos obrigatórios da trilha
- Definição de dor pleurítica.
- Dor ventilatório-dependente.
- Pneumonia com pleurite.
- TEP.
- Pneumotórax.
- Derrame pleural.
- Red flags: dispneia súbita, hipoxemia, hipotensão, síncope.

## Mini-casos sugeridos
- TEP: dor pleurítica + dispneia súbita.
- Pneumotórax: dor súbita + MV abolido.
- Pneumonia: febre + crepitações.
- Dor musculoesquelética: reprodutível à palpação, sem hipoxemia.

## Questões ativas-base
1. Dor pleurítica exclui IAM?
2. Qual dor pleurítica exige pensar em TEP?
3. Por que pneumotórax pode dar dor e hipoxemia?

## Erros comuns a corrigir
- Chamar toda dor torácica de muscular.
- Esquecer TEP.
- Esperar RX em paciente instável com pneumotórax hipertensivo.

## Ponte para OSCE
OSCE Ciclo Básico: dor torácica respiratória. OSCE Clínico: pneumotórax/TEP com evolução dinâmica.
