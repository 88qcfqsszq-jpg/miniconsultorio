import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso005HipertensaoArterialSistemica: CasoOSCEV2 = {
// ====== CASO 5: HAS - HIPERTENSÃO ESTÁGIO 1 ======
id: "5",
titulo: "Hipertensão Arterial Sistêmica",
sistema: "Cardiovascular",
tema: "Hipertensão",
nivel: "iniciante",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Diagnosticar HAS, avaliar lesões em órgão-alvo e estabelecer terapia anti-hipertensiva",
dados_visiveis_ao_estudante: {
nome_paciente: "Maria Santos",
idade: 52,
sexo: "Feminino",
queixa_principal: "Dor de cabeça e fraqueza",
historia_breve: "Vem sentindo mal-estar há alguns meses, com dor de cabeça recorrente",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Hipertensão Arterial Sistêmica Estágio 1",
diagnosticos_diferenciais: [
"HAS Estágio 2",
"Crise Hipertensiva",
"Preeclâmpsia",
"Feocromocitoma",
],
sindromes_associadas: ["Síndrome Metabólica"],
},
descricaoBreve: "Paciente com pressão arterial elevada e fatores de risco metabólicos",
categoria: "HAS",
paciente: {
id: "pac-005",
nome: "Maria Santos",
idade: 52,
sexo: "F",
queixaPrincipal: "Dor de cabeça e fraqueza",
historicoDoenca: "Mal-estar há alguns meses com dor de cabeça recorrente",
antecedentes: ["Obesidade", "Diabetes tipo 2", "Dislipidemia"],
profissao: "Comerciante",
estado_civil: "Viúva",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Doutora, tô com uma dor de cabeça constante, fico fraca.",
cefaleia: "Dói aqui em cima, tipo um aperto, o dia inteiro.",
visao: "Sim, às vezes vejo umas bolinhas na frente dos olhos.",
tontura: "Bastante, isso me preocupa.",
zumbido: "Tenho sim, um zumbido chato no ouvido.",
sangue_nariz: "Não tive não, mas tava com pressão alta no ano passado.",
alimentacao: "Como bastante sal mesmo, gosto de comida temperada.",
atividade_fisica: "Trabalho no comércio, fico em pé o tempo todo.",
peso: "Sempre fui de peso, tem uns anos que não emagreço.",
},
respostaPaciente: {
inicial: "Doutora, tô com uma dor de cabeça constante, fico fraca.",
cefaleia: "Dói aqui em cima, tipo um aperto, o dia inteiro.",
visao: "Sim, às vezes vejo umas bolinhas na frente dos olhos.",
tontura: "Bastante, isso me preocupa.",
zumbido: "Tenho sim, um zumbido chato no ouvido.",
sangue_nariz: "Não tive não, mas tava com pressão alta no ano passado.",
alimentacao: "Como bastante sal mesmo, gosto de comida temperada.",
atividade_fisica: "Trabalho no comércio, fico em pé o tempo todo.",
peso: "Sempre fui de peso, tem uns anos que não emagreço.",
},
sinais_vitais: {
corretos: {
pressaoArterial: "160/100 mmHg",
frequenciaCardiaca: 88,
frequenciaRespiratoria: 18,
temperatura: 36.9,
saturacaoOxigenio: 97,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "160/100 mmHg",
frequenciaCardiaca: 88,
frequenciaRespiratoria: 18,
temperatura: 36.9,
saturacaoOxigenio: 97,
glicemia: 115,
},
exame_fisico: {
correto: {
inspecao: "Paciente obesa, sem sinais de desconforto agudo, normocolorada",
palpacao: "Ictus cordis não desviado, pulsos braquial e femoral simétricos",
ausculta: "Ritmo cardíaco regular, sem sopros, sem B3, sem estertores",
percussao: "Normal",
observacoes: "Sem sinais de descompensação cardíaca ou edema periférico",
regiao: "Precórdio",
achados_positivos: ["IMC elevado"],
achados_negativos: ["Edema", "Sopros", "B3"],
},
},
exameFisicoCorreto: {
inspecao: "Paciente obesa, sem sinais de desconforto",
palpacao: "Ictus cordis não desviado, pulsos simétricos",
ausculta: "Ritmo cardíaco regular, sem sopros",
percussao: "Normal",
observacoes: "Sem sinais de descompensação",
},
exames_complementares_disponiveis: [
{
nome: "ECG",
descricao: "12 derivações",
resultado: "Sem alterações agudas, possível hipertrofia ventricular esquerda",
valor_referencia: "Normal",
interpretacao: "Compatível com HAS crônica",
},
{
nome: "Hemograma",
descricao: "Série de glóbulos",
resultado: "Normal",
valor_referencia: "Normal",
interpretacao: "Sem anemia",
},
{
nome: "Glicemia de jejum",
descricao: "Metabolismo de glicose",
resultado: "128 mg/dL",
valor_referencia: "<100 mg/dL",
interpretacao: "Elevada, compatível com DM2",
},
{
nome: "Creatinina e Ureia",
descricao: "Função renal",
resultado: "Creatinina 1.0 mg/dL, Ureia 35 mg/dL",
valor_referencia: "Creatinina 0.6-1.2, Ureia 10-50",
interpretacao: "Normal, sem lesão renal aguda",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Hipertensão Arterial Sistêmica Estágio 1",
probabilidade: 90,
criterios_minimos: [
"PA sistólica 140-159 mmHg",
"PA diastólica 90-99 mmHg",
"Sintomas associados",
"Fatores de risco",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "HAS Secundária",
criterios_exclusao: ["História típica de HAS primária"],
achados_que_descartam: ["Ausência de sinais de doença secundária"],
},
],
examesIndicados: ["ECG", "Hemograma", "Glicemia", "Creatinina", "Perfil lipídico"],
conduta_esperada: {
imediata: [
"Orientar redução de sal (máximo 6g/dia)",
"Recomendação de perda de peso",
"Atividade física regular",
],
curto_prazo: [
"Iniciar terapia anti-hipertensiva: ACE inibidor ou bloqueador de cálcio",
"Repetir medidas de PA após 4 semanas",
],
longo_prazo: [
"Monitorização de órgãos-alvo (coração, rim, cérebro)",
"Controle de fatores de risco associados",
],
encaminhamentos: ["Nutrição para orientação dietética"],
},
condutaCorreta:
"Iniciação de anti-hipertensivo, orientação dietética, atividade física, avaliação de órgãos-alvo",
criterios_de_gravidade: [
{
severidade: "leve",
sinais: ["PA 160/100", "Sem sintomas agudos"],
descricao: "HAS estágio 1 sem descompensação",
recomendacao: "Terapia anti-hipertensiva iniciar por mudanças comportamentais",
},
],
erros_criticos: [
{
erro: "Não solicitar ECG",
descricao: "ECG pode evidenciar hipertrofia ventricular ou isquemia",
penalidade: 1,
evitavel: true,
},
{
erro: "Iniciar múltiplas drogas sem tentar monoterapia",
descricao: "Sempre iniciar com monoterapia em HAS estágio 1",
penalidade: 1.5,
evitavel: true,
},
],
checklist_osce: [
{ item: "Investigou sintomas de alerta (cefaleia, tontura)", realizado: false, critico: true },
{ item: "Mediu PA corretamente bilateralmente", realizado: false, critico: true },
{ item: "Solicitou ECG", realizado: false, critico: true },
{ item: "Solicitou exames renais", realizado: false, critico: true },
{ item: "Orientou redução de sal e perda de peso", realizado: false, critico: true },
{ item: "Prescreveu anti-hipertensivo apropriado", realizado: false, critico: true },
],
rubrica_correcao: [
{
criterio: "Avaliação de Órgãos-Alvo",
peso: 20,
descricao: "Investigação de lesão em coração e rim",
pontuacao_maxima: 20,
},
{
criterio: "Orientação Comportamental",
peso: 20,
descricao: "Orientação sobre sal, peso e atividade",
pontuacao_maxima: 20,
},
{
criterio: "Terapia Farmacológica",
peso: 30,
descricao: "Seleção correta de anti-hipertensivo",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Cefaleia, tontura, zumbido",
"Fatores de risco: obesidade, DM2",
"Hábitos de vida",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Pressão arterial bilateral",
"Exame cardiovascular",
"ECG",
"Exames renais",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["HAS Estágio 1", "Avaliação de órgãos-alvo"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Anti-hipertensivo",
"Orientação dietética",
"Atividade física",
"Seguimento",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Investigou sintomatologia característica",
"Mediu PA bilateralmente",
"Solicitou ECG e exames renais",
"Prescreveu anti-hipertensivo",
"Orientou modificação de hábitos",
],
erros_comuns: [
"Prescrever múltiplas drogas imediatamente",
"Não investigar sintomas de alerta",
"Não solicitar exames complementares",
],
orientacoes_pedagogicas: [
"HAS primária é diagnóstico de exclusão",
"Sempre avalie órgãos-alvo",
"Monoterapia é primeira linha",
"Mudanças comportamentais são fundamentais",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer:
"Avaliação completa de HAS: confirmar diagnóstico com múltiplas aferições, excluir HAS secundária, avaliar órgãos-alvo (coração, rins, cérebro), dar orientações sobre estilo de vida ANTES de medicar, iniciar monoterapia se necessário. Não esquecer orientação não-farmacológica.",
comunicacao: [
"explicou o diagnóstico de forma clara",
"não assustou desnecessariamente",
"deu orientações sobre prevenção",
"explicou importância do seguimento",
],
anamnese: [
"investigou fatores de risco (tabagismo, álcool, stress)",
"perguntou sobre história familiar",
"investigou síntomas de lesão de órgão-alvo",
"perguntou sobre adesão a tratamentos prévios",
],
exame_fisico: [
"aferiu pressão arterial corretamente",
"realizou ausculta cardíaca",
"avaliou presença de edema",
"pesquisou outros sinais de gravidade",
],
exames_complementares: [
"solicitou eletrocardiograma",
"solicitou função renal (creatinina)",
"solicitou eletrólitos",
"solicitou perfil lipídico",
],
raciocinio: [
"reconheceu HAS estágio 1",
"investigou órgãos-alvo apropriadamente",
"avaliou risco cardiovascular global",
],
conduta: [
"orientou mudanças de estilo de vida PRIMEIRO",
"iniciou monoterapia se indicado",
"encaminhou para seguimento",
"instruiu sobre quando procurar emergência",
],
soap: [
"documentou múltiplas aferições de PA",
"registrou ausência de sintomas de órgão-alvo neste caso",
"reconheceu HAS estágio 1",
"planejou abordagem terapêutica apropriada",
],
},
temaOSCE: "HAS / sinais vitais",
subtopicosOSCE: [
"Técnica de medida de PA",
"HAS estágio 1 (140-159/90-99)",
"Avaliação de órgãos-alvo (coração, rins)",
"ECG para HVE",
"Função renal (creatinina)"
],
diagnosticoCorreto: "Hipertensão Arterial Sistêmica Estágio 1",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("5"),
} as CasoOSCEV2;
