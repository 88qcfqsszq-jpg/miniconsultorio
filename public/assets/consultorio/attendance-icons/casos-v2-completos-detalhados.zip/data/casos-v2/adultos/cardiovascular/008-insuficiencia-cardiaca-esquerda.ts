import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso008InsuficienciaCardiacaEsquerda: CasoOSCEV2 = {
// ====== CASO 8: INSUFICIÊNCIA CARDÍACA ESQUERDA ======
id: "8",
titulo: "Insuficiência Cardíaca Esquerda",
sistema: "Cardiovascular",
tema: "Insuficiência Cardíaca",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Diagnosticar insuficiência cardíaca sistólica e estabelecer terapia descongestiva",
dados_visiveis_ao_estudante: {
nome_paciente: "Fernanda Rocha",
idade: 67,
sexo: "Feminino",
queixa_principal: "Falta de ar ao fazer esforços",
historia_breve: "Sente falta de ar progressiva ao subir escada, acordando à noite com dificuldade respiratória",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Insuficiência Cardíaca Sistólica (FEVE reduzida)",
diagnosticos_diferenciais: [
"Asma",
"DPOC",
"Pneumonia",
"Tromboembolismo Pulmonar",
],
sindromes_associadas: ["Síndrome de congestão pulmonar"],
},
descricaoBreve: "Paciente com dispneia ao esforço, ortopneia, crepitações pulmonares",
categoria: "Insuficiência Cardíaca",
paciente: {
id: "pac-008",
nome: "Fernanda Rocha",
idade: 67,
sexo: "F",
queixaPrincipal: "Falta de ar ao fazer esforços",
historicoDoenca:
"Falta de ar progressiva ao subir escada, acordando à noite com dificuldade respiratória",
antecedentes: ["Hipertensão", "Infarto prévio 5 anos atrás"],
profissao: "Aposentada",
estado_civil: "Viúva",
alergias: [],
medicamentos_em_uso: ["Losartana 50mg", "Metoprolol 50mg"],
},
respostas_do_paciente: {
inicial: "Doutora, tenho muita falta de ar quando subir escada.",
dispneia: "Fico muito cansada, antes caminhava mais, agora só consigo andar um pouco.",
noturna: "Acordo à noite com falta de ar, preciso sentar na cama para respirar.",
posicao: "Só consigo dormir com vários travesseiros, não consigo ficar deitada.",
inchaço: "Meus pés incharam, os sapatos não entram.",
peso: "Aumentei de peso bastante, ganho quilos rápido.",
cansaco: "Fico muito cansada o tempo todo, nem consigo fazer nada.",
tosse: "Tenho uma tosse que aparece ao fazer esforço.",
},
respostaPaciente: {
inicial: "Doutora, tenho muita falta de ar quando subir escada.",
dispneia: "Fico muito cansada, antes caminhava mais, agora só consigo andar um pouco.",
noturna: "Acordo à noite com falta de ar, preciso sentar na cama para respirar.",
posicao: "Só consigo dormir com vários travesseiros, não consigo ficar deitada.",
inchaço: "Meus pés incharam, os sapatos não entram.",
peso: "Aumentei de peso bastante, ganho quilos rápido.",
cansaco: "Fico muito cansada o tempo todo, nem consigo fazer nada.",
tosse: "Tenho uma tosse que aparece ao fazer esforço.",
},
sinais_vitais: {
corretos: {
pressaoArterial: "150/95 mmHg",
frequenciaCardiaca: 102,
frequenciaRespiratoria: 28,
temperatura: 36.8,
saturacaoOxigenio: 90,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "150/95 mmHg",
frequenciaCardiaca: 102,
frequenciaRespiratoria: 28,
temperatura: 36.8,
saturacaoOxigenio: 90,
glicemia: 150,
},
exame_fisico: {
correto: {
inspecao: "Paciente taquipneica, com uso de musculatura acessória, palidez ligeira",
palpacao: "Ictus cordis desviado lateralmente (5º espaço além da linha meioaxilar), frêmito hipercinético",
ausculta:
"Taquicardia (110 bpm), sopro sistólico sugestivo de insuficiência mitral funcional, B3 (S3) em ápex, crepitações bibasais",
percussao: "Macicez em bases (derrame pleural leve)",
observacoes:
"Sinais clássicos de IC descompensada: B3, crepitações, desvio de ictus, edema periférico",
regiao: "Precórdio e pulmões",
achados_positivos: [
"B3",
"Crepitações",
"Desvio de ictus",
"Edema periférico",
],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Paciente taquipneica, com musculatura acessória",
palpacao: "Ictus cordis desviado",
ausculta: "B3, crepitações bibasais, sopro sistólico",
percussao: "Macicez de bases",
observacoes: "Sinais de congestão pulmonar e disfunção VE",
},
exames_complementares_disponiveis: [
{
nome: "ECG",
descricao: "12 derivações",
resultado: "Ritmo sinusal, taquicardia, complexo QRS alargado (140ms), onda T negativa em lateral",
valor_referencia: "Normal",
interpretacao: "Alterações compatíveis com cardiomiopatia",
},
{
nome: "BNP (B-type Natriuretic Peptide)",
descricao: "Marcador de insuficiência cardíaca",
resultado: "850 pg/mL",
valor_referencia: "<100 pg/mL",
interpretacao: "Altamente elevado, confirma IC",
},
{
nome: "Ecocardiograma",
descricao: "Ultrassom cardíaco",
resultado: "FEVE 28%, acinesia anterior, insuficiência mitral funcional moderada",
valor_referencia: "FEVE >50%",
interpretacao: "IC sistólica moderada a grave",
},
{
nome: "Radiografia de Tórax",
descricao: "PA e perfil",
resultado: "Cardiomegalia, congestão pulmonar, derrame pleural bilateral leve",
valor_referencia: "Normal",
interpretacao: "IC descompensada",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Insuficiência Cardíaca Sistólica",
probabilidade: 95,
criterios_minimos: [
"Dispneia ao esforço e ortopneia",
"Edema periférico",
"Crepitações pulmonares",
"B3",
"FEVE reduzida",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Asma",
criterios_exclusao: ["B3 presente"],
achados_que_descartam: ["Crepitações finas, FEVE reduzida"],
},
],
examesIndicados: [
"ECG",
"Ecocardiograma",
"BNP",
"Radiografia de tórax",
"Hemograma",
"Função renal",
],
conduta_esperada: {
imediata: [
"Diurético intravenoso (Furosemida 40-80mg IV)",
"Oxigenioterapia",
"Posição semi-Fowler",
"Restrição hídrica",
],
curto_prazo: [
"ACE inibidor ou ARB",
"Betabloqueador",
"Repouso no leito inicialmente",
"Monitorização de eletrólitos",
],
longo_prazo: [
"Seguimento cardiológico",
"Reabilitação cardíaca",
"Considerar ressincronização se QRS >120ms",
],
encaminhamentos: ["Cardiologia", "Insuficiência cardíaca avançada"],
},
condutaCorreta:
"Diurético IV, ACE inibidor, betabloqueador, oxigenio, restrição hídrica, ecocardiograma",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["Ortopneia", "Crepitações", "SpO2 90%"],
descricao: "IC descompensada com congestão pulmonar",
recomendacao: "Internação, diurético IV, otimização terapia",
},
{
severidade: "grave",
sinais: ["SpO2 <90%", "Necessita ventilação", "Choque"],
descricao: "IC descompensada grave",
recomendacao: "Internação em UTI, inotrópicos, suporte avançado",
},
],
erros_criticos: [
{
erro: "Não prescrever diurético em IC congestiva",
descricao: "Diurético é essencial para aliviar congestão",
penalidade: 2.5,
evitavel: true,
},
{
erro: "Não solicitar ecocardiograma",
descricao: "Ecocardiograma confirma diagnóstico e FEVE",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{ item: "Investigou ortopneia e dispneia noturna", realizado: false, critico: true },
{ item: "Mediu sinais vitais (SpO2, FR)", realizado: false, critico: true },
{ item: "Ausculta: buscou B3 e crepitações", realizado: false, critico: true },
{ item: "Palpou: desvio de ictus", realizado: false, critico: true },
{ item: "Solicitou ECG", realizado: false, critico: true },
{ item: "Solicitou ecocardiograma", realizado: false, critico: true },
{ item: "Prescreveu diurético IV", realizado: false, critico: true },
],
rubrica_correcao: [
{
criterio: "Reconhecimento de Sinais",
peso: 20,
descricao: "B3, crepitações, ortopneia",
pontuacao_maxima: 20,
},
{
criterio: "Terapia Descongestiva",
peso: 25,
descricao: "Prescrição de diurético apropriado",
pontuacao_maxima: 25,
},
{
criterio: "Avaliação de FEVE",
peso: 25,
descricao: "Solicitação e interpretação de ecocardiograma",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dispneia ao esforço progressiva",
"Ortopneia",
"Dispneia paroxística noturna",
"Edema de MMII",
"Fatores de risco: HAS, IAM prévio",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Sinais vitais: taquicardia, taquipneia, SpO2 reduzida",
"Ausculta: B3, crepitações bibasais",
"Palpação: ictus desviado",
"Edema periférico",
"Ecocardiograma: FEVE reduzida",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"IC sistólica com congestão pulmonar",
"NYHA II-III",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Diurético IV",
"ACE inibidor",
"Betabloqueador",
"Restrição hídrica",
"Internação e monitorização",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Investigou ortopneia e dispneia noturna",
"Reconheceu B3 e crepitações",
"Solicitou ecocardiograma",
"Iniciou diurético IV",
"Prescreveu ACE inibidor",
],
erros_comuns: [
"Confundir com asma",
"Não prescrever diurético",
"Não solicitar ecocardiograma",
],
orientacoes_pedagogicas: [
"IC: dispneia ao esforço + ortopneia + edema",
"Achados: B3, crepitações, desvio de ictus",
"Ecocardiograma é essencial para diagnóstico",
"Diurético + ACE inibidor + betabloqueador",
"Reabilitação cardíaca é importante",
],
},
temaOSCE: "Insuficiência Cardíaca",
subtopicosOSCE: [
"IC sistólica (redução de FEVE)",
"Congestão pulmonar (ortopneia, dispneia)",
"B3 (galope)",
"BNP/NT-proBNP elevado",
"Ecocardiograma com FEVE reduzida"
],
diagnosticoCorreto: "Insuficiência Cardíaca Sistólica",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("8"),
} as CasoOSCEV2;
