import { casoPed001FebreEmCriancaDe4Anos } from "./pediatricos/infectologia/ped-01-febre-em-crianca-de-4-anos";
import { casoPed002ConsultaDePuericulturaLactenteDe8 } from "./pediatricos/puericultura/ped-02-consulta-de-puericultura-lactente-de-8-meses";
import { casoPed003AvaliacaoDePressaoArterialMeninaDe } from "./pediatricos/cardiovascular/ped-03-avaliacao-de-pressao-arterial-menina-de-4-anos";
import { casoPed004AvaliacaoDeDesenvolvimentoLactenteDe10 } from "./pediatricos/neurologico-desenvolvimento/ped-04-avaliacao-de-desenvolvimento-lactente-de-10-meses";
import { casoPed005InsuficienciaCardiacaEmLactente4Meses } from "./pediatricos/cardiovascular/ped-05-insuficiencia-cardiaca-em-lactente-4-meses";
import { casoPed006SuspeitaDeMausTratosMeninaDe } from "./pediatricos/protecao-infantil/ped-06-suspeita-de-maus-tratos-menina-de-6-anos";
import { casoPed007CardiopatiaCongenitaAcianoticaLactenteDe3 } from "./pediatricos/cardiovascular/ped-07-cardiopatia-congenita-acianotica-lactente-de-3-meses";
import { casoPed008CardiopatiaCongenitaCianoticaLactenteDe6 } from "./pediatricos/cardiovascular/ped-08-cardiopatia-congenita-cianotica-lactente-de-6-meses";
import { casoPed009PericarditeAgudaMeninoDe12Anos } from "./pediatricos/cardiovascular/ped-09-pericardite-aguda-menino-de-12-anos";
import { casoPed010TuberculosePulmonarCriancaDe7Anos } from "./pediatricos/infectologia/ped-10-tuberculose-pulmonar-crianca-de-7-anos";
import { casoPed011AsmaNaInfanciaCriancaDe7 } from "./pediatricos/respiratorio/ped-11-asma-na-infancia-crianca-de-7-anos";
import { casoPed012RinossinusiteBacterianaCriancaDe9Anos } from "./pediatricos/respiratorio/ped-12-rinossinusite-bacteriana-crianca-de-9-anos";
import { casoPed013PneumoniaAdquiridaNaComunidadeCriancaDe } from "./pediatricos/respiratorio/ped-13-pneumonia-adquirida-na-comunidade-crianca-de-5-anos";
import { casoPed014LinfonodomegaliaCervicalCriancaDe7Anos } from "./pediatricos/infectologia/ped-14-linfonodomegalia-cervical-crianca-de-7-anos";
import { casoPed015AnemiaComSinaisDeAlertaCrianca } from "./pediatricos/hematologia/ped-15-anemia-com-sinais-de-alerta-crianca-de-8-anos";
import { casoPed016SuspeitaDeDengueCriancaDe8 } from "./pediatricos/infectologia/ped-16-suspeita-de-dengue-crianca-de-8-anos";

export const casosPediatricosV3 = [
  casoPed001FebreEmCriancaDe4Anos,
  casoPed002ConsultaDePuericulturaLactenteDe8,
  casoPed003AvaliacaoDePressaoArterialMeninaDe,
  casoPed004AvaliacaoDeDesenvolvimentoLactenteDe10,
  casoPed005InsuficienciaCardiacaEmLactente4Meses,
  casoPed006SuspeitaDeMausTratosMeninaDe,
  casoPed007CardiopatiaCongenitaAcianoticaLactenteDe3,
  casoPed008CardiopatiaCongenitaCianoticaLactenteDe6,
  casoPed009PericarditeAgudaMeninoDe12Anos,
  casoPed010TuberculosePulmonarCriancaDe7Anos,
  casoPed011AsmaNaInfanciaCriancaDe7,
  casoPed012RinossinusiteBacterianaCriancaDe9Anos,
  casoPed013PneumoniaAdquiridaNaComunidadeCriancaDe,
  casoPed014LinfonodomegaliaCervicalCriancaDe7Anos,
  casoPed015AnemiaComSinaisDeAlertaCrianca,
  casoPed016SuspeitaDeDengueCriancaDe8,
];

export type { CasoPediatricoOSCEV2 } from "@/types/caso-pediatrico-osce-v2";
