import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso051HemofiliaA: CasoOSCEV2 = {
// ====== CASO 51: HEMOFILIA A ======
id: "51",
titulo: "Hemofilia A",
sistema: "Hematologia",
tema: "Coagulopatias",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 11,
objetivo_pedagogico: "Diagnosticar hemofilia por sangramento espontâneo e testes de coagulação",
dados_visiveis_ao_estudante: {
nome_paciente: "Rafael Santos",
idade: 16,
sexo: "Masculino",
queixa_principal: "Sangramento articular, hematomas fáceis",
historia_breve: "Adolescente com sangramento recorrente em joelho",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Hemofilia A",
diagnosticos_diferenciais: ["Hemofilia B", "Doença de von Willebrand", "Trombocitopenia"],
sindromes_associadas: ["Hemartrose", "Hemorragia musculoesquelética"],
},
descricaoBreve: "Paciente com hemartrose, sangramento espontâneo, TTPa prolongado, dosagem baixa de fator VIII",
categoria: "Coagulopatias",
paciente: {
id: "pac-051",
nome: "Rafael Santos",
idade: 16,
sexo: "M",
queixaPrincipal: "Sangramento articular",
historicoDoenca: "Episódios recorrentes de hemartrose",
antecedentes: ["História familiar de sangramento"],
profissao: "Estudante",
estado_civil: "Solteiro",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Meu joelho fica inchado e dói muito por causa de sangramento",
sangramento_articular: "Sim, principalmente joelho",
hematomas: "Sim, roxo fácil por qualquer coisa",
sangramento_nasal: "Sim, às vezes",
historia_familiar: "Meu avó tinha algo parecido",
dor_articular: "Muita dor no joelho",
duracao: "Episódios desde criança",
},
respostaPaciente: {
inicial: "Sangramento articular e hematomas",
sangramento_articular: "Sim",
hematomas: "Fácil",
sangramento_nasal: "Sim",
historia_familiar: "Sim",
dor_articular: "Muita",
duracao: "Desde criança",
},
sinais_vitais: {
corretos: {
pressaoArterial: "120/75 mmHg",
frequenciaCardiaca: 80,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "120/75 mmHg",
frequenciaCardiaca: 80,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 98,
},
exame_fisico: {
correto: {
inspecao: "Hematomas em MMII, edema articular em joelho",
palpacao: "Articulação dolorosa, limitação de movimento",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Hemartrose aguda",
regiao: "Membros inferiores",
achados_positivos: ["Hematomas", "Edema articular", "Hemartrose"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Hematomas e edema",
palpacao: "Hemartrose dolorosa",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Hemofilia",
},
exame_fisico_interativo: {
membros: {
edema: "Joelho com hemartrose",
mobilidade: "Muito limitada por dor",
},
},
exames_complementares_disponiveis: [
{
nome: "TP",
descricao: "Tempo de protrombina",
resultado: "12 segundos",
valor_referencia: "11-13.5 segundos",
interpretacao: "Normal",
},
{
nome: "TTPa",
descricao: "Tempo de tromboplastina parcial ativada",
resultado: "52 segundos",
valor_referencia: "25-35 segundos",
interpretacao: "Prolongado",
},
{
nome: "Fator VIII",
descricao: "Atividade de fator VIII",
resultado: "8%",
valor_referencia: ">70%",
interpretacao: "Deficiência severa",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Hemofilia A",
probabilidade: 95,
criterios_minimos: [
"Sangramento articular espontâneo",
"TTPa prolongado",
"Fator VIII baixo",
"História familiar",
"TP normal",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Hemofilia B",
criterios_exclusao: ["Fator VIII normal", "Fator IX baixo"],
achados_que_descartam: ["Fator VIII baixo"],
},
],
examesIndicados: [
"TP, TTPa, PT",
"Dosagem de fator VIII",
"Se TTPa prolongado: painel de fatores de coagulação",
],
conduta_esperada: {
imediata: [
"Repouso e elevação",
"Reposição de fator VIII",
],
curto_prazo: [
"Fisioterapia",
"Educação sobre atividades",
],
longo_prazo: [
"Acompanhamento hematológico",
"Inibidor de fibrinólise se indicado",
],
encaminhamentos: ["Hematologia"],
},
condutaCorreta: "TTPa e dosagem fator VIII, reposição de fator VIII, repouso, hematologia",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["Hemartrose", "Fator VIII <10%"],
descricao: "Hemofilia severa com risco de deficiências",
recomendacao: "Reposição de fator VIII",
},
],
erros_criticos: [
{
erro: "Prescrever AINE",
descricao: "Aumenta sangramento",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu coagulopatia",
realizado: false,
critico: true,
},
{
item: "Solicitou TTPa",
realizado: false,
critico: true,
},
{
item: "Dosou fator VIII",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de hemofilia",
peso: 25,
descricao: "Achados clínicos",
pontuacao_maxima: 25,
},
{
criterio: "Diagnóstico diferencial",
peso: 20,
descricao: "Fator VIII vs. IX",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Hemartrose",
"História familiar",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Edema articular",
"TTPa prolongado",
"Fator VIII baixo",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Hemofilia A"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Reposição de fator VIII",
"Hematologia",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu hemofilia",
"Solicitou TTPa",
"Dosou fator VIII",
],
erros_comuns: ["Confundir com hemofilia B"],
orientacoes_pedagogicas: [
"Hemofilia A: fator VIII baixo",
"Hemofilia B: fator IX baixo",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar hemofilia por achados clínicos e laboratoriais",
comunicacao: ["explicou importância da reposição"],
anamnese: ["investigou história familiar"],
exame_fisico: ["detectou hemartrose"],
exames_complementares: ["pediu TTPa e fator VIII"],
raciocinio: ["diagnosticou hemofilia A"],
conduta: ["prescreveu fator VIII"],
soap: ["documentou hemofilia"],
},
temaOSCE: "Coagulopatias",
subtopicosOSCE: [
"Hemofilia A",
"Hemartrose",
"Fator VIII baixo",
"TTPa prolongado",
"Sangramento espontâneo",
],
diagnosticoCorreto: "Hemofilia A",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("51"),
} as CasoOSCEV2;
