import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso060CetoacidoseDiabetica: CasoOSCEV2 = {
// ====== CASO 60: CETOACIDOSE DIABÉTICA ======
id: "60",
titulo: "Cetoacidose Diabética",
sistema: "Endocrinologia",
tema: "Casos Integradores",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 13,
objetivo_pedagogico: "Diagnosticar cetoacidose diabética e manejar emergência metabólica",
dados_visiveis_ao_estudante: {
nome_paciente: "Lucas Ferreira",
idade: 18,
sexo: "Masculino",
queixa_principal: "Respiração profunda rápida, náusea, dor abdominal, confusão",
historia_breve: "Adolescente com diabetes tipo 1 de novo diagnóstico",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Cetoacidose Diabética",
diagnosticos_diferenciais: ["Gastroenterite", "Sepse", "Meningite"],
sindromes_associadas: ["Acidose metabólica", "Desidratação"],
},
descricaoBreve: "Paciente com respiração de Kussmaul, cetose, glicemia >300, pH <7.3, cetonas positivas",
categoria: "Casos Integradores",
paciente: {
id: "pac-060",
nome: "Lucas Ferreira",
idade: 18,
sexo: "M",
queixaPrincipal: "Distresse respiratório",
historicoDoenca: "Sintomas agudos há 12 horas",
antecedentes: ["Diabetes tipo 1 novo"],
profissao: "Estudante",
estado_civil: "Solteiro",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Tenho muita dor na barriga, respiração estranho, muito ruim",
respiracao: "Respiração muito profunda e rápida",
nausea: "Muita náusea e vômitos",
dor_abdominal: "Dor intensa no abdômen",
confusao: "Confuso, tonteado",
fadiga: "Muito cansado",
sede: "Muita sede",
},
respostaPaciente: {
inicial: "Distresse respiratório e dor abdominal",
respiracao: "Profunda e rápida",
nausea: "Muita",
dor_abdominal: "Intensa",
confusao: "Sim",
fadiga: "Muita",
sede: "Muita",
},
sinais_vitais: {
corretos: {
pressaoArterial: "105/65 mmHg",
frequenciaCardiaca: 125,
frequenciaRespiratoria: 32,
temperatura: 37.5,
saturacaoOxigenio: 95,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "105/65 mmHg",
frequenciaCardiaca: 125,
frequenciaRespiratoria: 32,
temperatura: 37.5,
saturacaoOxigenio: 95,
},
exame_fisico: {
correto: {
inspecao: "Respiração de Kussmaul (profunda e rápida), odor de acetona, desidratação",
palpacao: "Turgor reduzido, abdômen sensível",
ausculta: "Taquicardia",
percussao: "Normal",
observacoes: "Sinais de cetoacidose diabética",
regiao: "Geral",
achados_positivos: [
"Kussmaul",
"Odor de acetona",
"Desidratação",
"Taquicardia",
],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Kussmaul, odor de acetona",
palpacao: "Desidratação",
ausculta: "Taquicardia",
percussao: "Normal",
observacoes: "CAD",
},
exame_fisico_interativo: {
respiratorio: {
padrao_respiratorio: "Kussmaul",
},
},
exames_complementares_disponiveis: [
{
nome: "Glicemia",
descricao: "Glicose em jejum",
resultado: "450 mg/dL",
valor_referencia: "<100 mg/dL",
interpretacao: "Hiperglicemia severa",
},
{
nome: "Eletrólitos",
descricao: "Sódio, potássio",
resultado: "Na 130, K 5.8",
valor_referencia: "Na 135-145, K 3.5-5.0",
interpretacao: "Hiponatremia dilucional e hiperkalemia",
},
{
nome: "pH arterial",
descricao: "Acidose",
resultado: "7.18",
valor_referencia: ">7.35",
interpretacao: "Acidose severa",
},
{
nome: "HCO3",
descricao: "Bicarbonato",
resultado: "8 mEq/L",
valor_referencia: ">24 mEq/L",
interpretacao: "Acidose metabólica severa",
},
{
nome: "Cetonas",
descricao: "Corpos cetônicos",
resultado: "+++ (grandes quantidades)",
valor_referencia: "Negativa",
interpretacao: "Cetose severa",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Cetoacidose Diabética",
probabilidade: 98,
criterios_minimos: [
"Glicemia >250",
"pH <7.3",
"HCO3 <18",
"Cetonas positivas",
"Respiração de Kussmaul",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Gastroenterite",
criterios_exclusao: ["Acidose severa", "Cetonas"],
achados_que_descartam: ["CAD"],
},
],
examesIndicados: [
"Gasometria arterial",
"Eletrólitos seriados",
"Glicemia seriada",
"Cetona sérica ou urinária",
"Hemograma, função renal",
],
conduta_esperada: {
imediata: [
"CTI/Emergência",
"Insulina IV contínua",
"Fluidos IV agressivos",
"Reposição de potássio",
],
curto_prazo: [
"Monitorização contínua",
"Correção de eletrólitos",
],
longo_prazo: [
"Educação diabética",
],
encaminhamentos: ["CTI", "Endocrinologia"],
},
condutaCorreta: "CTI urgente, insulina IV, fluidos IV rápido, reposição K, gasometria seriada",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["pH <7.1", "Confusão", "Choque"],
descricao: "CAD severa com risco de morte",
recomendacao: "CTI com suporte máximo",
},
],
erros_criticos: [
{
erro: "Não reconhecer CAD",
descricao: "Emergência com alta mortalidade",
penalidade: 3,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu CAD",
realizado: false,
critico: true,
},
{
item: "Solicitou gasometria",
realizado: false,
critico: true,
},
{
item: "Encaminhou CTI",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de CAD",
peso: 35,
descricao: "Kussmaul + acidose",
pontuacao_maxima: 35,
},
{
criterio: "Manejo de emergência",
peso: 30,
descricao: "Insulina IV e fluidos",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Respiração profunda",
"Náusea",
"Dor abdominal",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Kussmaul",
"Glicemia 450",
"pH 7.18",
"Cetonas positivas",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Cetoacidose diabética",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"CTI",
"Insulina IV",
"Fluidos IV",
"Gasometria seriada",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu CAD",
"Solicitou gasometria",
"Encaminhou CTI",
"Prescreveu insulina",
],
erros_comuns: ["Achar que é gastroenterite"],
orientacoes_pedagogicas: [
"CAD: Kussmaul + acidose + glicemia elevada + cetonas",
"Emergência com mortalidade 5-10% sem tratamento",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer CAD como emergência máxima",
comunicacao: ["explicou urgência crítica"],
anamnese: ["investigou sintomas"],
exame_fisico: ["detectou Kussmaul"],
exames_complementares: ["pediu gasometria"],
raciocinio: ["diagnosticou CAD"],
conduta: ["encaminhou CTI"],
soap: ["documentou urgência"],
},
temaOSCE: "Casos Integradores",
subtopicosOSCE: [
"Cetoacidose diabética",
"Acidose metabólica",
"Respiração Kussmaul",
"Hiperglicemia",
"Emergência",
],
diagnosticoCorreto: "Cetoacidose Diabética",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("60"),
} as CasoOSCEV2;
