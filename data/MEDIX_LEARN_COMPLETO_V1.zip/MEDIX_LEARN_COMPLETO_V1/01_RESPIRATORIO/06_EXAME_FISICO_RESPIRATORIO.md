# Trilha Respiratório — Exame Físico Respiratório

## Papel dentro do MEDIX Learn
Trilha prática para transformar inspeção, palpação, percussão e ausculta em hipóteses clínicas.

## Objetivo pedagógico
Ensinar exame respiratório como raciocínio, não como checklist decorado.

## Competências ao final
- Medir e interpretar FR.
- Reconhecer esforço respiratório.
- Avaliar expansibilidade.
- Interpretar percussão.
- Diferenciar sibilos, roncos, crepitações e ausência de murmúrio.
- Associar padrões a doenças.

## Sequência didática padrão
1. **Microaula** — conceito central em linguagem simples.
2. **Fisiologia aplicada** — mecanismo que explica o sinal/sintoma.
3. **Semiologia** — como o mecanismo aparece no paciente.
4. **Raciocínio clínico** — como diferenciar causas próximas.
5. **Mini-casos** — aplicação curta, com pergunta e feedback.
6. **Questões ativas** — perguntas que obrigam o aluno a pensar.
7. **Erros comuns** — atalhos mentais perigosos.
8. **Mapa final** — síntese visual/textual.
9. **Ponte para OSCE** — para onde o aluno vai treinar depois.

## Blocos obrigatórios da trilha
- Inspeção: FR, padrão, tiragem, cianose.
- Palpação: expansibilidade e frêmito.
- Percussão: macicez vs hipertimpanismo.
- Ausculta: MV, sibilos, roncos, crepitações, atrito pleural.
- Sínteses: consolidação, derrame, pneumotórax, obstrução.

## Mini-casos sugeridos
- Consolidação pneumônica.
- Pneumotórax.
- Derrame pleural.
- Asma/DPOC.
- Edema pulmonar.

## Questões ativas-base
1. O que sugere hipertimpanismo unilateral?
2. O que sugere macicez com MV reduzido?
3. Qual diferença entre sibilo e crepitação?

## Erros comuns a corrigir
- Auscultar sem olhar o paciente.
- Não contar FR.
- Interpretar achado isolado sem contexto.
- Ignorar assimetria.

## Ponte para OSCE
OSCE Ciclo Básico: exame físico respiratório completo. OSCE Clínico: reavaliação após intervenção.
