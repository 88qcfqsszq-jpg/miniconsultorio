# Trilha Respiratório — Tosse e Febre

## Papel dentro do MEDIX Learn
Trilha para raciocínio de infecção respiratória e diferenciais, sem reduzir tudo a antibiótico.

## Objetivo pedagógico
Ensinar a caracterizar tosse/febre e reconhecer pneumonia, viroses, TB, exacerbação de DPOC e gravidade.

## Competências ao final
- Diferenciar tosse seca/produtiva, aguda/crônica.
- Identificar sinais de pneumonia.
- Reconhecer sinais de gravidade infecciosa.
- Saber quando RX e exames importam.
- Diferenciar suporte de tratamento etiológico.

## Sequência didática padrão
1. **Microaula** — conceito central em linguagem simples.
2. **Fisiologia aplicada** — mecanismo que explica o sinal/sintoma.
3. **Semiologia** — como o mecanismo aparece no paciente.
4. **Raciocínio clínico** — como diferenciar causas próximas.
5. **Mini-casos** — aplicação curta, com pergunta e feedback.
6. **Questões ativas** — perguntas que obrigam o aluno a pensar.
7. **Erros comuns** — atalhos mentais perigosos.
8. **Mapa final** — síntese visual/textual.
9. **Ponte para OSCE** — para onde o aluno vai treinar depois.

## Blocos obrigatórios da trilha
- Tosse: duração, escarro, hemoptise, gatilhos.
- Febre: padrão, calafrios, sinais sistêmicos.
- Pneumonia típica/atípica.
- Consolidação e crepitações.
- TB e tosse crônica.
- Sinais de gravidade: FR, SpO₂, PA, confusão, comorbidades.

## Mini-casos sugeridos
- Pneumonia comunitária.
- IVAS/bronquite viral.
- Tuberculose suspeita.
- DPOC exacerbado infeccioso.
- Influenza/COVID com dispneia.

## Questões ativas-base
1. Escarro purulento sempre significa antibiótico?
2. Quando tosse e febre viram sinal de gravidade?
3. Por que SpO₂ baixa muda a prioridade?

## Erros comuns a corrigir
- Antibiótico automático para toda tosse.
- Ignorar FR.
- Não perguntar duração.
- Não considerar TB em tosse persistente.

## Ponte para OSCE
OSCE Ciclo Básico: pneumonia. OSCE Clínico: pneumonia grave com resposta a oxigênio/antibiótico.
