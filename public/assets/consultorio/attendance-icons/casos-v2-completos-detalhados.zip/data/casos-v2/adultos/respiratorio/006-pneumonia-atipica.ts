import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso006PneumoniaAtipica: CasoOSCEV2 = {
// ====== CASO 6: PNEUMONIA ATÍPICA ======
id: "6",
titulo: "Pneumonia Atípica",
sistema: "Respiratório",
tema: "Infecção Respiratória",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Diferenciar pneumonia atípica de pneumonia típica e prescrever antibióticoterapia apropriada",
dados_visiveis_ao_estudante: {
nome_paciente: "Pedro Costa",
idade: 35,
sexo: "Masculino",
queixa_principal: "Tosse seca persistente há 2 semanas",
historia_breve: "Tosse seca que piorou progressivamente, febre baixa, mal-estar geral",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Pneumonia Atípica (provavelmente Mycoplasma pneumoniae)",
diagnosticos_diferenciais: [
"Bronquite Aguda",
"Tuberculose",
"Pneumonia Viral",
"Refluxo Gastroesofágico com tosse",
],
sindromes_associadas: ["Infecção de Trato Respiratório"],
},
descricaoBreve: "Paciente com tosse seca prolongada, febre baixa, infiltrado intersticial em RX",
categoria: "Pneumonia",
paciente: {
id: "pac-006",
nome: "Pedro Costa",
idade: 35,
sexo: "M",
queixaPrincipal: "Tosse seca persistente há 2 semanas",
historicoDoenca: "Tosse seca que piorou progressivamente, febre baixa, mal-estar",
antecedentes: ["Sem antecedentes relevantes"],
profissao: "Analista de sistemas",
estado_civil: "Solteiro",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Doutor, tô com essa tosse chata que não melhora.",
tosse: "É seca mesmo, não sai catarro nenhum.",
inicio: "Começou umas 2 semanas atrás, tava gripado.",
febre: "Tenho uma febrinha, nada muito alto, umas 37-38 graus.",
respiracao: "Um pouco, fico cansado ao caminar.",
dor_peito: "Sinto um incômodo no peito quando respiro fundo.",
corpo_dói: "Sim, dói o corpo todo, tipo uma mialgia.",
outro_sintoma: "Fico fraco, sem energia mesmo.",
tratamento: "Tomei uns xarope e nada ajuda muito.",
},
respostaPaciente: {
inicial: "Doutor, tô com essa tosse chata que não melhora.",
tosse: "É seca mesmo, não sai catarro nenhum.",
inicio: "Começou umas 2 semanas atrás, tava gripado.",
febre: "Tenho uma febrinha, nada muito alto, umas 37-38 graus.",
respiracao: "Um pouco, fico cansado ao caminar.",
dor_peito: "Sinto um incômodo no peito quando respiro fundo.",
corpo_dói: "Sim, dói o corpo todo, tipo uma mialgia.",
outro_sintoma: "Fico fraco, sem energia mesmo.",
tratamento: "Tomei uns xarope e nada ajuda muito.",
},
sinais_vitais: {
corretos: {
pressaoArterial: "125/80 mmHg",
frequenciaCardiaca: 95,
frequenciaRespiratoria: 22,
temperatura: 37.8,
saturacaoOxigenio: 94,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "125/80 mmHg",
frequenciaCardiaca: 95,
frequenciaRespiratoria: 22,
temperatura: 37.8,
saturacaoOxigenio: 94,
glicemia: 125,
},
exame_fisico: {
correto: {
inspecao: "Paciente febril, tosse ocasional, sem desconforto respiratório grave",
palpacao: "Expansão torácica simétrica",
ausculta: "Murmúrio vesicular presente bilateralmente, ocasional ronco localizado",
percussao: "Normal",
observacoes:
"Ausência de crepitações consolidativas, achados compatíveis com infecção viral/atípica",
regiao: "Pulmões",
achados_positivos: ["Febre", "Tosse seca", "Mialgia"],
achados_negativos: ["Crepitações", "Consolidação"],
},
},
exameFisicoCorreto: {
inspecao: "Paciente febril, tosse ocasional",
palpacao: "Expansão torácica simétrica",
ausculta: "Murmúrio vesicular presente, ocasional ronco",
percussao: "Normal",
observacoes: "Sem crepitações consolidativas",
},
exames_complementares_disponiveis: [
{
nome: "Radiografia de Tórax PA e Perfil",
descricao: "Avaliação pulmonar",
resultado: "Infiltrado intersticial bilateral, predomínio peri-hilar",
valor_referencia: "Sem infiltrados",
interpretacao: "Compatível com pneumonia atípica/viral",
},
{
nome: "Hemograma Completo",
descricao: "Série de glóbulos",
resultado: "Leucócitos 9.500/mm³, linfócitos aumentados",
valor_referencia: "4.500-11.000/mm³",
interpretacao: "Leve elevação com padrão viral/atípico",
},
{
nome: "PCR (Proteína C Reativa)",
descricao: "Marcador inflamatório",
resultado: "Elevada",
valor_referencia: "<3 mg/dL",
interpretacao: "Inflamação presente",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Pneumonia Atípica",
probabilidade: 80,
criterios_minimos: [
"Tosse seca persistente",
"Febre baixa",
"Infiltrado intersticial em RX",
"Ausência de consolidação lobar",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Pneumonia Bacteriana Típica",
criterios_exclusao: ["Ausência de consolidação lobar"],
achados_que_descartam: ["Infiltrado intersticial, não lobar"],
},
],
examesIndicados: [
"Raio X de tórax PA e perfil",
"Hemograma",
"PCR",
"Sorologia para Mycoplasma se disponível",
],
conduta_esperada: {
imediata: [
"Prescrever macrolídeo (azitromicina) ou tetraciclina",
"Orientar repouso",
"Hidratação adequada",
],
curto_prazo: [
"Monitorização de sintomas",
"Avaliação após 1-2 semanas",
"Raio X de controle se necessário",
],
longo_prazo: ["Seguimento para resolução", "Investigação se não melhorar"],
encaminhamentos: ["Pneumologia se sintomas persistirem"],
},
condutaCorreta:
"Prescrever macrolídeo (azitromicina), hidratação, repouso, raio X de tórax para investigação",
criterios_de_gravidade: [
{
severidade: "leve",
sinais: ["Febre <39°C", "SpO2 >94%", "FR 20-24"],
descricao: "Pneumonia atípica sem sinais de gravidade",
recomendacao: "Tratamento ambulatorial com seguimento",
},
],
erros_criticos: [
{
erro: "Prescrever betalactâmico (penicilina) para pneumonia atípica",
descricao: "Mycoplasma é resistente a betalactâmicos, usar macrolídeo",
penalidade: 2,
evitavel: true,
},
{
erro: "Não solicitar RX de tórax",
descricao: "RX é essencial para diferenciar atípica de típica",
penalidade: 1.5,
evitavel: true,
},
],
checklist_osce: [
{ item: "Caracterizou a tosse (seca vs produtiva)", realizado: false, critico: true },
{ item: "Perguntou sobre febre", realizado: false, critico: true },
{ item: "Mediu sinais vitais completos", realizado: false, critico: true },
{ item: "Realizou ausculta pulmonar", realizado: false, critico: true },
{ item: "Solicitou radiografia de tórax", realizado: false, critico: true },
{ item: "Prescreveu macrolídeo", realizado: false, critico: true },
],
rubrica_correcao: [
{
criterio: "Diagnóstico Diferencial",
peso: 20,
descricao: "Diferenciação entre atípica e típica",
pontuacao_maxima: 20,
},
{
criterio: "Exames Complementares",
peso: 20,
descricao: "Interpretação correta de RX intersticial",
pontuacao_maxima: 20,
},
{
criterio: "Antibióticoterapia",
peso: 30,
descricao: "Prescrição de macrolídeo",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Tosse seca prolongada",
"Febre baixa",
"Mialgia",
"Exposição a vírus",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Sinais vitais",
"Ausculta: sem crepitações",
"RX: infiltrado intersticial",
"Hemograma com padrão viral",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Pneumonia atípica", "Sem sinais de gravidade"],
},
plano: {
secao: "P",
componentes_obrigatorios: ["Macrolídeo", "Hidratação", "Repouso", "Seguimento"],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu padrão de tosse seca prolongada",
"Solicitou RX e viu infiltrado intersticial",
"Prescreveu macrolídeo",
"Orientou repouso e hidratação",
],
erros_comuns: [
"Prescrever penicilina",
"Não diferenciar padrão de RX",
"Não investigar adequadamente",
],
orientacoes_pedagogicas: [
"Pneumonia atípica: tosse seca, febre baixa, mialgia",
"RX: infiltrado intersticial, não lobar",
"Ausência de crepitações consolidativas",
"Macrolídeo é a droga de escolha",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer:
"Reconhecer pneumonia atípica: história com tosse persistente, febre baixa, RX com infiltrado intersticial (não lobar consolidado), ausência de crepitações consolidativas. Prescrever macrolídeo, não penicilina. Investigação apropriada com história e RX.",
comunicacao: [
"explicou diferença entre pneumonia típica e atípica",
"tranquilizou paciente sobre prognóstico",
"explicou por que RX é importante",
],
anamnese: [
"investigou duração prolongada da tosse",
"perguntou sobre natureza da tosse (seca vs produtiva)",
"investigou febre baixa prolongada",
"perguntou sobre contatos com doenças",
],
exame_fisico: [
"solicitou sinais vitais",
"ausculta pulmonar à procura de crepitações",
"avaliou padrão respiratório",
],
exames_complementares: [
"solicitou radiografia de tórax",
"solicitou hemograma",
"considerou sorologia se indicado",
],
raciocinio: [
"integrou história + ausculta + padrão RX",
"reconheceu padrão de pneumonia atípica",
"diferenciou de pneumonia bacteriana típica",
],
conduta: [
"prescreveu macrolídeo apropriadamente",
"NÃO prescreveu penicilina",
"deu orientações de seguimento",
],
soap: [
"documentou tosse seca prolongada",
"registrou febre baixa",
"reconheceu padrão intersticial no RX",
"planejou antibioticoterapia com macrolídeo",
],
},
temaOSCE: "Pneumonia",
subtopicosOSCE: [
"Pneumonia atípica (Mycoplasma)",
"Tosse seca prolongada",
"Infiltrado intersticial em RX",
"Macrolídeos como primeira linha",
"Apresentação clínica diferente de PAC típica"
],
diagnosticoCorreto: "Pneumonia Atípica",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("6"),
} as CasoOSCEV2;
