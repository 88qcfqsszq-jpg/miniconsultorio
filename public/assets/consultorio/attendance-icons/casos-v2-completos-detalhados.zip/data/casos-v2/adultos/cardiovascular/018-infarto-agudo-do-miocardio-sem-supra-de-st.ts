import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso018InfartoAgudoDoMiocardioSem: CasoOSCEV2 = {
// ====== CASO 18: IAM SEM SUPRA DE ST ======
id: "18",
titulo: "Infarto Agudo do Miocárdio sem Supra de ST",
sistema: "Cardiovascular",
tema: "Síndrome Coronariana Aguda",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Diagnosticar IAM sem supra de ST, reconhecer risco e estratificar para angiografia",
dados_visiveis_ao_estudante: {
nome_paciente: "Marcos Antonio",
idade: 58,
sexo: "Masculino",
queixa_principal: "Dor no peito há 3 horas",
historia_breve: "Dor opressiva no peito com sudorese, melhorou um pouco em repouso mas persiste",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Infarto Agudo do Miocárdio sem Supra de ST",
diagnosticos_diferenciais: ["Angina Instável", "Pericardite Aguda", "Embolia Pulmonar"],
sindromes_associadas: ["Síndrome Coronariana Aguda"],
},
descricaoBreve: "Paciente com dor torácica típica, ECG sem supra, troponina elevada indicando necrose miocárdica",
categoria: "SCA",
paciente: {
id: "pac-018",
nome: "Marcos Antonio",
idade: 58,
sexo: "M",
queixaPrincipal: "Dor no peito há 3 horas",
historicoDoenca: "Dor começou durante esforço físico leve, alivia com repouso mas não desaparece",
antecedentes: ["HAS", "Dislipidemia", "Tabagismo ativo"],
profissao: "Motorista",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: ["Enalapril 10mg"],
},
respostas_do_paciente: {
inicial: "Tô com uma dor no peito que apareceu enquanto eu tava trabalhando",
dor: "É uma dor de aperto, no meio do peito, às vezes irradia pro braço",
intensidade: "7 em 10, diminuiu um pouco mas continua",
inicio: "Começou há umas 3 horas, tava dirigindo",
suor: "Sim, suei bastante no começo",
respiracao: "Um pouco de falta de ar, sim",
nausea: "Sim, sinto um pouco de enjôo",
alerta: "Tenho medo de estar infartando",
},
respostaPaciente: {
inicial: "Tô com uma dor no peito que apareceu enquanto eu tava trabalhando",
dor: "É uma dor de aperto, no meio do peito",
intensidade: "7 em 10",
inicio: "Começou há umas 3 horas",
suor: "Sim",
respiracao: "Um pouco de falta de ar",
nausea: "Sim",
alerta: "Tenho medo de estar infartando",
},
sinais_vitais: {
corretos: {
pressaoArterial: "155/92 mmHg",
frequenciaCardiaca: 95,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 96,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "155/92 mmHg",
frequenciaCardiaca: 95,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 96,
glicemia: 112,
},
exame_fisico: {
correto: {
inspecao: "Paciente ansioso, leve diaforese, aparente desconforto",
palpacao: "Leve sensibilidade precordial, sem alterações estruturais",
ausculta: "Taquicardia, ritmo regular, sem sopros audíveis",
percussao: "Normal",
observacoes: "Sinais de desconforto coronariano, necessário ECG urgente",
regiao: "Precórdio",
achados_positivos: ["Taquicardia", "Leve diaforese"],
achados_negativos: ["Sopros", "Arritmias"],
},
},
exameFisicoCorreto: {
inspecao: "Ansioso, leve diaforese",
palpacao: "Sensibilidade precordial leve",
ausculta: "Taquicardia regular, sem sopros",
percussao: "Normal",
observacoes: "Compatível com desconforto coronariano",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Paciente ansioso, em aparente desconforto, normocor",
consciencia: "Lúcido e orientado",
},
cardiovascular: {
inspecao_precordial: "Sem abaulamentos, sem cicatrizes visíveis",
ausculta_cardiaca: "Bulhas normofonéticas, FC 95 bpm, ritmo regular, sem sopros",
pulsos: "Presentes e simétricos bilateralmente",
turgencia_jugular: "Sem turgência jugular",
edema: "Sem edema em membros",
},
},
exames_complementares_disponiveis: [
{
nome: "ECG (Eletrocardiograma)",
descricao: "12 derivações",
resultado: "Infradesnivelamento de ST 2-3mm em D2, D3, aVF; inversão de onda T",
valor_referencia: "Segmento ST isoelétrico",
interpretacao: "Isquemia inferior, sem supra persistente",
},
{
nome: "Troponina I",
descricao: "Biomarcador cardíaco",
resultado: "1.2 ng/mL",
valor_referencia: "<0.04 ng/mL",
interpretacao: "Elevada - confirmação de necrose miocárdica",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Infarto Agudo do Miocárdio sem Supra de ST",
probabilidade: 90,
criterios_minimos: [
"Dor torácica típica",
"Troponina elevada",
"ECG com infradesnivelamento ou inversão de T",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Angina Instável",
criterios_exclusao: ["Troponina elevada"],
achados_que_descartam: ["Marcador cardíaco positivo"],
},
],
examesIndicados: [
"ECG seriado",
"Troponina seriada",
"Hemograma",
"Perfil lipídico",
"Creatinina",
"Ecocardiograma",
"Angiografia coronariana",
],
conduta_esperada: {
imediata: [
"Monitorização cardíaca contínua",
"Oxigenioterapia se SpO2 <90%",
"Acesso venoso",
"Aspirina 500mg",
"Clopidogrel ou ticagrelor conforme protocolo",
"Heparina",
"Analgesia se necessário",
],
curto_prazo: [
"Estratificação de risco",
"Angiografia coronariana diagnóstica",
"Possível intervenção coronariana percutânea",
"Internação em UCO",
],
longo_prazo: [
"Estatina",
"Betabloqueador",
"Reabilitação cardíaca",
"Modificação de fatores de risco",
],
encaminhamentos: ["Cardiologia", "Unidade Coronariana"],
},
condutaCorreta: "Monitorização, aspirina, clopidogrel, heparina, angiografia diagnóstica, manejo conforme risco",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: [
"Troponina elevada",
"Infradesnivelamento de ST",
"Taquicardia",
],
descricao: "Infarto estabelecido com risco de complicações",
recomendacao: "Internação em UCO, angiografia urgente",
},
],
erros_criticos: [
{
erro: "Não solicitar troponina",
descricao: "Marcador diferencia IAM de angina instável",
penalidade: 2,
evitavel: true,
},
{
erro: "Atrasar angiografia coronariana",
descricao: "Angiografia precoce melhora prognóstico",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Investigou características completas da dor",
realizado: false,
critico: true,
},
{
item: "Mediu sinais vitais",
realizado: false,
critico: true,
},
{
item: "Solicitou ECG",
realizado: false,
critico: true,
},
{
item: "Solicitou troponina",
realizado: false,
critico: true,
},
{
item: "Iniciou dupla antiagregação",
realizado: false,
critico: true,
},
{
item: "Encaminhou para angiografia",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de SCA",
peso: 25,
descricao: "Diferenciação de outras causas de dor torácica",
pontuacao_maxima: 25,
},
{
criterio: "Manejo antitrombótico",
peso: 20,
descricao: "Dupla antiagregação e anticoagulação apropriadas",
pontuacao_maxima: 20,
},
{
criterio: "Estratificação e encaminhamento",
peso: 20,
descricao: "Indicação apropriada de angiografia",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Características da dor (OLDCARTS)",
"Fatores de risco cardiovascular",
"Sintomas associados",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Sinais vitais",
"Exame cardiovascular",
"ECG com interpretação",
"Troponina",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"IAM sem supra de ST",
"Diagnósticos diferenciais",
"Estratificação de risco",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Dupla antiagregação",
"Anticoagulação",
"Angiografia coronariana",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu apresentação de SCA",
"Solicitou ECG e troponina",
"Iniciou dupla antiagregação",
"Encaminhou para angiografia coronariana",
"Estratificou risco apropriadamente",
],
erros_comuns: [
"Confundir com angina estável",
"Atrasar troponina",
"Não considerar angiografia urgente",
],
orientacoes_pedagogicas: [
"NSTEMI: troponina elevada + ECG sem supra = risco moderado a alto",
"Angiografia diagnóstica dentro de 24-72h melhora prognóstico",
"Dupla antiagregação é standard em SCA",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar NSTEMI pelos sinais clínicos, ECG e troponina; iniciar antitrombóticos apropriados; estratificar risco e encaminhar para angiografia",
comunicacao: [
"explicou a gravidade da situação",
"tranquilizou o paciente",
"explicou necessidade de internação",
],
anamnese: [
"investigou características da dor",
"pesquisou fatores de risco",
"investigou sintomas associados",
],
exame_fisico: [
"mediu sinais vitais corretamente",
"realizou ausculta cardíaca e respiratória",
"avaliou perfusão periférica",
],
exames_complementares: [
"solicitou ECG urgente",
"solicitou troponina seriada",
"considerou ecocardiograma",
],
raciocinio: [
"reconheceu apresentação compatível com NSTEMI",
"interpretou ECG corretamente",
"estratificou risco apropriadamente",
],
conduta: [
"iniciou dupla antiagregação",
"prescreveu anticoagulação",
"encaminhou para angiografia",
],
soap: [
"documentou características da dor",
"registrou achados de SCA",
"planejou manejo apropriado",
],
},
temaOSCE: "Síndrome Coronariana Aguda",
subtopicosOSCE: [
"IAM sem elevação de ST",
"Troponina elevada",
"ECG com infradesnivelamento de ST",
"Dupla antiagregação",
"Angiografia diagnóstica",
],
diagnosticoCorreto: "Infarto Agudo do Miocárdio sem Supra de ST",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("18"),
} as CasoOSCEV2;
