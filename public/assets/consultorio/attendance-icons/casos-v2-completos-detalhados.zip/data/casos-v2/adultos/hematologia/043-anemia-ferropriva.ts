import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso043AnemiaFerropriva: CasoOSCEV2 = {
// ====== CASO 43: ANEMIA FERROPRIVA ======
id: "43",
titulo: "Anemia Ferropriva",
sistema: "Hematologia",
tema: "Anemias",
nivel: "iniciante",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Diagnosticar anemia ferropriva e investigar causa de sangramento",
dados_visiveis_ao_estudante: {
nome_paciente: "Sandra Oliveira",
idade: 42,
sexo: "Feminino",
queixa_principal: "Cansaço progressivo e falta de ar",
historia_breve: "Mulher com menorragia crônica, anemia há meses",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Anemia Ferropriva",
diagnosticos_diferenciais: ["Anemia de doença crônica", "Deficiência de B12", "Anemia hemolítica"],
sindromes_associadas: ["Sangramento crônico"],
},
descricaoBreve: "Paciente com palidez, taquicardia, anemia microcítica hipocrômica com ferro baixo",
categoria: "Anemias",
paciente: {
id: "pac-043",
nome: "Sandra Oliveira",
idade: 42,
sexo: "F",
queixaPrincipal: "Cansaço e falta de ar",
historicoDoenca: "Menorragia há 2 anos",
antecedentes: ["Menorragia"],
profissao: "Vendedora",
estado_civil: "Casada",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Tô muito cansada, sem ar pra fazer as coisas",
cansaco: "Sim, muito cansaço, não tenho energia",
respiracao: "Falta de ar ao fazer esforço",
menstruacao: "Sim, muito intensa, dura muito tempo",
sangramento_outro: "Não, só a menstruação mesmo",
alimentacao: "Como bem pouco, não tenho vontade",
tontura: "Sim, fico tonta às vezes",
},
respostaPaciente: {
inicial: "Cansaço e falta de ar",
cansaco: "Sim",
respiracao: "Sim",
menstruacao: "Muito intensa",
sangramento_outro: "Não",
alimentacao: "Pouco apetite",
tontura: "Sim",
},
sinais_vitais: {
corretos: {
pressaoArterial: "110/70 mmHg",
frequenciaCardiaca: 105,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 97,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "110/70 mmHg",
frequenciaCardiaca: 105,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 97,
},
exame_fisico: {
correto: {
inspecao: "Paciente pálida, mucosas descoradas, unhas quebradiças",
palpacao: "Sem edema, pulsos amplos",
ausculta: "Sopro sistólico funcional",
percussao: "Normal",
observacoes: "Sinais de anemia crônica",
regiao: "Geral",
achados_positivos: ["Palidez", "Taquicardia", "Unhas quebradiças"],
achados_negativos: ["Esplenomegalia"],
},
},
exameFisicoCorreto: {
inspecao: "Pálida, mucosas descoradas",
palpacao: "Sem edema",
ausculta: "Sopro sistólico funcional",
percussao: "Normal",
observacoes: "Anemia crônica",
},
exame_fisico_interativo: {
geral: {
coloracao: "Pálida",
consciencia: "Alerta",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemograma",
descricao: "Série vermelha",
resultado: "Hb 8.5 g/dL, VCM 68 fL, HCM 22 pg",
valor_referencia: "Hb 12-16, VCM 80-100, HCM 27-33",
interpretacao: "Anemia microcítica hipocrômica",
},
{
nome: "Ferro sérico",
descricao: "Ferro disponível",
resultado: "22 mcg/dL",
valor_referencia: ">60 mcg/dL",
interpretacao: "Ferro baixo",
},
{
nome: "Ferritina",
descricao: "Reserva de ferro",
resultado: "12 ng/mL",
valor_referencia: ">24 ng/mL",
interpretacao: "Depleção de ferro",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Anemia Ferropriva",
probabilidade: 95,
criterios_minimos: [
"Anemia microcítica",
"Ferro baixo",
"Ferritina baixa",
"Menorragia",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Anemia de doença crônica",
criterios_exclusao: ["Ferro baixo, ferritina baixa"],
achados_que_descartam: ["Ferro sérico elevado"],
},
],
examesIndicados: [
"Hemograma completo",
"Ferro sérico, ferritina, TIBC",
"Se menorragia: ginecologia",
],
conduta_esperada: {
imediata: [
"Suplementação de ferro oral",
"Orientação dietética",
],
curto_prazo: [
"Investigar causa de sangramento",
"Ginecologia se menorragia",
],
longo_prazo: [
"Controle de menstruação",
],
encaminhamentos: ["Ginecologia"],
},
condutaCorreta: "Suplementação de ferro, investigação de sangramento, hemograma de controle em 4-6 semanas",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["Hb 8-10", "Taquicardia", "Dispneia"],
descricao: "Anemia moderada",
recomendacao: "Reposição de ferro e investigação",
},
],
erros_criticos: [
{
erro: "Não investigar causa de sangramento",
descricao: "Essencial para evitar recorrência",
penalidade: 1.5,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu anemia",
realizado: false,
critico: true,
},
{
item: "Solicitou hemograma",
realizado: false,
critico: true,
},
{
item: "Pesquisou ferro",
realizado: false,
critico: true,
},
{
item: "Investigou sangramento",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de anemia ferropriva",
peso: 25,
descricao: "Achados clínicos e laboratoriais",
pontuacao_maxima: 25,
},
{
criterio: "Investigação de causa",
peso: 20,
descricao: "Identificação de sangramento",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Cansaço",
"Menorragia",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Palidez",
"Anemia microcítica",
"Ferro baixo",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Anemia ferropriva"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Ferro oral",
"Investigação de sangramento",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu anemia ferropriva",
"Investigou sangramento",
"Prescreveu ferro",
],
erros_comuns: ["Só prescrever ferro sem investigar"],
orientacoes_pedagogicas: [
"Anemia ferropriva: investigar SEMPRE a causa",
"Menorragia é causa comum em mulheres",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar anemia e investigar sangramento",
comunicacao: ["explicou importância de reposição"],
anamnese: ["investigou menorragia"],
exame_fisico: ["detectou palidez"],
exames_complementares: ["pediu hemograma e ferro"],
raciocinio: ["diagnosticou ferropriva"],
conduta: ["prescreveu ferro"],
soap: ["documentou anemia"],
},
temaOSCE: "Anemias",
subtopicosOSCE: [
"Anemia ferropriva",
"Microcitose",
"Hipocromia",
"Menorragia",
"Investigação de sangramento",
],
diagnosticoCorreto: "Anemia Ferropriva",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("43"),
} as CasoOSCEV2;
