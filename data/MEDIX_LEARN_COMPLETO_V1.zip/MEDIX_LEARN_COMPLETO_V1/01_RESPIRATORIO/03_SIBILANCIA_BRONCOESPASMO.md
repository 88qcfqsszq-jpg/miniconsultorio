# Trilha Respiratório — Sibilância e Broncoespasmo

## Papel dentro do MEDIX Learn
Trilha para transformar “chiado” em raciocínio de obstrução das vias aéreas.

## Objetivo pedagógico
Ensinar por que o sibilo ocorre, como avaliar gravidade e como diferenciar asma, DPOC e outras causas.

## Competências ao final
- Explicar sibilo como fluxo turbulento por via aérea estreitada.
- Reconhecer expiração prolongada.
- Distinguir asma/DPOC/anafilaxia/corpo estranho conforme contexto.
- Reconhecer silêncio auscultatório como sinal grave.
- Relacionar broncodilatador à melhora de fluxo.

## Sequência didática padrão
1. **Microaula** — conceito central em linguagem simples.
2. **Fisiologia aplicada** — mecanismo que explica o sinal/sintoma.
3. **Semiologia** — como o mecanismo aparece no paciente.
4. **Raciocínio clínico** — como diferenciar causas próximas.
5. **Mini-casos** — aplicação curta, com pergunta e feedback.
6. **Questões ativas** — perguntas que obrigam o aluno a pensar.
7. **Erros comuns** — atalhos mentais perigosos.
8. **Mapa final** — síntese visual/textual.
9. **Ponte para OSCE** — para onde o aluno vai treinar depois.

## Blocos obrigatórios da trilha
- O que é sibilo.
- Broncoespasmo, edema, muco e estreitamento.
- Asma vs DPOC.
- Gravidade: fala, FR, SpO₂, esforço, consciência.
- Silêncio auscultatório.
- Conduta inicial em crise: oxigênio se hipoxemia, broncodilatadores, corticoide e reavaliação.

## Mini-casos sugeridos
- Asma leve: sibilos, fala preservada.
- Asma grave: fala entrecortada e SpO₂ baixa.
- DPOC exacerbado: sibilos + história tabágica + risco de CO₂.
- Anafilaxia: sibilância com urticária/hipotensão.

## Questões ativas-base
1. Todo sibilo é asma?
2. Por que silêncio auscultatório pode ser pior que sibilo intenso?
3. Como saber se a crise está respondendo?

## Erros comuns a corrigir
- Confundir roncos com sibilos.
- Não reconhecer gravidade.
- Dar alta sem reavaliar.
- Não perguntar internação/intubação prévia.

## Ponte para OSCE
OSCE Ciclo Básico: crise asmática. OSCE Clínico: resposta dinâmica a broncodilatador e oxigênio.
