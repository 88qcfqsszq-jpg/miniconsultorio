import { CasoOSCEV2 } from "@/types/caso-osce-v2";

export const caso003AsmaAguda: CasoOSCEV2 = {
// ====== CASO 3: ASMA AGUDA ======
id: "3",
titulo: "Asma Aguda",
sistema: "Respiratório",
tema: "Dispneia Aguda",
nivel: "iniciante",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico:
"Reconhecer crise asmática, avaliar gravidade e estabelecer tratamento broncodilatador",
dados_visiveis_ao_estudante: {
nome_paciente: "Roberto Costa",
idade: 28,
sexo: "Masculino",
queixa_principal: "Falta de ar e chiado no peito há 3 horas",
historia_breve:
"Asma desde a infância, controlada com inalador quando necessário"
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Asma Aguda (Crise Asmática Moderada)",
diagnosticos_diferenciais: [
"Anafilaxia",
"Embolia Pulmonar",
"Pneumotórax",
"Edema Pulmonar",
],
sindromes_associadas: ["Obstrução Reversível das Vias Aéreas"],
},
descricaoBreve:
"Paciente com dispneia súbita, chiado no peito e redução do pico de fluxo",
categoria: "Asma",
paciente: {
id: "pac-003",
nome: "Roberto Costa",
idade: 28,
sexo: "M",
queixaPrincipal: "Falta de ar e chiado no peito há 3 horas",
historicoDoenca:
"Asma desde a infância, controlada com inalador quando necessário",
antecedentes: ["Asma", "Alergias sazonais", "Alergias a ácaros e pó"],
profissao: "Designer",
estado_civil: "Solteiro",
alergias: ["Ácaros", "Pólen"],
medicamentos_em_uso: ["Salbutamol conforme necessário"],
},
respostas_do_paciente: {
inicial:
"Doutor/doutora, tô com muita dificuldade pra respirar, é como se tivesse algo apertando meu peito.",
falta_ar: "Muito! Não consigo pegar ar direito.",
chiado: "Sim! Tô fazendo aquele barulho chato ao respirar.",
tosse: "Sim, uma tosse seca mesmo.",
aperto: "Sim, aperto no peito, tipo uma banda apertando.",
inicio: "Começou de repente umas 3 horas atrás.",
gatilho: "Não fiz nada diferente hoje, acordei assim.",
inalador: "Tenho um inalador em casa mas uso pouquíssimo.",
alergias: "Sou muito alérgico, principalmente a pó e pólen.",
estresse: "Sim, tava estressado no trabalho.",
},
respostaPaciente: {
inicial:
"Doutor/doutora, tô com muita dificuldade pra respirar, é como se tivesse algo apertando meu peito.",
falta_ar: "Muito! Não consigo pegar ar direito.",
chiado: "Sim! Tô fazendo aquele barulho chato ao respirar.",
tosse: "Sim, uma tosse seca mesmo.",
aperto: "Sim, aperto no peito, tipo uma banda apertando.",
inicio: "Começou de repente umas 3 horas atrás.",
gatilho: "Não fiz nada diferente hoje, acordei assim.",
inalador: "Tenho um inalador em casa mas uso pouquíssimo.",
alergias: "Sou muito alérgico, principalmente a pó e pólen.",
estresse: "Sim, tava estressado no trabalho.",
},
sinais_vitais: {
corretos: {
pressaoArterial: "130/85 mmHg",
frequenciaCardiaca: 110,
frequenciaRespiratoria: 28,
temperatura: 36.9,
saturacaoOxigenio: 88,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "130/85 mmHg",
frequenciaCardiaca: 110,
frequenciaRespiratoria: 28,
temperatura: 36.9,
saturacaoOxigenio: 88,
glicemia: 140,
},
exame_fisico: {
correto: {
inspecao:
"Paciente em desconforto respiratório, taquipneia, uso de musculatura acessória",
palpacao: "Expansão torácica reduzida bilateralmente",
ausculta:
"Chiado difuso bilateral (wheezing), redução do murmúrio vesicular",
percussao: "Hiperinsuflação pulmonar",
observacoes:
"Crise asmática moderada com redução significativa do fluxo aéreo",
regiao: "Pulmões bilateralmente",
achados_positivos: [
"Wheezing difuso",
"Taquipneia",
"Redução do murmúrio",
],
achados_negativos: ["Crepitações", "Sibilos inspiratórios"],
},
},
exameFisicoCorreto: {
inspecao:
"Paciente em desconforto respiratório, taquipneia, uso de musculatura acessória",
palpacao: "Expansão torácica reduzida bilateralmente",
ausculta:
"Chiado difuso bilateral (wheezing), redução do murmúrio vesicular",
percussao: "Hiperinsuflação pulmonar",
observacoes:
"Crise asmática moderada com redução significativa do fluxo aéreo",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Paciente em desconforto respiratório, taquipneico, usando musculatura acessória.",
},
respiratorio: {
inspecao_torax: "Taquipneia (28 ipm), uso de musculatura acessória, retrações intercostais.",
expansibilidade: "Expansão torácica reduzida bilateralmente.",
ausculta_pulmonar: "Sibilos difusos bilaterais em expiração, murmúrio vesicular reduzido.",
musculatura_acessoria: "Presente, uso evidente de músculos acessórios.",
},
},
exames_complementares_disponiveis: [
{
nome: "Espirometria",
descricao: "Função pulmonar",
resultado: "FEV1 60% do previsto",
valor_referencia: ">80% do previsto",
interpretacao: "Obstrução moderada do fluxo aéreo",
},
{
nome: "Gasometria Arterial",
descricao: "pH, pCO2, pO2",
resultado: "pH 7.40, pCO2 35, pO2 65 com O2",
valor_referencia: "pH 7.35-7.45, pCO2 35-45, pO2 >80 com O2",
interpretacao: "Hipoxemia moderada",
},
{
nome: "Raio X de Tórax",
descricao: "PA e perfil",
resultado: "Hiperinsuflação pulmonar, sem pneumotórax",
valor_referencia: "Normal",
interpretacao: "Compatível com asma aguda",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Asma Aguda (Crise Asmática)",
probabilidade: 95,
criterios_minimos: [
"Dispneia aguda",
"Chiado bilateral",
"Redução do fluxo aéreo",
"Resposta ao broncodilatador",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Anafilaxia",
criterios_exclusao: ["Ausência de angioedema", "Sem urticária"],
achados_que_descartam: ["História alérgica clara", "Sem exposição alérgena recente"],
},
{
diagnostico: "Pneumotórax",
criterios_exclusao: ["RX normal"],
achados_que_descartam: ["Ausência de pneumotórax em RX"],
},
],
examesIndicados: [
"Espirometria",
"Gasometria arterial",
"Raio X de tórax para excluir pneumotórax",
],
conduta_esperada: {
imediata: [
"Salbutamol inalado (albuterol)",
"Corticosteroide sistêmico (prednisona ou metilprednisolona)",
"Oxigenioterapia para manter SpO2 >94%",
"Monitorização cardiopulmonar",
],
curto_prazo: [
"Broncodilatadores seriados a cada 15-20 minutos",
"Magnesium IV se crise grave",
],
longo_prazo: [
"Prescrever inalador de manutenção",
"Avaliação de gatilhos",
"Acompanhamento pneumológico",
],
encaminhamentos: ["Pneumologia se não responder ao tratamento"],
},
condutaCorreta:
"Salbutamol inalado, corticosteroide sistêmico, oxigenioterapia para manter SpO2 > 94%",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["SpO2 <90%", "FR >30", "Fala apenas palavras isoladas"],
descricao: "Crise asmática grave com risco de insuficiência respiratória",
recomendacao: "Internação, terapia agressiva, considernar intubação",
},
{
severidade: "moderada",
sinais: ["SpO2 90-94%", "FR 20-30", "Chiado difuso"],
descricao: "Crise asmática moderada",
recomendacao: "Broncodilatadores, corticosteroide, oxigenioterapia",
},
],
erros_criticos: [
{
erro: "Não usar corticosteroide sistêmico",
descricao:
"Corticosteroide é essencial em toda crise asmática, reduz recorrência",
penalidade: 2,
evitavel: true,
},
{
erro: "Não avaliar gravidade adequadamente",
descricao: "Asma grave pode progredir para insuficiência respiratória",
penalidade: 2.5,
evitavel: true,
},
],
checklist_osce: [
{ item: "Investigou histórico de asma", realizado: false, critico: true },
{ item: "Perguntou sobre gatilhos", realizado: false, critico: true },
{ item: "Mediu sinais vitais (inclusive SpO2)", realizado: false, critico: true },
{ item: "Realizou ausculta pulmonar completa", realizado: false, critico: true },
{ item: "Avaliou gravidade corretamente", realizado: false, critico: true },
{
item: "Prescreveu salbutamol + corticosteroide",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Avaliação de Gravidade",
peso: 25,
descricao: "Reconhecimento de sinais de gravidade",
pontuacao_maxima: 25,
},
{
criterio: "Terapia Broncodilatadora",
peso: 25,
descricao: "Salbutamol apropriadamente prescrito",
pontuacao_maxima: 25,
},
{
criterio: "Corticosteroide Sistêmico",
peso: 20,
descricao: "Prescrição apropriada",
pontuacao_maxima: 20,
},
{
criterio: "Oxigenioterapia",
peso: 15,
descricao: "Titulação para SpO2 >94%",
pontuacao_maxima: 15,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Duração da dispneia",
"Histórico de asma",
"Gatilhos identificáveis",
"Medicações asmáticas em uso",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"SpO2 e sinais vitais",
"Ausculta pulmonar",
"Uso de musculatura acessória",
"Espirometria se possível",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Crise asmática", "Avaliação de gravidade"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Broncodilatadores",
"Corticosteroide",
"Oxigenioterapia",
"Acompanhamento",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu chiado pulmonar",
"Mediu saturação de oxigênio",
"Prescreveu broncodilatador",
"Indicou corticosteroide sistêmico",
],
erros_comuns: [
"Não usar corticosteroide",
"Demora para oxigenioterapia",
"Subestimar gravidade",
],
orientacoes_pedagogicas: [
"Asma aguda: dispneia, chiado, aperto no peito, tosse",
"Ausculta: wheezing bilateral, redução do murmúrio",
"SEMPRE use corticosteroide sistêmico + SABA em crise asmática",
"Titule oxigenioterapia para SpO2 >94%",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer:
"Reconhecer crise asmática aguda: história de asma, dispneia, sibilos à ausculta, hipoxemia. Tratamento correto: oxigenioterapia, SABA + corticosteroide sistêmico. Não deixar sair da emergência sem estar melhor.",
comunicacao: [
"se apresentou rapidamente (paciente dispneico)",
"acalmou o paciente",
"explicou o que está fazendo",
"transmitiu confiança",
],
anamnese: [
"investigou história prévia de asma",
"perguntou sobre gatilhos",
"investigou início da crise",
"perguntou sobre medicações em casa",
],
exame_fisico: [
"solicitou sinais vitais imediatamente",
"mediu SpO2",
"ausculta bilateral procurando sibilos",
"avaliou uso de musculatura acessória",
],
exames_complementares: [
"solicitou SpO2/gasometria",
"considerou radiografia para descartar outros diagnósticos",
"considerou pico de fluxo se possível",
],
raciocinio: [
"reconheceu dispneia aguda com sibilos = asma",
"identificou gravidade pela SpO2 e dispneia",
"formulou diagnóstico apropriado",
],
conduta: [
"iniciou oxigenioterapia imediatamente",
"administrou SABA (salbutamol)",
"administrou corticosteroide sistêmico",
"monitorou resposta",
],
soap: [
"registrou história de asma e gatilho",
"documentou SpO2 baixa e sibilos",
"reconheceu crise asmática aguda",
"planejou tratamento emergencial",
],
},
temaOSCE: "Asma",
subtopicosOSCE: [
"Dispneia aguda",
"Sibilância bilateral",
"Espirometria com redução de FEV1",
"Broncodilatador (SABA)",
"Corticosteroide sistêmico"
],
diagnosticoCorreto: "Asma Aguda",

  exames_laboratoriais_detalhados: {
    hemograma: {
      solicitadoPor: ["hemograma completo"],
      disponivel: true,
      prioridade: "complementar",
      interpretacao: "Hemograma sem padrão bacteriano, com eosinofilia discreta.",
      valores: {
        hemoglobina: "13,9 g/dL",
        leucocitos: "8.600/mm³",
        neutrofilos: "55%",
        linfocitos: "29%",
        eosinofilos: "6%",
        plaquetas: "260.000/mm³",
      },
    },
    funcaoRenal: {
      solicitadoPor: ["ureia", "creatinina", "função renal"],
      disponivel: true,
      prioridade: "rotina",
      interpretacao: "Função renal preservada.",
      valores: {
        ureia: "32 mg/dL",
        creatinina: "0,9 mg/dL",
        etfg: "> 90 mL/min/1,73m²",
      },
    },
    eletrolitos: {
      solicitadoPor: ["sódio", "potássio", "eletrólitos", "ionograma"],
      disponivel: true,
      prioridade: "rotina",
      interpretacao: "Eletrólitos sem alterações relevantes.",
      valores: {
        sodio: "139 mEq/L",
        potassio: "4,2 mEq/L",
        cloro: "102 mEq/L",
        magnesio: "2,0 mg/dL",
        calcio: "9,2 mg/dL",
      },
    },
    marcadoresInflamatorios: {
      solicitadoPor: ["pcr", "vhs", "procalcitonina", "marcadores inflamatórios"],
      disponivel: true,
      prioridade: "opcional",
      interpretacao: "Marcadores inflamatórios sem elevação relevante.",
      valores: {
        pcr: "0,4 mg/dL",
        vhs: "12 mm/h",
        procalcitonina: "0,05 ng/mL",
      },
    },
    gasometria: {
      solicitadoPor: ["gasometria arterial"],
      disponivel: true,
      prioridade: "opcional",
      interpretacao: "Alcalose respiratória com hipoxemia leve, compatível com crise asmática.",
      valores: {
        ph: "7,47",
        paco2: "31 mmHg",
        pao2: "72 mmHg",
        hco3: "22 mEq/L",
        satO2: "94%",
        lactato: "1,3 mmol/L",
        be: "-1",
      },
    },
    marcadoresCardiacos: {
      solicitadoPor: ["troponina", "ckmb", "bnp", "marcadores cardíacos"],
      disponivel: true,
      prioridade: "opcional",
      interpretacao: "Marcadores cardíacos sem evidência de necrose miocárdica.",
      valores: {
        troponina: "<0,04 ng/mL",
        ckmb: "2,0 ng/mL",
        bnp: "48 pg/mL",
      },
    },
    funcaoHepatica: {
      solicitadoPor: ["tgo", "tgp", "bilirrubinas", "função hepática"],
      disponivel: true,
      prioridade: "opcional",
      interpretacao: "Função hepática sem alterações relevantes.",
      valores: {
        tgo: "24 U/L",
        tgp: "28 U/L",
        fa: "88 U/L",
        ggt: "34 U/L",
        bilirrubinaTotal: "0,8 mg/dL",
        bilirrubinaDireta: "0,2 mg/dL",
        bilirrubinaIndireta: "0,6 mg/dL",
        albumina: "4,1 g/dL",
      },
    },
    coagulograma: {
      solicitadoPor: ["tp", "inr", "ttpa", "fibrinogênio", "d-dímero", "coagulograma"],
      disponivel: true,
      prioridade: "opcional",
      interpretacao: "Coagulograma sem alterações relevantes.",
      valores: {
        tp: "12,4 s",
        inr: "1,0",
        ttpa: "31 s",
        fibrinogenio: "320 mg/dL",
        dDimero: "<500 ng/mL",
      },
    },
    urinaTipo1: {
      solicitadoPor: ["urina tipo 1", "eas", "sumário de urina"],
      disponivel: true,
      prioridade: "opcional",
      interpretacao: "Urina tipo 1 sem alterações relevantes.",
      valores: {
        densidade: "1,020",
        ph: "6,0",
        proteina: "Ausente",
        glicose: "Ausente",
        cetonas: "Ausentes",
        sangueHemoglobina: "Ausente",
        nitrito: "Negativo",
        esteraseLeucocitaria: "Negativa",
        leucocitos: "< 5 p/campo",
        hemacias: "< 3 p/campo",
        bacterias: "Raras",
        cilindros: "Ausentes",
      },
    },
  },
} as CasoOSCEV2;
