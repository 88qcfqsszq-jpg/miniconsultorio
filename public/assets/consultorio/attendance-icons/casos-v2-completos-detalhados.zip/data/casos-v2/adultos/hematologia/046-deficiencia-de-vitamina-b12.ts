import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso046DeficienciaDeVitaminaB12: CasoOSCEV2 = {
// ====== CASO 46: DÉFICIT DE B12 ======
id: "46",
titulo: "Deficiência de Vitamina B12",
sistema: "Hematologia",
tema: "Anemias",
nivel: "iniciante",
tipo_estacao: "integrada",
tempo_osce_minutos: 11,
objetivo_pedagogico: "Diagnosticar deficiência de B12 e investigar causa",
dados_visiveis_ao_estudante: {
nome_paciente: "Oswaldo Ferreira",
idade: 68,
sexo: "Masculino",
queixa_principal: "Formigamento nas mãos e pés, dificuldade em caminhar",
historia_breve: "Vegetariano há muitos anos, cansaço crônico",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Deficiência de Vitamina B12",
diagnosticos_diferenciais: ["Polineuropatia diabética", "Mielopatia", "Esclerose múltipla"],
sindromes_associadas: ["Anemia megaloblástica", "Neuropatia periférica"],
},
descricaoBreve: "Paciente com anemia macrocítica, neuropatia periférica, B12 baixo",
categoria: "Anemias",
paciente: {
id: "pac-046",
nome: "Oswaldo Ferreira",
idade: 68,
sexo: "M",
queixaPrincipal: "Formigamento e cansaço",
historicoDoenca: "Vegetariano há 30 anos",
antecedentes: ["Vegetarianismo", "Gastrectomia anterior"],
profissao: "Aposentado",
estado_civil: "Viúvo",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Meus pés e mãos formigam muito, tenho dificuldade em caminhar",
formigamento: "Sim, principalmente nos pés",
fraqueza: "Sim, perna fraca",
cansaco: "Muito cansaço",
alimentacao: "Sou vegetariano desde jovem",
memoria: "Um pouco esquecido",
equilibrio: "Perdi um pouco do equilíbrio",
},
respostaPaciente: {
inicial: "Formigamento e dificuldade em caminhar",
formigamento: "Sim, pés",
fraqueza: "Sim",
cansaco: "Muito",
alimentacao: "Vegetariano há anos",
memoria: "Esquecido",
equilibrio: "Ruim",
},
sinais_vitais: {
corretos: {
pressaoArterial: "130/80 mmHg",
frequenciaCardiaca: 80,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 97,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "130/80 mmHg",
frequenciaCardiaca: 80,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 97,
},
exame_fisico: {
correto: {
inspecao: "Palidez, língua lisa",
palpacao: "Redução de sensibilidade vibratória e proprioceptiva",
ausculta: "Normal",
percussao: "Reflexos tendinosos ausentes em MMII",
observacoes: "Neuropatia periférica com sinais medulares",
regiao: "Geral e neurologia",
achados_positivos: ["Glossite", "Neuropatia", "Ausência de reflexos"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Palidez, língua lisa",
palpacao: "Sensibilidade reduzida",
ausculta: "Normal",
percussao: "Reflexos ausentes",
observacoes: "Neuropatia",
},
exame_fisico_interativo: {
geral: {
coloracao: "Pálido",
consciencia: "Alerta mas com déficit cognitivo leve",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemograma",
descricao: "Série vermelha",
resultado: "Hb 9, VCM 105, Reticulócitos 0.8%",
valor_referencia: "VCM 80-100",
interpretacao: "Anemia macrocítica",
},
{
nome: "Vitamina B12",
descricao: "Cobalamina sérica",
resultado: "180 pg/mL",
valor_referencia: ">200 pg/mL",
interpretacao: "Deficiência de B12",
},
{
nome: "Ácido fólico",
descricao: "Folato sérico",
resultado: "6 ng/mL",
valor_referencia: ">5.4 ng/mL",
interpretacao: "Normal",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Deficiência de Vitamina B12",
probabilidade: 95,
criterios_minimos: [
"Anemia macrocítica",
"Neuropatia periférica",
"B12 baixo",
"Dieta vegetariana",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Déficit de ácido fólico",
criterios_exclusao: ["Ácido fólico normal"],
achados_que_descartam: ["Folato normal"],
},
],
examesIndicados: [
"Hemograma com reticulócitos",
"Vitamina B12 e folato",
"Teste de Schilling se disponível",
],
conduta_esperada: {
imediata: [
"Vitamina B12 intramuscular",
"Aconselhamento dietético",
],
curto_prazo: [
"Reposição mensal de B12",
"Avaliação neurológica",
],
longo_prazo: [
"Monitorização contínua",
],
encaminhamentos: ["Hematologia"],
},
condutaCorreta: "Hemograma, B12 e folato, B12 intramuscular, seguimento mensal",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["Neuropatia", "Anemia", "Déficit cognitivo"],
descricao: "B12 com manifestações neurológicas",
recomendacao: "Reposição imediata para evitar piora",
},
],
erros_criticos: [
{
erro: "Não investigar causa",
descricao: "Vegetarianismo vs. má absorção",
penalidade: 1,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu déficit de B12",
realizado: false,
critico: true,
},
{
item: "Solicitou B12 e folato",
realizado: false,
critico: true,
},
{
item: "Investigou causa",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de B12",
peso: 25,
descricao: "Anemia macrocítica com neuropatia",
pontuacao_maxima: 25,
},
{
criterio: "Investigação de causa",
peso: 20,
descricao: "Dietética vs. má absorção",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Formigamento",
"Vegetarianismo",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Palidez",
"Neuropatia",
"Anemia macrocítica",
"B12 baixo",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Deficiência de B12"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"B12 intramuscular",
"Aconselhamento dietético",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu B12",
"Solicitou B12 e folato",
"Investigou causa",
],
erros_comuns: ["Confundir com déficit de ácido fólico"],
orientacoes_pedagogicas: [
"B12: neuropatia + palidez + macrocitose",
"Folato: apenas anemia macrocítica",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar B12 e investigar causa",
comunicacao: ["explicou importância de suplementação"],
anamnese: ["investigou vegetarianismo"],
exame_fisico: ["detectou neuropatia"],
exames_complementares: ["pediu B12 e folato"],
raciocinio: ["diagnosticou B12"],
conduta: ["prescreveu B12 IM"],
soap: ["documentou B12"],
},
temaOSCE: "Anemias",
subtopicosOSCE: [
"Deficiência de B12",
"Macrocitose",
"Neuropatia periférica",
"Glossite",
"Vegetarianismo",
],
diagnosticoCorreto: "Deficiência de Vitamina B12",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("46"),
} as CasoOSCEV2;
