# MEDIX Learn — Neurologia

## Objetivo
Ensinar raciocínio neurológico inicial: localizar, reconhecer urgência e fazer exame essencial.

## Trilhas
1. Cefaleia e sinais de alarme
2. Rebaixamento do nível de consciência
3. Déficit neurológico focal e AVC
4. Convulsão
5. Tontura e vertigem
6. Exame neurológico essencial
7. Síndromes meníngeas
