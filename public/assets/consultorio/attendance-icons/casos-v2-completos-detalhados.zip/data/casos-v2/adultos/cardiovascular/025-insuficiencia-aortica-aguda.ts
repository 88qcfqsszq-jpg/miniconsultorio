import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso025InsuficienciaAorticaAguda: CasoOSCEV2 = {
// ====== CASO 25: INSUFICIÊNCIA AÓRTICA AGUDA ======
id: "25",
titulo: "Insuficiência Aórtica Aguda",
sistema: "Cardiovascular",
tema: "Valvopatia",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 11,
objetivo_pedagogico: "Diagnosticar insuficiência aórtica aguda e reconhecer emergência médica",
dados_visiveis_ao_estudante: {
nome_paciente: "Pedro Alves",
idade: 45,
sexo: "Masculino",
queixa_principal: "Falta de ar súbita e palpitações",
historia_breve: "Começou há poucas horas, febre alguns dias atrás, paciente com uso de drogas IV",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Insuficiência Aórtica Aguda com Endocardite",
diagnosticos_diferenciais: ["Dissecção aórtica", "Pericardite"],
sindromes_associadas: ["Endocardite infecciosa"],
},
descricaoBreve: "Paciente com sopro diastólico decrescente, pulso amplo, insuficiência cardíaca aguda",
categoria: "Valvopatia",
paciente: {
id: "pac-025",
nome: "Pedro Alves",
idade: 45,
sexo: "M",
queixaPrincipal: "Falta de ar súbita",
historicoDoenca: "Febre recente, uso de drogas IV",
antecedentes: ["Uso de drogas ilícitas IV", "Hepatite C"],
profissao: "Mecânico",
estado_civil: "Solteiro",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "De repente fiquei com falta de ar muito ruim",
dispneia: "Muita, até em repouso",
palpitacoes: "Sim, coração acelerado",
febre: "Tive febre alguns dias atrás",
dor_peito: "Sim, dor que irradia para as costas",
uso_drogas: "Sim, uso drogas IV esporadicamente",
},
respostaPaciente: {
inicial: "Falta de ar de repente",
dispneia: "Muita",
palpitacoes: "Sim",
febre: "Sim",
dor_peito: "Sim",
uso_drogas: "Sim",
},
sinais_vitais: {
corretos: {
pressaoArterial: "170/40 mmHg",
frequenciaCardiaca: 115,
frequenciaRespiratoria: 28,
temperatura: 38.5,
saturacaoOxigenio: 90,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "170/40 mmHg",
frequenciaCardiaca: 115,
frequenciaRespiratoria: 28,
temperatura: 38.5,
saturacaoOxigenio: 90,
},
exame_fisico: {
correto: {
inspecao: "Pulsos amplos, cabeçada (sinal de Musset)",
palpacao: "Pulso bounding",
ausculta: "Sopro diastólico decrescente em borda esternal esquerda, possível sopro sistólico (Austin Flint) em ápice",
percussao: "Normal",
observacoes: "Sinais de IA aguda com IC",
regiao: "Precórdio",
achados_positivos: ["Sopro diastólico"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Pulsos amplos",
palpacao: "Pulso bounding",
ausculta: "Sopro diastólico em aórtica",
percussao: "Normal",
observacoes: "Sinais de IA",
},
exame_fisico_interativo: {
cardiovascular: {
inspecao_precordial: "Pulsos visíveis amplos",
ausculta_cardiaca: "Sopro diastólico decrescente em borda esternal esquerda, sopro sistólico em ápice",
pulsos: "Pulso amplo e bounding",
turgencia_jugular: "Elevada",
edema: "Possível em MMII",
},
},
exames_complementares_disponiveis: [
{
nome: "Ecocardiograma",
descricao: "Avaliação urgente",
resultado: "Folheto aórtico danificado, regurgitação aórtica massiva",
valor_referencia: "Folheto aórtico íntegro",
interpretacao: "IA aguda severa",
},
{
nome: "Hemocultura",
descricao: "Isolamento de bactéria",
resultado: "Positiva para Staphylococcus aureus",
valor_referencia: "Negativa",
interpretacao: "Endocardite",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Insuficiência Aórtica Aguda",
probabilidade: 90,
criterios_minimos: [
"Sopro diastólico decrescente",
"Pulso amplo",
"IA massiva ao ecocardiograma",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Dissecção aórtica",
criterios_exclusao: ["Ecocardiograma com vegetação"],
achados_que_descartam: ["Hemocultura positiva"],
},
],
examesIndicados: [
"Ecocardiograma urgente",
"Hemocultura",
"Hemograma",
"Creatinina",
"Ecocardiograma transesofágico",
],
conduta_esperada: {
imediata: [
"Encaminhar para cirurgia urgente",
"Nitroprussiato para controle de PA",
"Oxigenioterapia",
],
curto_prazo: [
"Substituição de válvula aórtica",
"Antibioticoterapia para endocardite",
],
longo_prazo: ["Seguimento infeccioso e cardíaco"],
encaminhamentos: ["Cirurgia cardíaca urgente", "Infectologia"],
},
condutaCorreta: "Emergência cirúrgica, nitroprussiato, ecocardiograma urgente, hemocultura, substituição valvular",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["Dispneia aguda", "SpO2 baixa", "Insuficiência cardíaca"],
descricao: "Emergência com risco de morte",
recomendacao: "Cirurgia urgentíssima",
},
],
erros_criticos: [
{
erro: "Não reconhecer como emergência",
descricao: "IA aguda pode causar morte rapidamente",
penalidade: 3,
evitavel: true,
},
{
erro: "Não encaminhar para cirurgia urgente",
descricao: "Única esperança de sobrevida",
penalidade: 3,
evitavel: true,
},
],
checklist_osce: [
{
item: "Detectou sopro diastólico em aórtica",
realizado: false,
critico: true,
},
{
item: "Reconheceu pulso amplo",
realizado: false,
critico: true,
},
{
item: "Solicitou ecocardiograma urgente",
realizado: false,
critico: true,
},
{
item: "Encaminhou para cirurgia emergencial",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de emergência",
peso: 35,
descricao: "IA aguda é vida em risco",
pontuacao_maxima: 35,
},
{
criterio: "Manejo apropriado",
peso: 25,
descricao: "Cirurgia e antibioticoterapia",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dispneia aguda",
"Febre",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Sopro diastólico",
"Pulso amplo",
"IA massiva ao ecocardiograma",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Insuficiência aórtica aguda"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Cirurgia urgente",
"Nitroprussiato",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu IA aguda",
"Encaminhou para cirurgia urgente",
"Solicitou ecocardiograma urgente",
],
erros_comuns: ["Achar que é apenas insuficiência cardíaca"],
orientacoes_pedagogicas: [
"IA aguda com febre = suspeitar endocardite",
"Pulso amplo > 50% diferença pressão sistólica-diastólica",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer IA aguda como emergência e encaminhar para cirurgia",
comunicacao: ["explicou gravidade"],
anamnese: ["investigou febre e uso de drogas"],
exame_fisico: ["detectou sinais de IA"],
exames_complementares: ["pediu ecocardiograma urgente"],
raciocinio: ["diagnosticou IA aguda"],
conduta: ["encaminhou cirurgia urgente"],
soap: ["documentou IA aguda"],
},
temaOSCE: "Valvopatias",
subtopicosOSCE: [
"Insuficiência aórtica aguda",
"Sopro diastólico",
"Pulso amplo",
"Emergência cirúrgica",
],
diagnosticoCorreto: "Insuficiência Aórtica Aguda",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("25"),
} as CasoOSCEV2;
