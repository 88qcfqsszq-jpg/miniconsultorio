# Referências e critérios de curadoria

Este pacote é material educacional para estudantes de medicina. Não substitui diretrizes locais, supervisão docente ou atendimento médico real.

## Critérios usados

- Ensinar por mecanismo, não por memorização.
- Começar por gravidade e segurança.
- Conectar fisiologia com semiologia.
- Usar mini-casos para transferência.
- Encerrar com ponte para OSCE.

## Fontes gerais de referência para curadoria posterior

- Fisiologia médica clássica: Guyton & Hall; Boron & Boulpaep.
- Semiologia médica: Bates; Porto.
- Medicina interna: Harrison; Cecil.
- Urgências: ATLS/ACLS/PALS conforme escopo e supervisão.
- Manuais profissionais revisados: MSD/Merck Manual Professional.
- Revisões sobre hipoxemia e V/Q: literatura revisada por pares.

## Nota

Antes de transformar qualquer trilha em produto final, realizar curadoria médica/docente específica.
