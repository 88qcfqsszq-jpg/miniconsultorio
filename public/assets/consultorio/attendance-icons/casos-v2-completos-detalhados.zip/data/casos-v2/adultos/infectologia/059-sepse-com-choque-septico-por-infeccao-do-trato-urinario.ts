import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso059SepseComChoqueSepticoPor: CasoOSCEV2 = {
// ====== CASO 59: SEPSE COM CHOQUE SÉPTICO ======
id: "59",
titulo: "Sepse com Choque Séptico por Infecção do Trato Urinário",
sistema: "Infectologia",
tema: "Casos Integradores",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 13,
objetivo_pedagogico: "Reconhecer sepse/choque séptico e instituir manejo apropriado",
dados_visiveis_ao_estudante: {
nome_paciente: "Beatriz Gomez",
idade: 78,
sexo: "Feminino",
queixa_principal: "Confusão mental, febre, pressão baixa",
historia_breve: "Idosa com ITU evoluindo para sepse",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Sepse com Choque Séptico por Pielonefrite",
diagnosticos_diferenciais: ["Choque cardiogênico", "Choque hemorrágico", "AVC"],
sindromes_associadas: ["Insuficiência de múltiplos órgãos"],
},
descricaoBreve: "Paciente com febre, hipotensão, taquicardia, lactato elevado, alteração mental",
categoria: "Casos Integradores",
paciente: {
id: "pac-059",
nome: "Beatriz Gomez",
idade: 78,
sexo: "F",
queixaPrincipal: "Confusão e choque",
historicoDoenca: "Sintomas há 2 dias",
antecedentes: ["Sonda vesical"],
profissao: "Aposentada",
estado_civil: "Viúva",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Não consigo ficar orientada, tenho muito frio",
confusao: "Confusa, não sei o dia",
febre: "Febre muito alta",
frio: "Calafrios",
respiracao: "Respiração rápida",
pressao: "Fraqueza, tontura",
urina: "Urina com cheiro estranho e cor escura",
},
respostaPaciente: {
inicial: "Confusão e febre",
confusao: "Sim, desorientada",
febre: "Muito alta",
frio: "Sim",
respiracao: "Rápida",
pressao: "Muito baixa",
urina: "Escura e com cheiro",
},
sinais_vitais: {
corretos: {
pressaoArterial: "85/52 mmHg",
frequenciaCardiaca: 128,
frequenciaRespiratoria: 26,
temperatura: 40.2,
saturacaoOxigenio: 94,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "85/52 mmHg",
frequenciaCardiaca: 128,
frequenciaRespiratoria: 26,
temperatura: 40.2,
saturacaoOxigenio: 94,
},
exame_fisico: {
correto: {
inspecao: "Paciente confusa, extremidades frias, cianose, pele manchada",
palpacao: "Pulsos filiformes, tempo de enchimento capilar >2s",
ausculta: "Taquicardia, taquipneia",
percussao: "Normal",
observacoes: "Sinais de choque séptico",
regiao: "Geral",
achados_positivos: ["Confusão", "Extremidades frias", "Pulsos finos"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Confusa, extremidades frias",
palpacao: "Pulsos filiformes",
ausculta: "Taquicardia",
percussao: "Normal",
observacoes: "Choque",
},
exame_fisico_interativo: {
geral: {
coloracao: "Manchado, cianótico",
consciencia: "Confuso, desorientado",
},
},
exames_complementares_disponiveis: [
{
nome: "Lactato",
descricao: "Marcador de hipoperfusão",
resultado: "4.2 mmol/L",
valor_referencia: "<2 mmol/L",
interpretacao: "Hipoperfusão tissular",
},
{
nome: "Hemograma",
descricao: "Leucócitos",
resultado: "18.500/mm³",
valor_referencia: "<11.000",
interpretacao: "Leucocitose",
},
{
nome: "Urinálise",
descricao: "Análise de urina",
resultado: "Bacteriúria massiva, piúria",
valor_referencia: "Negativa",
interpretacao: "ITU",
},
{
nome: "Hemoculturas",
descricao: "Culturas de sangue",
resultado: "Grampositivo em pendência",
valor_referencia: "Negativa",
interpretacao: "Bacteremia",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Sepse com Choque Séptico",
probabilidade: 98,
criterios_minimos: [
"Febre/hipotermia",
"Hipotensão",
"Alteração mental",
"Lactato elevado",
"Foco infeccioso (ITU)",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "AVC",
criterios_exclusao: ["Febre alta", "Choque"],
achados_que_descartam: ["Lactato elevado"],
},
],
examesIndicados: [
"Lactato, hemoculturas",
"Hemograma, bioquímica",
"Urinálise e urocultura",
"PCR, procalcitonina",
"SOFA score",
],
conduta_esperada: {
imediata: [
"CTI/Emergência",
"Fluidos IV agressivos",
"Vasopressores se necessário",
"Antibióticos de amplo espectro",
],
curto_prazo: [
"Drenagem de foco (sonda vesical)",
"Monitorização contínua",
],
longo_prazo: [
"Suporte de órgão",
],
encaminhamentos: ["CTI", "Infectologia"],
},
condutaCorreta: "CTI urgente, fluidos IV rápido, vasopressores, antibióticos amplos, drenagem de foco",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["Hipotensão", "Alteração mental", "Lactato >4"],
descricao: "Choque séptico com risco de morte",
recomendacao: "CTI com suporte máximo",
},
],
erros_criticos: [
{
erro: "Atrasar fluidos ou antibióticos",
descricao: "Cada hora aumenta mortalidade",
penalidade: 3,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu sepse",
realizado: false,
critico: true,
},
{
item: "Solicitou lactato",
realizado: false,
critico: true,
},
{
item: "Encaminhou CTI",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de sepse/choque",
peso: 35,
descricao: "SIRS + hipotensão",
pontuacao_maxima: 35,
},
{
criterio: "Urgência do manejo",
peso: 30,
descricao: "CTI e antibióticos precoces",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Febre",
"Confusão",
"ITU",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Hipotensão",
"Taquicardia",
"Lactato elevado",
"Bacteriúria",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Choque séptico por ITU",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"CTI",
"Fluidos IV",
"Antibióticos",
"Vasopressores",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu sepse",
"Solicitou lactato",
"Encaminhou CTI",
"Ordenou antibióticos",
],
erros_comuns: ["Achar que é AVC"],
orientacoes_pedagogicas: [
"Sepse: febre + hipotensão + alteração mental",
"Lactato é marcador de hipoperfusão",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer choque e agir rápido",
comunicacao: ["explicou urgência crítica"],
anamnese: ["investigou foco infeccioso"],
exame_fisico: ["detectou sinais de choque"],
exames_complementares: ["pediu lactato"],
raciocinio: ["diagnosticou choque séptico"],
conduta: ["iniciou fluidos e antibióticos"],
soap: ["documentou urgência"],
},
temaOSCE: "Casos Integradores",
subtopicosOSCE: [
"Sepse",
"Choque séptico",
"Lactato elevado",
"SIRS",
"Emergência máxima",
],
diagnosticoCorreto: "Sepse com Choque Séptico",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("59"),
} as CasoOSCEV2;
