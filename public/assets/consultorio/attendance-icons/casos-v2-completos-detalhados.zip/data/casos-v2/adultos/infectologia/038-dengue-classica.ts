import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso038DengueClassica: CasoOSCEV2 = {
// ====== CASO 38: DENGUE CLÁSSICA ======
id: "38",
titulo: "Dengue Clássica",
sistema: "Infectologia",
tema: "Arboviroses",
nivel: "iniciante",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Diagnosticar dengue clássica e orientar manejo de suporte",
dados_visiveis_ao_estudante: {
nome_paciente: "Ana Paula Santos",
idade: 32,
sexo: "Feminino",
queixa_principal: "Febre, dor de cabeça e mal-estar",
historia_breve: "Febre alta há 3 dias, dor retro-orbitária, vive em área com dengue",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Dengue Clássica",
diagnosticos_diferenciais: ["Influenza", "Chikungunya", "Zika", "Malária"],
sindromes_associadas: ["Síndrome Febril Viral"],
},
descricaoBreve: "Paciente febril em fase aguda com exantema, cefaleia e mialgia sem sinais de alarme",
categoria: "Arboviroses",
paciente: {
id: "pac-038",
nome: "Ana Paula Santos",
idade: 32,
sexo: "F",
queixaPrincipal: "Febre e dor de cabeça",
historicoDoenca: "Febre há 3 dias",
antecedentes: ["Vive em área endêmica de dengue"],
profissao: "Professora",
estado_civil: "Casada",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Estou com febre muito alta, dor de cabeça intensa",
febre: "Sim, aparece de repente, muito alta",
cefaleia: "Sim, dor de cabeça muito forte",
retroorbitaria: "Dói muito atrás dos olhos",
mialgia: "Sim, dor em todo o corpo, especialmente nas costas",
artralgia: "Sinto dor nas juntas também",
exantema: "Apareceu umas manchinhas vermelhas ontem",
nausea: "Tenho náusea e perdi a vontade de comer",
vomito: "Não vomitei",
},
respostaPaciente: {
inicial: "Febre e dor de cabeça",
febre: "Sim, alta",
cefaleia: "Sim, intensa",
retroorbitaria: "Sim",
mialgia: "Sim",
artralgia: "Sim",
exantema: "Sim, manchinhas",
nausea: "Sim",
vomito: "Não",
},
sinais_vitais: {
corretos: {
pressaoArterial: "120/75 mmHg",
frequenciaCardiaca: 90,
frequenciaRespiratoria: 16,
temperatura: 39.5,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "120/75 mmHg",
frequenciaCardiaca: 90,
frequenciaRespiratoria: 16,
temperatura: 39.5,
saturacaoOxigenio: 98,
},
exame_fisico: {
correto: {
inspecao: "Paciente febril, face avermelhada, exantema maculopapular em tronco",
palpacao: "Abdome mole, fígado palpável a 2cm",
ausculta: "MV+, ausência de sopros",
percussao: "Normal",
observacoes: "Hepatomegalia discreta sem sinais de alarme",
regiao: "Geral",
achados_positivos: ["Febre", "Exantema", "Hepatomegalia"],
achados_negativos: ["Sangramento", "Edema"],
},
},
exameFisicoCorreto: {
inspecao: "Febril, exantema maculopapular",
palpacao: "Hepatomegalia 2cm",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Fase febril clássica",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Paciente mal-estar, febril com exantema",
coloracao: "Avermelhada com exantema",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemograma",
descricao: "Contagem de células",
resultado: "Hb 13, Ht 38%, Leucócitos 5.200, Plaquetas 150.000",
valor_referencia: "Hb 12-16, Plaquetas >150.000",
interpretacao: "Sem hemoconcentração",
},
{
nome: "Sorologia Dengue IgM",
descricao: "Anticorpo IgM anti-dengue",
resultado: "Positivo",
valor_referencia: "Negativo",
interpretacao: "Infecção recente por dengue",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Dengue Clássica",
probabilidade: 90,
criterios_minimos: [
"Febre",
"Cefaleia retro-orbitária",
"Mialgia",
"Exantema",
"Sorologia IgM positiva",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Chikungunya",
criterios_exclusao: ["Sorologia dengue IgM positiva"],
achados_que_descartam: ["IgM dengue positivo"],
},
],
examesIndicados: [
"Hemograma",
"Sorologia dengue (IgM/IgG)",
"Testes rápidos de antígeno NS1",
],
conduta_esperada: {
imediata: [
"Repouso",
"Hidratação oral",
"Dipirona ou paracetamol",
],
curto_prazo: [
"Monitorização de sintomas",
"Retorno se surgir sangramento",
],
longo_prazo: [
"Educação sobre dengue",
],
encaminhamentos: ["Avaliação de risco"],
},
condutaCorreta: "Suporte clínico, hidratação, analgesia, vigilância para sinais de alarme",
criterios_de_gravidade: [
{
severidade: "leve",
sinais: ["Febre", "Exantema", "Sem sangramento"],
descricao: "Dengue clássica sem complicações",
recomendacao: "Manejo ambulatorial com vigilância",
},
],
erros_criticos: [
{
erro: "Prescrever AAS",
descricao: "AAS aumenta risco de sangramento em dengue",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu dengue",
realizado: false,
critico: true,
},
{
item: "Solicitou sorologia dengue",
realizado: false,
critico: true,
},
{
item: "Orientou hidratação",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de dengue",
peso: 25,
descricao: "Sintomatologia clássica",
pontuacao_maxima: 25,
},
{
criterio: "Conduta apropriada",
peso: 20,
descricao: "Suporte e vigilância",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Febre alta",
"Cefaleia retro-orbitária",
"Mialgia",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Febre",
"Exantema",
"Hepatomegalia",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Dengue clássica"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Sorologia dengue",
"Hidratação",
"Vigilância",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu dengue",
"Solicitou sorologia",
"Prescreveu suporte clínico",
],
erros_comuns: ["Prescrever AAS"],
orientacoes_pedagogicas: [
"Dengue: febre + cefaleia retro-orbitária + mialgia + exantema",
"Nunca use AAS em dengue",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar dengue e orientar manejo seguro",
comunicacao: ["explicou importância de vigilância"],
anamnese: ["investigou sintomas clássicos"],
exame_fisico: ["avaliou hepatomegalia"],
exames_complementares: ["pediu sorologia"],
raciocinio: ["diagnosticou dengue"],
conduta: ["prescreveu suporte"],
soap: ["documentou dengue"],
},
temaOSCE: "Arboviroses",
subtopicosOSCE: [
"Dengue",
"Febre",
"Cefaleia retro-orbitária",
"Mialgia",
"Arboviroses",
],
diagnosticoCorreto: "Dengue Clássica",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("38"),
} as CasoOSCEV2;
