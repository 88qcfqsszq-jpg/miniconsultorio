# Casos OSCE v2 — banco organizado

Este pacote foi gerado a partir do banco atual `casos-osce.ts`, reorganizado por sistema em arquivos individuais.

## Conteúdo

- `61` casos completos, sem placeholders.
- Cada arquivo contém o objeto de caso original completo.
- Cada caso recebeu `fonte_exames_laboratoriais` via `buildFonteExamesLaboratoriais(id)`.
- O arquivo `data/casos-v2/shared/laboratorios.ts` centraliza exames laboratoriais normais e alterações por ID.
- O arquivo `types/caso-osce-v2.ts` adiciona os tipos necessários.
- O arquivo `data/casos-v2/index.ts` exporta `casosV2`.

## Observação

A estrutura preserva os dados clínicos existentes do app e acrescenta fonte laboratorial estruturada.
