import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso053TalassemiaMaior: CasoOSCEV2 = {
// ====== CASO 53: TALASSEMIA MAIOR ======
id: "53",
titulo: "Talassemia Maior",
sistema: "Hematologia",
tema: "Anemias hereditárias",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 11,
objetivo_pedagogico: "Diagnosticar talassemia maior por achados clínicos e laboratoriais",
dados_visiveis_ao_estudante: {
nome_paciente: "Antonio Rossi",
idade: 12,
sexo: "Masculino",
queixa_principal: "Cansaço, palidez, deformidades faciais",
historia_breve: "Criança mediterrânea com anemia crônica desde pequeno",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Talassemia Maior",
diagnosticos_diferenciais: ["Anemia ferropriva", "Talassemia menor", "Esferocitose hereditária"],
sindromes_associadas: ["Hemólise crônica", "Sobrecarga de ferro"],
},
descricaoBreve: "Criança com anemia macrocítica, hepatomegalia, esplenomegalia, alterações faciais",
categoria: "Anemias hereditárias",
paciente: {
id: "pac-053",
nome: "Antonio Rossi",
idade: 12,
sexo: "M",
queixaPrincipal: "Cansaço e palidez",
historicoDoenca: "Anemia desde pequeno",
antecedentes: ["Origem mediterrânea", "Transfusões regulares"],
profissao: "Estudante",
estado_civil: "Solteiro",
alergias: [],
medicamentos_em_uso: ["Transfusões"],
},
respostas_do_paciente: {
inicial: "Sou muito cansado, pálido desde pequeno",
cansaco: "Muito, não aguento esforço",
facies: "Tenho a cara diferente, abaulada",
respiracao: "Fico sem ar fácil",
transfusoes: "Tomo transfusão cada 4-6 semanas",
barriga: "Barriga inchada por causa do baço",
crescimento: "Sou pequeno para minha idade",
},
respostaPaciente: {
inicial: "Cansaço e alterações faciais",
cansaco: "Muito",
facies: "Deformidade facial",
respiracao: "Sim",
transfusoes: "Regulares",
barriga: "Esplenomegalia",
crescimento: "Retardo",
},
sinais_vitais: {
corretos: {
pressaoArterial: "110/70 mmHg",
frequenciaCardiaca: 95,
frequenciaRespiratoria: 20,
temperatura: 36.8,
saturacaoOxigenio: 96,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "110/70 mmHg",
frequenciaCardiaca: 95,
frequenciaRespiratoria: 20,
temperatura: 36.8,
saturacaoOxigenio: 96,
},
exame_fisico: {
correto: {
inspecao: "Criança pálida, alterações faciais (frontal e malar proeminentes), deformidade do palato",
palpacao: "Hepatomegalia 4cm, esplenomegalia 6cm",
ausculta: "Sopro sistólico",
percussao: "Baço aumentado",
observacoes: "Talassemia maior com alterações ósseas",
regiao: "Geral",
achados_positivos: [
"Palidez",
"Alterações faciais",
"Hepatomegalia",
"Esplenomegalia",
"Retardo de crescimento",
],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Alterações faciais, palidez",
palpacao: "Hepatomegalia, esplenomegalia",
ausculta: "Sopro sistólico",
percussao: "Baço aumentado",
observacoes: "Talassemia maior",
},
exame_fisico_interativo: {
geral: {
coloracao: "Muito pálido",
facies: "Proeminência frontal e malar",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemograma",
descricao: "Série vermelha",
resultado: "Hb 7.5, VCM 72, RDW elevado",
valor_referencia: "Hb 12-16, VCM 80-100",
interpretacao: "Anemia macrocítica com anisocitose",
},
{
nome: "Hemoglobina F",
descricao: "Hemoglobina fetal",
resultado: "80%",
valor_referencia: "<1%",
interpretacao: "Talassemia maior",
},
{
nome: "Ferritina",
descricao: "Sobrecarga de ferro",
resultado: "3500 ng/mL",
valor_referencia: "<24 ng/mL",
interpretacao: "Sobrecarga de ferro",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Talassemia Maior",
probabilidade: 98,
criterios_minimos: [
"Anemia macrocítica",
"Hemoglobina F elevada",
"Alterações ósseas faciais",
"Hepatosplenomegalia",
"Transfusões regulares",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Talassemia menor",
criterios_exclusao: ["Hemoglobina F 80%"],
achados_que_descartam: ["HbF normal"],
},
],
examesIndicados: [
"Hemograma com RDW",
"Eletroforese de hemoglobina",
"Hemoglobina F",
"Estudo de ferro (ferritina, TIBC)",
"Ecocardiograma anual",
],
conduta_esperada: {
imediata: [
"Continuação de transfusões",
"Quelação de ferro",
],
curto_prazo: [
"Monitorização de complicações",
"Possível transplante de medula",
],
longo_prazo: [
"Seguimento multidisciplinar",
],
encaminhamentos: ["Hematologia"],
},
condutaCorreta: "Hemograma, hemoglobina F, ferritina, quelação de ferro, transplante de medula se indicado",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["Anemia severa", "Sobrecarga de ferro", "Alterações faciais"],
descricao: "Talassemia maior com complicações",
recomendacao: "Seguimento hematológico intensivo",
},
],
erros_criticos: [
{
erro: "Não monitorizar sobrecarga de ferro",
descricao: "Complicação grave e tratável",
penalidade: 1.5,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu talassemia",
realizado: false,
critico: true,
},
{
item: "Solicitou hemoglobina F",
realizado: false,
critico: true,
},
{
item: "Avaliou sobrecarga de ferro",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de talassemia",
peso: 25,
descricao: "Achados clínicos e laboratoriais",
pontuacao_maxima: 25,
},
{
criterio: "Manejo de complicações",
peso: 20,
descricao: "Monitorização de ferro",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Cansaço crônico",
"Alterações faciais",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Anemia severa",
"Hemoglobina F 80%",
"Hepatosplenomegalia",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Talassemia maior"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Transfusões regulares",
"Quelação de ferro",
"Hematologia",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu talassemia",
"Solicitou hemoglobina F",
"Avaliou sobrecarga de ferro",
],
erros_comuns: ["Confundir com anemia ferropriva"],
orientacoes_pedagogicas: [
"Talassemia: hemoglobina F elevada",
"Anemia ferropriva: ferro baixo",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar talassemia e monitorizar complicações",
comunicacao: ["explicou importância de transfusões"],
anamnese: ["investigou origem étnica"],
exame_fisico: ["detectou alterações faciais"],
exames_complementares: ["pediu hemoglobina F"],
raciocinio: ["diagnosticou talassemia"],
conduta: ["monitorizar ferro"],
soap: ["documentou talassemia"],
},
temaOSCE: "Anemias hereditárias",
subtopicosOSCE: [
"Talassemia maior",
"Hemoglobina F elevada",
"Anemia macrocítica",
"Sobrecarga de ferro",
"Alterações ósseas",
],
diagnosticoCorreto: "Talassemia Maior",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("53"),
} as CasoOSCEV2;
