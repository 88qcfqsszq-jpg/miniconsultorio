import { casoSCAIAM } from "./adultos/cardiovascular/sca-iam";
import { casoAnginaEstavel } from "./adultos/cardiovascular/angina-estavel";
import { casoInsuficienciaCardiaca } from "./adultos/cardiovascular/insuficiencia-cardiaca";
import { casoPericardite } from "./adultos/cardiovascular/pericardite";
import { casoPneumonia } from "./adultos/respiratorio/pneumonia";
import { casoAsma } from "./adultos/respiratorio/asma";
import { casoDPOC } from "./adultos/respiratorio/dpoc";
import { casoTEP } from "./adultos/respiratorio/tep";
import { casoDengue } from "./adultos/infectologia/dengue";
import { casoTuberculose } from "./adultos/infectologia/tuberculose";
import { casoAnemiaFerropriva } from "./adultos/hematologia/anemia-ferropriva";
import { casoAnemiaHemolitica } from "./adultos/hematologia/anemia-hemolitica";
import { casoFebreViral } from "./pediatricos/febre-viral";
import { casoPuericultura } from "./pediatricos/puericultura";
import { casoBronquiolite } from "./pediatricos/bronquiolite";

export const casosV2 = [
  casoSCAIAM,
  casoAnginaEstavel,
  casoInsuficienciaCardiaca,
  casoPericardite,
  casoPneumonia,
  casoAsma,
  casoDPOC,
  casoTEP,
  casoDengue,
  casoTuberculose,
  casoAnemiaFerropriva,
  casoAnemiaHemolitica,
  casoFebreViral,
  casoPuericultura,
  casoBronquiolite,
];

export type { CasoOSCEV2 } from "@/types/caso-osce-v2";
