import { Caso } from "@/lib/types";

export interface PainelLaboratorialV2 {
  solicitadoPor: string[];
  disponivel: boolean;
  prioridade: "obrigatorio" | "obrigatorio_imediato" | "importante" | "complementar" | "opcional" | "rotina";
  interpretacao: string;
  valores: Record<string, string>;
  valoresReferencia?: Record<string, string>;
  comentarioClinico?: string;
}

export interface ExamesLaboratoriaisDetalhadosV2 {
  hemograma?: PainelLaboratorialV2;
  funcaoRenal?: PainelLaboratorialV2;
  eletrolitos?: PainelLaboratorialV2;
  marcadoresInflamatorios?: PainelLaboratorialV2;
  gasometria?: PainelLaboratorialV2;
  marcadoresCardiacos?: PainelLaboratorialV2;
  funcaoHepatica?: PainelLaboratorialV2;
  coagulograma?: PainelLaboratorialV2;
  urinaTipo1?: PainelLaboratorialV2;

  // Painéis especiais por caso.
  perfilFerro?: PainelLaboratorialV2;
  perfilHemolise?: PainelLaboratorialV2;
  coombsDireto?: PainelLaboratorialV2;
  esfregacoPeriferico?: PainelLaboratorialV2;
  baciloscopiaEscarro?: PainelLaboratorialV2;
  liquidoPleural?: PainelLaboratorialV2;
  hemoculturas?: PainelLaboratorialV2;
  liquor?: PainelLaboratorialV2;
  imunologiaHIV?: PainelLaboratorialV2;
  culturas?: PainelLaboratorialV2;
  vitaminas?: PainelLaboratorialV2;
  eritropoetinaJAK2?: PainelLaboratorialV2;
  proteinas?: PainelLaboratorialV2;
  mielograma?: PainelLaboratorialV2;
  eletroforeseHemoglobina?: PainelLaboratorialV2;
  controleGlicemico?: PainelLaboratorialV2;
  autoimunidade?: PainelLaboratorialV2;
}

export type CasoOSCEV2 = Caso & {
  exames_laboratoriais_detalhados: ExamesLaboratoriaisDetalhadosV2;
};
