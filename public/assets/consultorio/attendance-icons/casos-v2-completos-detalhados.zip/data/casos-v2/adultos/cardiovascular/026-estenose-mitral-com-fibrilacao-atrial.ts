import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso026EstenoseMitralComFibrilacaoAtrial: CasoOSCEV2 = {
// ====== CASO 26: ESTENOSE MITRAL COM FIBRILAÇÃO ATRIAL ======
id: "26",
titulo: "Estenose Mitral com Fibrilação Atrial",
sistema: "Cardiovascular",
tema: "Valvopatia",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 11,
objetivo_pedagogico: "Diagnosticar estenose mitral e reconhecer complicação de fibrilação atrial",
dados_visiveis_ao_estudante: {
nome_paciente: "Carolina Dias",
idade: 58,
sexo: "Feminino",
queixa_principal: "Palpitações e falta de ar",
historia_breve: "Histórico de febre reumática, agora com palpitações recentes",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Estenose Mitral com Fibrilação Atrial",
diagnosticos_diferenciais: ["Insuficiência Mitral", "Insuficiência Cardíaca"],
sindromes_associadas: ["Valvopatia Reumática"],
},
descricaoBreve: "Paciente com sopro diastólico em ápice, ritmo irregularmente irregular, risco de trombo atrial",
categoria: "Valvopatia",
paciente: {
id: "pac-026",
nome: "Carolina Dias",
idade: 58,
sexo: "F",
queixaPrincipal: "Palpitações",
historicoDoenca: "Febre reumática aos 15 anos",
antecedentes: ["Febre reumática"],
profissao: "Comerciante",
estado_civil: "Viúva",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Tô com batidas aceleradas no coração",
palpitacoes: "Sim, irregular",
dispneia: "Sim, especialmente ao deitar-se",
tosse: "Sim, costumo acordar tossindo",
sincope: "Não, mas fico tonta",
historico: "Tive febre reumática quando era jovem",
},
respostaPaciente: {
inicial: "Palpitações",
palpitacoes: "Sim, irregular",
dispneia: "Sim",
tosse: "Sim",
sincope: "Não",
historico: "Febre reumática",
},
sinais_vitais: {
corretos: {
pressaoArterial: "130/80 mmHg",
frequenciaCardiaca: 110,
frequenciaRespiratoria: 20,
temperatura: 36.8,
saturacaoOxigenio: 94,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "130/80 mmHg",
frequenciaCardiaca: 110,
frequenciaRespiratoria: 20,
temperatura: 36.8,
saturacaoOxigenio: 94,
},
exame_fisico: {
correto: {
inspecao: "Rubor malar bilateral",
palpacao: "Frêmito diastólico",
ausculta: "Opening snap seguido de sopro diastólico, ritmo irregularmente irregular",
percussao: "Normal",
observacoes: "Sinais de EM com FA",
regiao: "Precórdio",
achados_positivos: ["Opening snap", "Sopro diastólico"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Rubor malar",
palpacao: "Frêmito diastólico",
ausculta: "Opening snap, sopro diastólico, ritmo irregular",
percussao: "Normal",
observacoes: "EM com FA",
},
exame_fisico_interativo: {
cardiovascular: {
inspecao_precordial: "Sem alterações estruturais",
ausculta_cardiaca: "Opening snap audível após B2, seguido de sopro diastólico rumbante, ritmo irregularmente irregular",
pulsos: "Irregulares",
turgencia_jugular: "Possível elevação",
edema: "Possível em MMII",
},
},
exames_complementares_disponiveis: [
{
nome: "Ecocardiograma",
descricao: "Avaliação de mitral",
resultado: "Válvula mitral espessada, área <1.5 cm², FA em ECG",
valor_referencia: "Normal",
interpretacao: "EM com FA",
},
{
nome: "ECG",
descricao: "Eletrocardiograma",
resultado: "Fibrilação atrial, possível onda P não organizada",
valor_referencia: "Ritmo sinusal",
interpretacao: "FA",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Estenose Mitral com FA",
probabilidade: 95,
criterios_minimos: [
"Sopro diastólico + opening snap",
"Ritmo irregularmente irregular",
"Área mitral <1.5 cm²",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "IM com FA",
criterios_exclusao: ["Opening snap"],
achados_que_descartam: ["Sopro sistólico"],
},
],
examesIndicados: [
"Ecocardiograma",
"ECG",
"Radiografia de tórax",
"D-dímero ou ecocardiograma transesofágico para descartar trombo",
],
conduta_esperada: {
imediata: [
"Anticoagulação urgente",
"Controle de frequência com betabloqueador ou digoxina",
],
curto_prazo: [
"Monitorização",
"Possível cardioversão",
"Avaliação para comissurotomia",
],
longo_prazo: [
"Anticoagulação contínua",
"Possível comissurotomia percutânea ou plástica valvular",
],
encaminhamentos: ["Cardiologia"],
},
condutaCorreta: "Anticoagulação imediata, controle de frequência, ecocardiograma, avaliação para comissurotomia",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["FA de resposta rápida", "Congestão"],
descricao: "Risco de AVC",
recomendacao: "Anticoagulação urgente",
},
],
erros_criticos: [
{
erro: "Não anticoagular",
descricao: "Risco muito alto de AVC",
penalidade: 3,
evitavel: true,
},
{
erro: "Não controlar frequência",
descricao: "Pode precipitar IC",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Detectou opening snap",
realizado: false,
critico: true,
},
{
item: "Detectou sopro diastólico",
realizado: false,
critico: true,
},
{
item: "Reconheceu ritmo irregularmente irregular",
realizado: false,
critico: true,
},
{
item: "Prescreveu anticoagulante",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de EM + FA",
peso: 30,
descricao: "Achados auscultatórios e ECG",
pontuacao_maxima: 30,
},
{
criterio: "Anticoagulação",
peso: 25,
descricao: "Prevenção de AVC",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Palpitações",
"Febre reumática infantil",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Opening snap",
"Sopro diastólico",
"Ritmo irregular",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Estenose mitral com FA"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Anticoagulação",
"Controle de FC",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu EM",
"Detectou FA",
"Prescreveu anticoagulante",
"Controle de frequência",
],
erros_comuns: ["Confundir com IM"],
orientacoes_pedagogicas: [
"EM: opening snap + sopro diastólico",
"FA em EM = SEMPRE anticoagular",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar EM e reconhecer FA como complicação grave",
comunicacao: ["explicou risco de AVC"],
anamnese: ["investigou FR"],
exame_fisico: ["detectou opening snap"],
exames_complementares: ["pediu eco e ECG"],
raciocinio: ["diagnosticou EM + FA"],
conduta: ["anticoagulou apropriadamente"],
soap: ["documentou EM + FA"],
},
temaOSCE: "Valvopatias",
subtopicosOSCE: [
"Estenose mitral",
"Opening snap",
"Fibrilação atrial",
"Anticoagulação",
],
diagnosticoCorreto: "Estenose Mitral com Fibrilação Atrial",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("26"),
} as CasoOSCEV2;
