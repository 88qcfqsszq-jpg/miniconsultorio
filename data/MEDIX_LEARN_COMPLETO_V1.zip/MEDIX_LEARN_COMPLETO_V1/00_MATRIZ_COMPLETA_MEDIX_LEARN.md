# Matriz Completa do MEDIX Learn

## Módulos oficiais

```text
MEDIX Learn
├── Respiratório
├── Cardiovascular
├── Infectologia
├── Neurologia
├── Gastro/Abdome
├── Semiologia Geral
└── Raciocínio Clínico
```

## 1. Respiratório

Ordem recomendada de criação:

```text
1. Hipoxemia
2. Dispneia
3. Exame físico respiratório
4. Sibilância e broncoespasmo
5. Tosse e febre
6. Dor torácica pleurítica
7. Gasometria básica
```

Casos recorrentes: asma, DPOC, pneumonia, TEP, pneumotórax, derrame pleural, edema agudo de pulmão, tuberculose.

## 2. Cardiovascular

Trilhas propostas:

```text
1. Dor torácica
2. Dispneia cardíaca e congestão
3. Edema e insuficiência cardíaca
4. Hipertensão e risco cardiovascular
5. Síncope e palpitações
6. Exame físico cardiovascular
7. ECG básico para clínico iniciante
```

Casos recorrentes: síndrome coronariana aguda, insuficiência cardíaca, crise hipertensiva, arritmia, valvopatias, pericardite.

## 3. Infectologia

Trilhas propostas:

```text
1. Febre
2. Sepse e sinais de gravidade
3. Infecção respiratória
4. Infecção urinária
5. Dengue e arboviroses
6. Antibiótico: quando pensar, quando não pensar
7. Isolamento, transmissão e prevenção
```

Casos recorrentes: pneumonia, ITU, pielonefrite, dengue, sepse, meningite, celulite.

## 4. Neurologia

Trilhas propostas:

```text
1. Cefaleia e sinais de alarme
2. Rebaixamento do nível de consciência
3. Déficit neurológico focal e AVC
4. Convulsão
5. Tontura e vertigem
6. Exame neurológico essencial
7. Síndromes meníngeas
```

Casos recorrentes: AVC, crise convulsiva, meningite, hipoglicemia, migrânea, vertigem periférica.

## 5. Gastro/Abdome

Trilhas propostas:

```text
1. Dor abdominal
2. Náuseas, vômitos e desidratação
3. Diarreia
4. Icterícia
5. Sangramento digestivo
6. Exame físico abdominal
7. Abdome agudo: raciocínio inicial
```

Casos recorrentes: apendicite, gastroenterite, colecistite, pancreatite, hepatite, obstrução intestinal, hemorragia digestiva.

## 6. Semiologia Geral

Trilhas propostas:

```text
1. Como colher uma boa história clínica
2. Queixa principal e história da doença atual
3. Sinais vitais
4. Estado geral e nível de consciência
5. Dor: caracterização semiológica
6. Exame físico geral
7. Comunicação clínica inicial
```

Essas trilhas alimentam todos os sistemas.

## 7. Raciocínio Clínico

Trilhas propostas:

```text
1. Sintoma, sinal, síndrome e diagnóstico
2. Diagnóstico diferencial
3. Gravidade e red flags
4. Priorização: o que fazer primeiro
5. Interpretação de exames básicos
6. Erros cognitivos em medicina
7. Raciocínio de conduta e reavaliação
```

Este módulo é transversal: aparece em todos os sistemas e prepara o aluno para OSCE.

## Formato fixo de cada trilha

Toda trilha do MEDIX Learn deve ter:

1. Microaula
2. Fisiologia aplicada
3. Semiologia
4. Raciocínio clínico
5. Mini-casos
6. Questões ativas
7. Erros comuns
8. Mapa final
9. Ponte para OSCE Ciclo Básico
10. Ponte para OSCE Clínico quando houver simulação dinâmica

## Critério de profundidade

Cada trilha deve responder três perguntas:

1. **O que está acontecendo no corpo?**
2. **Como isso aparece no paciente?**
3. **O que o estudante deve pensar e fazer primeiro?**
