import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso007PericarditeAguda: CasoOSCEV2 = {
// ====== CASO 7: PERICARDITE AGUDA ======
id: "7",
titulo: "Pericardite Aguda",
sistema: "Cardiovascular",
tema: "Dor Torácica",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Diagnosticar pericardite aguda e diferenciar de infarto do miocárdio",
dados_visiveis_ao_estudante: {
nome_paciente: "Lucas Ferreira",
idade: 34,
sexo: "Masculino",
queixa_principal: "Dor no peito que piora ao respirar",
historia_breve: "Começou com infecção viral há uma semana, agora com dor ao respirar",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Pericardite Aguda",
diagnosticos_diferenciais: [
"Infarto Agudo do Miocárdio",
"Pleuresia",
"Pneumonia",
"Espasmo Esofágico",
],
sindromes_associadas: ["Síndrome pericárdica"],
},
descricaoBreve: "Paciente com dor pleurítica, febre, antecedente de infecção viral",
categoria: "Pericardite",
paciente: {
id: "pac-007",
nome: "Lucas Ferreira",
idade: 34,
sexo: "M",
queixaPrincipal: "Dor no peito que piora ao respirar",
historicoDoenca: "Infecção viral uma semana atrás, agora com dor ao respirar",
antecedentes: ["Sem antecedentes relevantes"],
profissao: "Professor",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Doutor, tenho uma dor no peito que piora quando respiro fundo.",
dor: "Aqui no meio do peito, tipo uma pontada.",
intensidade: "7 a 8, bem incômodo.",
respiracao: "Piora muito quando respiro fundo ou tosse.",
posicao: "Fico mais confortável sentado e inclinado para frente.",
febre: "Tive febre há uma semana, agora melhorou.",
infeccao: "Peguei um resfriado viral há uma semana.",
duracao: "Começou ontem, contínua.",
outro: "Fico um pouco cansado.",
},
respostaPaciente: {
inicial: "Doutor, tenho uma dor no peito que piora quando respiro fundo.",
dor: "Aqui no meio do peito, tipo uma pontada.",
intensidade: "7 a 8, bem incômodo.",
respiracao: "Piora muito quando respiro fundo ou tosse.",
posicao: "Fico mais confortável sentado e inclinado para frente.",
febre: "Tive febre há uma semana, agora melhorou.",
infeccao: "Peguei um resfriado viral há uma semana.",
duracao: "Começou ontem, contínua.",
outro: "Fico um pouco cansado.",
},
sinais_vitais: {
corretos: {
pressaoArterial: "125/80 mmHg",
frequenciaCardiaca: 95,
frequenciaRespiratoria: 20,
temperatura: 37.5,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "125/80 mmHg",
frequenciaCardiaca: 95,
frequenciaRespiratoria: 20,
temperatura: 37.5,
saturacaoOxigenio: 98,
glicemia: 108,
},
exame_fisico: {
correto: {
inspecao: "Paciente em desconforto ao respirar fundo, senta inclinado para frente",
palpacao: "Ictus cordis não desviado, sem alterações palpáveis",
ausculta: "Atrito pericárdico em foco apical (som de couro novo), ritmo regular",
percussao: "Normal",
observacoes: "Achado clássico: atrito pericárdico, piora com respiração profunda",
regiao: "Precórdio",
achados_positivos: ["Atrito pericárdico", "Dor pleurítica"],
achados_negativos: ["Sopros", "B3", "Desvio de ictus"],
},
},
exameFisicoCorreto: {
inspecao: "Paciente em desconforto ao respirar, posição sentada inclinada",
palpacao: "Ictus cordis não desviado",
ausculta: "Atrito pericárdico em foco apical",
percussao: "Normal",
observacoes: "Achado clássico: atrito pericárdico",
},
exames_complementares_disponiveis: [
{
nome: "ECG",
descricao: "12 derivações",
resultado: "Elevação difusa de ST com concavidade, sem ondas Q patológicas",
valor_referencia: "Normal",
interpretacao: "Padrão típico de pericardite aguda",
},
{
nome: "Troponina I",
descricao: "Biomarcador cardíaco",
resultado: "<0.04 ng/mL",
valor_referencia: "<0.04 ng/mL",
interpretacao: "Negativa - sem infarto",
},
{
nome: "PCR (Proteína C Reativa)",
descricao: "Marcador inflamatório",
resultado: "Elevada 8 mg/dL",
valor_referencia: "<3 mg/dL",
interpretacao: "Inflamação presente",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Pericardite Aguda",
probabilidade: 90,
criterios_minimos: [
"Dor pleurítica",
"Antecedente viral",
"Atrito pericárdico",
"ECG com ST elevado difuso",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Infarto Agudo do Miocárdio",
criterios_exclusao: ["Elevação difusa de ST sem ondas Q"],
achados_que_descartam: ["Troponina negativa", "Atrito pericárdico"],
},
],
examesIndicados: [
"ECG seriados",
"Troponina",
"PCR",
"Ecocardiograma para descartar derrame",
],
conduta_esperada: {
imediata: [
"Anti-inflamatório: Ibuprofeno ou Indomentacina",
"Colchicina em alguns casos",
"Repouso relativo",
],
curto_prazo: ["Ecocardiograma para avaliar derrame", "ECG seriados"],
longo_prazo: [
"Seguimento clínico",
"Investigação de etiologia se persistir",
],
encaminhamentos: ["Cardiologia se complicações"],
},
condutaCorreta:
"Anti-inflamatório (Ibuprofeno), colchicina, repouso, monitorização com ECG seriados",
criterios_de_gravidade: [
{
severidade: "leve",
sinais: ["Dor ao respirar", "Sem derrame"],
descricao: "Pericardite aguda sem complicações",
recomendacao: "Tratamento com AINE e colchicina",
},
{
severidade: "moderada",
sinais: ["Derrame pericárdico presente"],
descricao: "Pericardite com efusão",
recomendacao: "AINE, colchicina, avaliação cardíaca frequente",
},
],
erros_criticos: [
{
erro: "Confundir com infarto e prescrever antiagregante/anticoagulante",
descricao: "Verificar troponina e padrão de ST antes de iniciar terapia",
penalidade: 2.5,
evitavel: true,
},
{
erro: "Não solicitar ECG",
descricao: "ECG é essencial para diagnóstico diferencial com IAM",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{ item: "Investigou relação com respiração e posição", realizado: false, critico: true },
{ item: "Perguntou sobre infecção viral prévia", realizado: false, critico: true },
{ item: "Mediu sinais vitais", realizado: false, critico: true },
{ item: "Ausculta: buscou atrito pericárdico", realizado: false, critico: true },
{ item: "Solicitou ECG", realizado: false, critico: true },
{ item: "Solicitou troponina", realizado: false, critico: true },
{ item: "Prescreveu AINE", realizado: false, critico: true },
],
rubrica_correcao: [
{
criterio: "Diagnóstico Diferencial",
peso: 25,
descricao: "Diferenciação com IAM",
pontuacao_maxima: 25,
},
{
criterio: "Achados Clínicos",
peso: 20,
descricao: "Reconhecimento de atrito e dor pleurítica",
pontuacao_maxima: 20,
},
{
criterio: "Terapia",
peso: 25,
descricao: "Prescrição de AINE e colchicina",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dor pleurítica",
"Antecedente viral",
"Piora com respiração",
"Melhora com flexão anterior",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Sinais vitais",
"Atrito pericárdico",
"ECG com ST elevado difuso",
"Troponina negativa",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Pericardite aguda", "Sem sinais de tamponamento"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"AINE",
"Colchicina",
"Repouso",
"Ecocardiograma",
"ECG seriados",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu padrão de dor pleurítica",
"Investigou infecção viral prévia",
"Solicitou ECG e troponina",
"Identificou atrito pericárdico",
"Prescreveu AINE apropriadamente",
],
erros_comuns: [
"Confundir com infarto",
"Prescrever aspirina desnecessariamente",
"Não investigar derrame",
],
orientacoes_pedagogicas: [
"Pericardite: dor pleurítica, melhora com flexão anterior",
"Atrito pericárdico é achado clássico",
"ECG: ST elevado difuso (não localizado como em IAM)",
"Troponina geralmente negativa",
"AINE é terapia de primeira linha",
],
},
temaOSCE: "Valvopatias",
subtopicosOSCE: [
"Pericardite aguda",
"Dor pleurítica com sopro de atrito",
"ECG com elevação difusa de ST",
"Ecocardiograma",
"Anti-inflamatórios como primeira linha"
],
diagnosticoCorreto: "Pericardite Aguda",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("7"),
} as CasoOSCEV2;
