import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso058SindromeMetabolicaComInfartoAgudo: CasoOSCEV2 = {
// ====== CASO 58: SÍNDROME METABÓLICA COM INFARTO ======
id: "58",
titulo: "Síndrome Metabólica com Infarto Agudo do Miocárdio",
sistema: "Cardiologia",
tema: "Casos Integradores",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 13,
objetivo_pedagogico: "Reconhecer síndrome metabólica como fator de risco e diagnosticar IAM",
dados_visiveis_ao_estudante: {
nome_paciente: "Ricardo Neves",
idade: 55,
sexo: "Masculino",
queixa_principal: "Dor no peito tipo aperto, sudorese, mal-estar",
historia_breve: "Homem obeso com síndrome metabólica apresentando IAM",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Infarto Agudo do Miocárdio em Paciente com Síndrome Metabólica",
diagnosticos_diferenciais: ["Angina instável", "Pericardite", "Embolia pulmonar"],
sindromes_associadas: ["Síndrome metabólica", "Obesidade", "Hipertensão", "Dislipidemia"],
},
descricaoBreve: "Paciente com dor torácica, ST elevado, troponina elevada, circunferência abdominal aumentada",
categoria: "Casos Integradores",
paciente: {
id: "pac-058",
nome: "Ricardo Neves",
idade: 55,
sexo: "M",
queixaPrincipal: "Dor no peito",
historicoDoenca: "Obesidade e síndrome metabólica",
antecedentes: ["Obesidade", "HAS", "Dislipidemia", "Sedentarismo"],
profissao: "Executivo",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: ["Losartana"],
},
respostas_do_paciente: {
inicial: "Tenho dor forte no peito, não consigo respirar",
dor: "Dor tipo aperto, irradia para braço esquerdo",
respiracao: "Muito falta de ar",
sudorese: "Suando muito, frio na espinha",
nausea: "Enjoo",
duracao: "Começou há 2 horas",
antecedentes_dor: "Tinha dor ao esforço antes",
},
respostaPaciente: {
inicial: "Dor torácica súbita",
dor: "Aperto, irradia braço esquerdo",
respiracao: "Muita",
sudorese: "Sim",
nausea: "Sim",
duracao: "2 horas",
antecedentes_dor: "Sim",
},
sinais_vitais: {
corretos: {
pressaoArterial: "155/95 mmHg",
frequenciaCardiaca: 115,
frequenciaRespiratoria: 22,
temperatura: 36.8,
saturacaoOxigenio: 94,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "155/95 mmHg",
frequenciaCardiaca: 115,
frequenciaRespiratoria: 22,
temperatura: 36.8,
saturacaoOxigenio: 94,
},
exame_fisico: {
correto: {
inspecao: "Paciente ansioso, obeso, diaforético",
palpacao: "Ictus deslocado, taquicardia",
ausculta: "Taquicardia, ritmo irregular ocasional",
percussao: "Normal",
observacoes: "Sinais de IAM com insuficiência cardíaca incipiente",
regiao: "Precórdio e geral",
achados_positivos: ["Taquicardia", "Ictus deslocado", "Diaforese"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Obeso, diaforético",
palpacao: "Ictus deslocado",
ausculta: "Taquicardia",
percussao: "Normal",
observacoes: "IAM",
},
exame_fisico_interativo: {
cardiovascular: {
inspecao_precordial: "Diaforese",
ausculta_cardiaca: "Taquicardia, B1 e B2 audíveis",
},
},
exames_complementares_disponiveis: [
{
nome: "ECG",
descricao: "Eletrocardiograma",
resultado: "ST elevado em V1-V4 (IAM anterior)",
valor_referencia: "Normal",
interpretacao: "IAM com supra de ST anterior",
},
{
nome: "Troponina I",
descricao: "Marcador cardíaco",
resultado: "2.5 ng/mL",
valor_referencia: "<0.04 ng/mL",
interpretacao: "Lesão miocárdica aguda",
},
{
nome: "Glicemia",
descricao: "Glicose em jejum",
resultado: "180 mg/dL",
valor_referencia: "<100 mg/dL",
interpretacao: "Hiperglicemia",
},
{
nome: "Colesterol total",
descricao: "Lipídios",
resultado: "285 mg/dL",
valor_referencia: "<200 mg/dL",
interpretacao: "Hipercolesterolemia",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Infarto Agudo do Miocárdio com Supra de ST",
probabilidade: 98,
criterios_minimos: [
"Dor torácica típica",
"ST elevado no ECG",
"Troponina elevada",
"Síndrome metabólica",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Angina instável",
criterios_exclusao: ["ST elevado"],
achados_que_descartam: ["ECG com supra"],
},
],
examesIndicados: [
"ECG seriado",
"Troponina seriada",
"Ecocardiograma",
"Cateterismo coronariano",
"Lipidograma, glicemia",
],
conduta_esperada: {
imediata: [
"Angioplastia primária",
"Dupla antiagregação",
"Anticoagulação",
"Internação em UCO",
],
curto_prazo: [
"Rehabilitação cardíaca",
"Controle de fatores de risco",
],
longo_prazo: [
"Prevenção secundária",
],
encaminhamentos: ["Cardiologia", "UCO"],
},
condutaCorreta: "ECG, troponina, angioplastia primária, dupla antiagregação, anticoagulação, UCO",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["ST elevado", "Troponina elevada", "Choque"],
descricao: "IAM agudo com risco de morte",
recomendacao: "Angioplastia primária urgente",
},
],
erros_criticos: [
{
erro: "Atrasar revascularização",
descricao: "Tempo é músculo",
penalidade: 3,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu IAM",
realizado: false,
critico: true,
},
{
item: "Solicitou ECG urgente",
realizado: false,
critico: true,
},
{
item: "Avaliou troponina",
realizado: false,
critico: true,
},
{
item: "Encaminhou cardiologia",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de IAM",
peso: 35,
descricao: "Clínica e ECG",
pontuacao_maxima: 35,
},
{
criterio: "Urgência de revascularização",
peso: 30,
descricao: "Angioplastia primária",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dor torácica típica",
"Síndrome metabólica",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"ST elevado",
"Troponina elevada",
"Taquicardia",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["IAM com supra de ST"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Angioplastia",
"Dupla antiagregação",
"Cardiologia",
"UCO",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu IAM",
"Solicitou ECG",
"Encaminhou cardiologia",
],
erros_comuns: ["Atrasar diagnóstico"],
orientacoes_pedagogicas: [
"IAM: dor + ST elevado + troponina",
"Síndrome metabólica é fator de risco",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer IAM e encaminhar urgentemente",
comunicacao: ["explicou urgência"],
anamnese: ["investigou fatores de risco"],
exame_fisico: ["detectou sinais de insuficiência"],
exames_complementares: ["pediu ECG"],
raciocinio: ["diagnosticou IAM"],
conduta: ["encaminhou cardiologia"],
soap: ["documentou urgência"],
},
temaOSCE: "Casos Integradores",
subtopicosOSCE: [
"IAM com supra",
"Síndrome metabólica",
"Fatores de risco",
"Angioplastia",
"Emergência",
],
diagnosticoCorreto: "Infarto Agudo do Miocárdio com Supra de ST",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("58"),
} as CasoOSCEV2;
