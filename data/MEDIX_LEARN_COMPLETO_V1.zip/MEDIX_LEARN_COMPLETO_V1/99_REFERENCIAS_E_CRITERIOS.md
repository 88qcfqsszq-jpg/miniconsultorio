# Referências e critérios médicos usados na curadoria

Este pacote é um material pedagógico para estudantes. Ele não substitui aula, supervisão clínica, protocolos locais nem diretrizes assistenciais.

## Fontes de base consultadas para conceitos respiratórios

- Sarkar M. et al. **Mechanisms of hypoxemia**. Lung India. 2017. PMC/NIH.
- StatPearls/NCBI Bookshelf. **Hypoxia and Hypoxemia**.
- MSD/Merck Manual Professional. **Evaluation of the Patient With Pulmonary Issues**.
- StatPearls/NCBI Bookshelf. **Arterial Blood Gas**.
- Merck Manual Professional. **Acute Hypoxemic Respiratory Failure / ARDS**.

## Critérios de escrita do MEDIX Learn

1. Sempre ligar fisiologia à semiologia.
2. Sempre incluir mini-casos.
3. Sempre apontar erros comuns.
4. Sempre terminar com ponte para OSCE.
5. Evitar linguagem excessivamente técnica no primeiro contato.
6. Aprofundar por camadas.
7. Nunca transformar o Learn em resumo passivo.
8. Não inventar condutas específicas sem validação médica/curadoria.
9. Em conteúdos terapêuticos, manter linguagem educacional e remeter a protocolos/supervisão.

## Observação sobre segurança

O MEDIX Learn deve ensinar raciocínio. Em situações reais, diagnóstico e conduta dependem de avaliação profissional, contexto clínico, protocolos locais e supervisão.
