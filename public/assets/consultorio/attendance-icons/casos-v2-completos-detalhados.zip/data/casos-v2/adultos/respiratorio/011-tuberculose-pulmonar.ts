import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso011TuberculosePulmonar: CasoOSCEV2 = {
// ====== CASO 11: TUBERCULOSE ======
id: "11",
titulo: "Tuberculose Pulmonar",
sistema: "Respiratório",
tema: "Infecção Crônica",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Diagnosticar TB pulmonar e prescrever esquema terapêutico apropriado",
dados_visiveis_ao_estudante: {
nome_paciente: "Roberto Santos",
idade: 42,
sexo: "Masculino",
queixa_principal: "Tosse há mais de 3 semanas",
historia_breve: "Tosse produtiva com sangue no escarro, febre à noite, perda de peso",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Tuberculose Pulmonar Ativa",
diagnosticos_diferenciais: [
"Pneumonia crônica",
"Micose pulmonar",
"Câncer de pulmão",
"Bronquiectasia",
],
sindromes_associadas: ["Síndrome consumptiva"],
},
descricaoBreve: "Paciente com tosse crônica, hemoptise, febre vespertina, perda ponderal",
categoria: "Tuberculose",
paciente: {
id: "pac-011",
nome: "Roberto Santos",
idade: 42,
sexo: "M",
queixaPrincipal: "Tosse há mais de 3 semanas",
historicoDoenca:
"Tosse produtiva com sangue no escarro, febre à noite, perda de peso",
antecedentes: ["Contato com TB previamente"],
profissao: "Mecânico",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Doutor, tô tossindo faz umas 3 semanas, não melhora.",
tosse: "Solta escarro, e às vezes tem sangue no meio.",
inicio: "Começou faz umas 3 semanas, progressivamente piorou.",
febre: "Tenho febre mais à noite, à tarde vou ficando quente.",
suor: "Acordo à noite todo suado, tenho que trocar de roupa.",
peso: "Emagreci bastante esses meses, ninguém reconhece.",
apetite: "Perdi o apetite, não tenho vontade de comer.",
cansaco: "Fico muito fraco, sem ânimo.",
contato: "Meu irmão teve TB faz uns 2 anos.",
},
respostaPaciente: {
inicial: "Doutor, tô tossindo faz umas 3 semanas, não melhora.",
tosse: "Solta escarro, e às vezes tem sangue no meio.",
inicio: "Começou faz umas 3 semanas, progressivamente piorou.",
febre: "Tenho febre mais à noite, à tarde vou ficando quente.",
suor: "Acordo à noite todo suado, tenho que trocar de roupa.",
peso: "Emagreci bastante esses meses, ninguém reconhece.",
apetite: "Perdi o apetite, não tenho vontade de comer.",
cansaco: "Fico muito fraco, sem ânimo.",
contato: "Meu irmão teve TB faz uns 2 anos.",
},
sinais_vitais: {
corretos: {
pressaoArterial: "120/75 mmHg",
frequenciaCardiaca: 92,
frequenciaRespiratoria: 22,
temperatura: 37.8,
saturacaoOxigenio: 95,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "120/75 mmHg",
frequenciaCardiaca: 92,
frequenciaRespiratoria: 22,
temperatura: 37.8,
saturacaoOxigenio: 95,
glicemia: 100,
},
exame_fisico: {
correto: {
inspecao: "Paciente emagrecido, pálido, tosse ocasional",
palpacao: "Expansão torácica simétrica",
ausculta: "Murmúrio vesicular reduzido em ápice direito, crepitações ocasionais",
percussao: "Macicez em ápice direito",
observacoes: "Achados sugestivos de consolidação apical de TB",
regiao: "Ápice de pulmão direito",
achados_positivos: ["Crepitações apicais", "Redução de MV apical"],
achados_negativos: ["Sibilos"],
},
},
exameFisicoCorreto: {
inspecao: "Paciente emagrecido, pálido",
palpacao: "Expansão simétrica",
ausculta: "Murmúrio reduzido em ápice direito",
percussao: "Macicez apical",
observacoes: "Consolidação apical sugestiva de TB",
},
exames_complementares_disponiveis: [
{
nome: "Radiografia de Tórax PA e Perfil",
descricao: "Avaliação pulmonar",
resultado: "Infiltrado opaco em ápice direito com escavação, consolidação lobar",
valor_referencia: "Normal",
interpretacao: "Compatível com TB ativa",
},
{
nome: "Baciloscopia de Escarro (2 amostras)",
descricao: "Pesquisa de BAAR",
resultado: "Positiva (BAAR +)",
valor_referencia: "Negativa",
interpretacao: "TB ativa, paciente bacilífero",
},
{
nome: "Hemograma",
descricao: "Série de glóbulos",
resultado: "Hb 10.5 g/dL (anemia), leucócitos 9.500/mm³",
valor_referencia: "Hb >12 g/dL, leucócitos 4.500-11.000/mm³",
interpretacao: "Anemia de doença crônica",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Tuberculose Pulmonar Ativa",
probabilidade: 95,
criterios_minimos: [
"Tosse >3 semanas",
"Hemoptise",
"Febre vespertina e sudorese noturna",
"Perda de peso",
"RX com infiltrado apical",
"Baciloscopia positiva",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Pneumonia Crônica",
criterios_exclusao: ["Baciloscopia positiva"],
achados_que_descartam: ["BAAR positivo"],
},
],
examesIndicados: [
"Radiografia de tórax",
"Baciloscopia de escarro (2 amostras)",
"TRM-TB (GeneXpert)",
"Hemograma",
"Função hepática e renal",
],
conduta_esperada: {
imediata: [
"Prescrever esquema RIPE (Rifampicina, Isoniazida, Pirazinamida, Etambutol)",
"Fase intensiva por 2 meses",
"Isolamento respiratório hospitalar se bacilífero",
],
curto_prazo: [
"Fase de manutenção: Rifampicina + Isoniazida por 4 meses",
"Avaliação de resposta em 2 meses",
"Notificação de contatos",
],
longo_prazo: [
"Esquema total 6 meses",
"Seguimento mensal",
"Busca de contatos para quimioprofilaxia",
],
encaminhamentos: [
"Pneumologia/TB se complicações",
"Infectologia para coinfecções",
],
},
condutaCorreta:
"Esquema RIPE: Rifampicina, Isoniazida, Pirazinamida, Etambutol. Fase intensiva 2 meses + manutenção 4 meses",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["Bacilífero", "Consolidação focal"],
descricao: "TB ativa com transmissibilidade",
recomendacao: "Esquema RIPE padrão, isolamento se hospitalar",
},
],
erros_criticos: [
{
erro: "Não solicitar baciloscopia",
descricao: "Baciloscopia é essencial para confirmação diagnóstica",
penalidade: 2.5,
evitavel: true,
},
{
erro: "Prescrever esquema incompleto ou dose errada",
descricao: "Esquema correto garante cura e evita resistência",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{ item: "Investigou tosse >3 semanas", realizado: false, critico: true },
{ item: "Perguntou sobre hemoptise, febre vespertina, sudorese", realizado: false, critico: true },
{ item: "Indagou sobre contatos e fatores de risco", realizado: false, critico: true },
{ item: "Mediu sinais vitais", realizado: false, critico: true },
{ item: "Solicitou RX de tórax", realizado: false, critico: true },
{ item: "Solicitou baciloscopia (2 amostras)", realizado: false, critico: true },
{ item: "Prescreveu esquema RIPE", realizado: false, critico: true },
],
rubrica_correcao: [
{
criterio: "Diagnóstico Diferencial",
peso: 15,
descricao: "Diferenciação com pneumonia crônica",
pontuacao_maxima: 15,
},
{
criterio: "Investigação Diagnóstica",
peso: 25,
descricao: "Baciloscopia apropriada",
pontuacao_maxima: 25,
},
{
criterio: "Esquema Terapêutico",
peso: 30,
descricao: "RIPE com doses e duração corretos",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Tosse >3 semanas",
"Hemoptise",
"Febre vespertina",
"Sudorese noturna",
"Perda de peso",
"Contato com TB",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Sinais vitais",
"Ausculta: redução de MV apical",
"RX: infiltrado apical",
"Baciloscopia: BAAR positivo",
"Hemograma: anemia",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"TB ativa bacilífera",
"Avaliação de comorbidades",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Esquema RIPE",
"Isolamento se hospitalar",
"Notificação de contatos",
"Seguimento mensal",
"Busca de contatos",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Investigou sintomas clássicos",
"Solicitou RX de tórax",
"Solicitou baciloscopia",
"Prescreveu RIPE",
"Abordou contatos e isolamento",
],
erros_comuns: [
"Não solicitar baciloscopia",
"Esquema terapêutico incompleto",
"Não investigar contatos",
],
orientacoes_pedagogicas: [
"TB: tosse >3 semanas, febre vespertina, sudorese, perda de peso",
"RX: infiltrado apical com escavação",
"Baciloscopia é fundamental",
"Esquema RIPE é padrão-ouro",
"Duração total: 6 meses (2 intensiva + 4 manutenção)",
],
},
temaOSCE: "DPOC",
subtopicosOSCE: [
"Tabagismo crônico",
"Tosse crônica e bronquite",
"Espirometria com VEF1/CVF <0.7",
"Broquiodilatadores e corticoides inalados",
"Exacerbação aguda"
],
diagnosticoCorreto: "Tuberculose Pulmonar Ativa",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("11"),
} as CasoOSCEV2;
