import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso023InsuficienciaMitralCronica: CasoOSCEV2 = {
// ====== CASO 23: INSUFICIÊNCIA MITRAL ======
id: "23",
titulo: "Insuficiência Mitral Crônica",
sistema: "Cardiovascular",
tema: "Valvopatia",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Diagnosticar insuficiência mitral e avaliar gravidade",
dados_visiveis_ao_estudante: {
nome_paciente: "Helena Ramos",
idade: 55,
sexo: "Feminino",
queixa_principal: "Falta de ar progressiva",
historia_breve: "Dispneia aos esforços que piorou nos últimos meses, palpitações ocasionais",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Insuficiência Mitral Crônica Moderada",
diagnosticos_diferenciais: ["Insuficiência Aórtica", "Estenose Mitral", "Cardiomiopatia"],
sindromes_associadas: ["Insuficiência Cardíaca"],
},
descricaoBreve: "Paciente com sopro holosistólico em ápice irradiado para axila, ictus amplo e deslocado",
categoria: "Valvopatia",
paciente: {
id: "pac-023",
nome: "Helena Ramos",
idade: 55,
sexo: "F",
queixaPrincipal: "Falta de ar progressiva",
historicoDoenca: "Dispneia ao esforço que piorou, paciente com febre reumática na infância",
antecedentes: ["Febre reumática infantil", "HAS"],
profissao: "Professora",
estado_civil: "Casada",
alergias: [],
medicamentos_em_uso: ["Losartana 50mg"],
},
respostas_do_paciente: {
inicial: "Tô ficando cada vez mais cansada, mal consigo subir escada",
dispneia: "Sim, ao fazer esforço, agora até em atividades leves",
palpitacoes: "Sim, ocasionalmente sinto palpitações",
edema: "Meus pés incharam um pouco",
historico: "Tive febre reumática quando era menina",
tosse: "Sim, uma tosse leve especialmente à noite",
ortopneia: "Às vezes preciso de mais travesseiros",
},
respostaPaciente: {
inicial: "Tô cansada, mal consigo subir escada",
dispneia: "Sim, ao esforço",
palpitacoes: "Sim",
edema: "Sim",
historico: "Febre reumática na infância",
tosse: "Sim, à noite",
ortopneia: "Às vezes",
},
sinais_vitais: {
corretos: {
pressaoArterial: "130/75 mmHg",
frequenciaCardiaca: 88,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 96,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "130/75 mmHg",
frequenciaCardiaca: 88,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 96,
},
exame_fisico: {
correto: {
inspecao: "Ictus amplo e deslocado para lateral",
palpacao: "Frêmito sistólico presente",
ausculta: "Sopro holosistólico em ápice irradiado para axila, possível B3",
percussao: "Normal",
observacoes: "Achados sugestivos de insuficiência mitral com dilatação ventricular",
regiao: "Precórdio",
achados_positivos: ["Sopro holosistólico", "Ictus amplo"],
achados_negativos: ["Sopro de abertura"],
},
},
exameFisicoCorreto: {
inspecao: "Ictus amplo e deslocado",
palpacao: "Frêmito sistólico",
ausculta: "Sopro holosistólico em ápice irradiado para axila",
percussao: "Normal",
observacoes: "Compatível com IM",
},
exame_fisico_interativo: {
cardiovascular: {
inspecao_precordial: "Ictus pulsátil amplo, deslocado para axila",
ausculta_cardiaca: "Sopro holosistólico máximo em ápice, irradiado para axila, possível B3",
pulsos: "Pulsos presentes e simétricos",
turgencia_jugular: "Normal",
edema: "Leve edema em tornozelos",
},
},
exames_complementares_disponiveis: [
{
nome: "Ecocardiograma",
descricao: "Avaliação de válvula mitral",
resultado: "Dilatação VE leve a moderada, regurgitação mitral moderada, leaflet anterior normal",
valor_referencia: "Válvulas normais",
interpretacao: "IM crônica moderada",
},
{
nome: "Radiografia de Tórax",
descricao: "PA e perfil",
resultado: "Aumento de silhueta cardíaca leve",
valor_referencia: "Normal",
interpretacao: "Cardiomegalia leve",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Insuficiência Mitral Crônica",
probabilidade: 95,
criterios_minimos: [
"Sopro holosistólico ápice-axila",
"Ictus amplo e deslocado",
"IM ao ecocardiograma",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Estenose Mitral",
criterios_exclusao: ["Sopro holosistólico"],
achados_que_descartam: ["Sopro diastólico"],
},
],
examesIndicados: [
"Ecocardiograma",
"Radiografia de tórax",
"ECG",
"Troponina se sintomas de IC",
],
conduta_esperada: {
imediata: [
"Monitorização conforme sintomas",
"Beta-bloqueador ou IECA/BRA conforme tolerância",
],
curto_prazo: [
"Ecocardiograma para avaliar gravidade",
"Avaliação de indicação de cirurgia",
],
longo_prazo: [
"Medicações conforme progressão",
"Possível plástica ou substituição valvular",
],
encaminhamentos: ["Cardiologia"],
},
condutaCorreta: "Ecocardiograma, medicações conforme sintomas, acompanhamento cardiológico, possível cirurgia valvular",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["Dilatação significativa", "Dispneia"],
descricao: "Possível indicação de cirurgia",
recomendacao: "Acompanhamento especializado",
},
],
erros_criticos: [
{
erro: "Não solicitar ecocardiograma",
descricao: "Essencial para avaliar gravidade e indicação de cirurgia",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Detectou sopro holosistólico em ápice",
realizado: false,
critico: true,
},
{
item: "Reconheceu irradiação para axila",
realizado: false,
critico: true,
},
{
item: "Identificou ictus amplo e deslocado",
realizado: false,
critico: true,
},
{
item: "Solicitou ecocardiograma",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de IM",
peso: 30,
descricao: "Achados clínicos e ecocardiografia",
pontuacao_maxima: 30,
},
{
criterio: "Avaliação de gravidade",
peso: 20,
descricao: "Indicação de seguimento ou cirurgia",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dispneia progressiva",
"Histórico de febre reumática",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Sopro holosistólico",
"Ictus amplo",
"IM ao ecocardiograma",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["IM crônica"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Medicações",
"Acompanhamento cardiológico",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu IM pelo sopro",
"Solicitou ecocardiograma",
"Iniciou medicações apropriadas",
],
erros_comuns: ["Confundir com estenose mitral"],
orientacoes_pedagogicas: [
"IM: sopro holosistólico ápice-axila, ictus amplo",
"EM: sopro diastólico com opening snap",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar IM pelos achados clínicos e confirmar com ecocardiograma",
comunicacao: ["explicou significado do sopro"],
anamnese: ["investigou progressão de sintomas"],
exame_fisico: ["localizou sopro corretamente"],
exames_complementares: ["solicitou ecocardiograma"],
raciocinio: ["diagnosticou IM"],
conduta: ["iniciou medicações apropriadas"],
soap: ["documentou achados de IM"],
},
temaOSCE: "Valvopatias",
subtopicosOSCE: [
"Insuficiência mitral",
"Sopro holosistólico",
"Ictus amplo",
"Ecocardiograma com regurgitação",
],
diagnosticoCorreto: "Insuficiência Mitral Crônica",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("23"),
} as CasoOSCEV2;
