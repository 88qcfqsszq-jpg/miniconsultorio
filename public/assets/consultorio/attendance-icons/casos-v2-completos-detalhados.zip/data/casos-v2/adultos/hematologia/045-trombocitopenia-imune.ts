import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso045TrombocitopeniaImune: CasoOSCEV2 = {
// ====== CASO 45: TROMBOCITOPENIA IMUNE ======
id: "45",
titulo: "Trombocitopenia Imune",
sistema: "Hematologia",
tema: "Coagulopatias",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Diagnosticar trombocitopenia imune e orientar manejo",
dados_visiveis_ao_estudante: {
nome_paciente: "Marina Silva",
idade: 29,
sexo: "Feminino",
queixa_principal: "Manchas roxas na pele e sangramento nasal",
historia_breve: "Aparecimento agudo de petéquias há 5 dias",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Púrpura Trombocitopênica Idiopática (Imune)",
diagnosticos_diferenciais: ["DIC", "Trombocitopenia medicamentosa", "Lúpus"],
sindromes_associadas: ["Trombocitopenia isolada"],
},
descricaoBreve: "Paciente com petéquias, sangramento de mucosas, plaquetas muito baixas",
categoria: "Coagulopatias",
paciente: {
id: "pac-045",
nome: "Marina Silva",
idade: 29,
sexo: "F",
queixaPrincipal: "Petéquias e sangramento",
historicoDoenca: "Aparecimento agudo há 5 dias",
antecedentes: [],
profissao: "Secretária",
estado_civil: "Solteira",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Apareceram manchas roxas no corpo todo",
petequias: "Sim, muito, começou de repente",
sangramento_nasal: "Sim, sangramento nasal espontâneo",
sangramentos_outros: "Gengivite, sangramento ao escovar",
hematomas: "Sim, roxos fácil",
menstruacao: "Muito pesada agora",
febre: "Não, sem febre",
},
respostaPaciente: {
inicial: "Petéquias e sangramento",
petequias: "Sim, difusas",
sangramento_nasal: "Sim",
sangramentos_outros: "Gengivite",
hematomas: "Fácil",
menstruacao: "Pesada",
febre: "Não",
},
sinais_vitais: {
corretos: {
pressaoArterial: "110/70 mmHg",
frequenciaCardiaca: 78,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "110/70 mmHg",
frequenciaCardiaca: 78,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 98,
},
exame_fisico: {
correto: {
inspecao: "Petéquias e equimoses difusas, sangramento gengival",
palpacao: "Sem esplenomegalia, pulsos normais",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Trombocitopenia com sangramento",
regiao: "Geral",
achados_positivos: ["Petéquias", "Equimoses", "Sangramento gengival"],
achados_negativos: ["Esplenomegalia"],
},
},
exameFisicoCorreto: {
inspecao: "Petéquias e equimoses",
palpacao: "Sem esplenomegalia",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Trombocitopenia",
},
exame_fisico_interativo: {
geral: {
coloracao: "Múltiplas petéquias",
estado_geral: "Bem, sem febre",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemograma",
descricao: "Contagem de plaquetas",
resultado: "Plaquetas 15.000/mm³",
valor_referencia: ">150.000",
interpretacao: "Trombocitopenia severa",
},
{
nome: "Teste de Coagulação",
descricao: "TP e TTPa",
resultado: "Normal",
valor_referencia: "Normal",
interpretacao: "Coagulação preservada",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Púrpura Trombocitopênica Idiopática",
probabilidade: 90,
criterios_minimos: [
"Petéquias",
"Sangramento de mucosas",
"Plaquetas <50.000",
"Coagulação normal",
"Sem esplenomegalia",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "DIC",
criterios_exclusao: ["Coagulação normal", "Sem febre"],
achados_que_descartam: ["TTPa normal"],
},
],
examesIndicados: [
"Hemograma com série branca",
"TP, TTPa, fibrinogênio",
"Teste de fragilidade capilar se indicado",
],
conduta_esperada: {
imediata: [
"Corticóide sistêmico",
"Possível imunoglobulina IV",
],
curto_prazo: [
"Monitorização de plaquetas",
"Possível esplenectomia se refratário",
],
longo_prazo: [
"Acompanhamento hematológico",
],
encaminhamentos: ["Hematologia"],
},
condutaCorreta: "Hemograma urgente, corticóide sistêmico, imunoglobulina IV, hematologia urgente",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["Plaquetas <10.000", "Sangramento"],
descricao: "Risco de hemorragia intracraniana",
recomendacao: "Internação e tratamento imediato",
},
],
erros_criticos: [
{
erro: "Prescrever AAS",
descricao: "Aumenta sangramento",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu trombocitopenia",
realizado: false,
critico: true,
},
{
item: "Solicitou hemograma urgente",
realizado: false,
critico: true,
},
{
item: "Encaminhou hematologia",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de trombocitopenia",
peso: 25,
descricao: "Achados clínicos",
pontuacao_maxima: 25,
},
{
criterio: "Urgência e encaminhamento",
peso: 25,
descricao: "Hematologia imediata",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Petéquias agudas",
"Sangramento de mucosas",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Petéquias e equimoses",
"Plaquetas muito baixas",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Púrpura trombocitopênica idiopática"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Hemograma urgente",
"Corticóide",
"Hematologia",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu trombocitopenia",
"Solicitou hemograma urgente",
"Encaminhou hematologia",
],
erros_comuns: ["Não reconhecer urgência"],
orientacoes_pedagogicas: [
"Petéquias + sangramento = trombocitopenia até prova ao contrário",
"Plaquetas <50.000 = risco de sangramento grave",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer urgência e encaminhar rapidamente",
comunicacao: ["explicou necessidade de tratamento"],
anamnese: ["investigou sangramentos"],
exame_fisico: ["detectou petéquias"],
exames_complementares: ["pediu hemograma"],
raciocinio: ["diagnosticou TPI"],
conduta: ["encaminhou hematologia"],
soap: ["documentou urgência"],
},
temaOSCE: "Coagulopatias",
subtopicosOSCE: [
"Púrpura trombocitopênica idiopática",
"Petéquias",
"Sangramento de mucosas",
"Trombocitopenia severa",
"Emergência",
],
diagnosticoCorreto: "Púrpura Trombocitopênica Idiopática",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("45"),
} as CasoOSCEV2;
