import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso012DengueGrupoA: CasoOSCEV2 = {
// ====== CASO 12: DENGUE GRUPO A ======
id: "12",
titulo: "Dengue - Grupo A",
sistema: "Infeccioso",
tema: "Arbovirose",
nivel: "iniciante",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico:
"Diagnosticar dengue clássica, orientar hidratação e monitorar sinais de alerta",
dados_visiveis_ao_estudante: {
nome_paciente: "Juliana Silva",
idade: 29,
sexo: "Feminino",
queixa_principal: "Febre alta, dor de cabeça e dor no corpo",
historia_breve: "Febre alta de início súbito há 2 dias, afebril em alguns períodos",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Dengue Grupo A (clássica)",
diagnosticos_diferenciais: [
"Dengue Grupo B",
"Zika",
"Chikungunya",
"Infecção viral inespecífica",
],
sindromes_associadas: ["Síndrome do dengue"],
},
descricaoBreve: "Paciente com febre alta bifásica, cefaleia, mialgia, sem sinais de alerta",
categoria: "Dengue",
paciente: {
id: "pac-012",
nome: "Juliana Silva",
idade: 29,
sexo: "F",
queixaPrincipal: "Febre alta, dor de cabeça e dor no corpo",
historicoDoenca: "Febre alta de início súbito há 2 dias, afebril em alguns períodos",
antecedentes: ["Sem antecedentes relevantes"],
profissao: "Enfermeira",
estado_civil: "Solteira",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Doutora, tenho febre muito alta, dói tudo no corpo.",
febre: "Febre altíssima, umas 39-40 graus, aparece e desaparece.",
cefaleia: "Dor de cabeça intensa, principalmente atrás dos olhos.",
retroorbitaria: "Isso, dói atrás dos olhos quando move para os lados.",
mialgia: "Tudo dói, músculos, as costas, as pernas, dói demais.",
artralgia: "As articulações também doem.",
exantema: "Apareceu uma manchinha avermelhada no corpo.",
apetite: "Perdi a vontade de comer.",
nausea: "Tenho umas náuseas, mas não vomitei.",
vomito: "Não, não vomitei.",
},
respostaPaciente: {
inicial: "Doutora, tenho febre muito alta, dói tudo no corpo.",
febre: "Febre altíssima, umas 39-40 graus, aparece e desaparece.",
cefaleia: "Dor de cabeça intensa, principalmente atrás dos olhos.",
retroorbitaria: "Isso, dói atrás dos olhos quando move para os lados.",
mialgia: "Tudo dói, músculos, as costas, as pernas, dói demais.",
artralgia: "As articulações também doem.",
exantema: "Apareceu uma manchinha avermelhada no corpo.",
apetite: "Perdi a vontade de comer.",
nausea: "Tenho umas náuseas, mas não vomitei.",
vomito: "Não, não vomitei.",
},
sinais_vitais: {
corretos: {
pressaoArterial: "115/75 mmHg",
frequenciaCardiaca: 95,
frequenciaRespiratoria: 18,
temperatura: 39.8,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "115/75 mmHg",
frequenciaCardiaca: 95,
frequenciaRespiratoria: 18,
temperatura: 39.8,
saturacaoOxigenio: 98,
glicemia: 110,
},
exame_fisico: {
correto: {
inspecao: "Paciente febril, exantema maculopapular em tronco e membros",
palpacao: "Sem hepatomegalia, sem edema",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Fase febril clássica de dengue sem complicações",
regiao: "Pele e órgãos abdominais",
achados_positivos: ["Febre", "Exantema maculopapular"],
achados_negativos: ["Hepatomegalia", "Sangramento"],
},
},
exameFisicoCorreto: {
inspecao: "Paciente febril, exantema maculopapular",
palpacao: "Sem hepatomegalia",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Fase febril clássica",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Paciente em regular estado geral, febril, com exantema.",
coloracao: "Exantema maculopapular presente em tronco e membros.",
},
abdominal: {
inspecao: "Abdome normal.",
palpacao_superficial: "Sem visceromegalias, sem dor à palpação.",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemograma Completo",
descricao: "Série de glóbulos",
resultado: "Plaquetas 150.000/mm³, leucócitos 3.500/mm³",
valor_referencia: "Plaquetas >150.000/mm³, leucócitos 4.500-11.000/mm³",
interpretacao: "Discreta leucopenia e trombocitopenia",
},
{
nome: "Sorologia para Dengue (IgM)",
descricao: "ELISA",
resultado: "Positiva (IgM positivo)",
valor_referencia: "Negativa",
interpretacao: "Dengue aguda",
},
{
nome: "NS1 Antígeno",
descricao: "Antígeno não-estrutural",
resultado: "Positivo",
valor_referencia: "Negativo",
interpretacao: "Infecção aguda",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Dengue Grupo A (Clássica)",
probabilidade: 90,
criterios_minimos: [
"Febre alta bifásica",
"Cefaleia intensa",
"Dor retroorbitária",
"Mialgia intensa",
"Exantema",
"Soropositividade (IgM ou NS1 positivo)",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Zika ou Chikungunya",
criterios_exclusao: ["Padrão de sintomas típico de dengue clássica"],
achados_que_descartam: ["Dor retroorbitária típica"],
},
],
examesIndicados: [
"Hemograma",
"IgM para dengue",
"NS1 antígeno",
"Testes de coagulação se necessário",
],
conduta_esperada: {
imediata: [
"Hidratação oral abundante (água, soro fisiológico, sucos)",
"Repouso relativo",
"Paracetamol ou Dipirona para febre",
],
curto_prazo: [
"Evitar AINEs (risco de hemorragia)",
"Monitorização de sinais de alerta",
"Hemograma seriado se piora",
],
longo_prazo: ["Seguimento até resolução", "Investigação se dengue hemorrágica"],
encaminhamentos: ["Infectologia se sinais de alerta"],
},
condutaCorreta:
"Hidratação oral abundante, paracetamol/dipirona, evitar AINEs, monitorização de sinais de alerta",
criterios_de_gravidade: [
{
severidade: "leve",
sinais: ["Sem sangramento", "PA normal", "Sem vômitos"],
descricao: "Dengue clássica sem complicações",
recomendacao: "Hidratação oral, analgésicos, follow-up ambulatorial",
},
],
erros_criticos: [
{
erro: "Prescrever AINEs (Ibuprofeno, Diclofenaco)",
descricao: "AINEs aumentam risco de sangramento em dengue",
penalidade: 2,
evitavel: true,
},
{
erro: "Não orientar hidratação adequada",
descricao: "Desidratação é fator de risco para piora",
penalidade: 1.5,
evitavel: true,
},
],
checklist_osce: [
{ item: "Investigou febre, cefaleia, mialgia", realizado: false, critico: true },
{ item: "Perguntou sobre dor retroorbitária", realizado: false, critico: true },
{ item: "Mediu sinais vitais", realizado: false, critico: true },
{ item: "Investigou sinais de alerta", realizado: false, critico: true },
{ item: "Solicitou hemograma", realizado: false, critico: true },
{ item: "Solicitou sorologia (IgM)", realizado: false, critico: true },
{ item: "Orientou hidratação e evitar AINEs", realizado: false, critico: true },
],
rubrica_correcao: [
{
criterio: "Diagnóstico Clínico",
peso: 20,
descricao: "Reconhecimento de sintomas clássicos",
pontuacao_maxima: 20,
},
{
criterio: "Avaliação de Sinais de Alerta",
peso: 20,
descricao: "Identificação de gravidade",
pontuacao_maxima: 20,
},
{
criterio: "Orientação Terapêutica",
peso: 30,
descricao: "Hidratação, analgésicos apropriados",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Febre alta bifásica",
"Cefaleia intensa e dor retroorbitária",
"Mialgia e artralgia",
"Náuseas",
"Exantema",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Febre alta (39-40°C)",
"Exantema maculopapular",
"Hemograma: leucopenia e trombocitopenia",
"Sorologia IgM positiva",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Dengue Grupo A (clássica)", "Sem sinais de alerta"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Hidratação oral",
"Paracetamol",
"Evitar AINEs",
"Monitorização de sinais de alerta",
"Hemograma seriado se necessário",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Investigou padrão clínico de dengue",
"Solicitou hemograma e sorologia",
"Orientou hidratação",
"Não prescreveu AINEs",
"Monitorização de sinais de alerta",
],
erros_comuns: [
"Prescrever AINE",
"Falta de orientação de hidratação",
"Não investigar sinais de alerta",
],
orientacoes_pedagogicas: [
"Dengue clássica: febre bifásica, cefaleia, dor retroorbitária, mialgia",
"Exantema é comum",
"NUNCA prescreva AINE",
"Hidratação oral é pilar do tratamento",
"IgM positivo do 5º dia em diante",
],
},
temaOSCE: "Conteúdos transversais",
subtopicosOSCE: [
"Dengue - arbovirose",
"Sintomas sistêmicos (febre, mialgia)",
"Trombocitopenia",
"Manejo de febre",
"Suspeita de síndrome hemorrágica"
],
diagnosticoCorreto: "Dengue Grupo A",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("12"),
} as CasoOSCEV2;
