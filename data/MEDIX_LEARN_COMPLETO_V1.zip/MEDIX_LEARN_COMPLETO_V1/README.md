# MEDIX Learn Completo — Arquitetura Curricular v1.0

Este pacote organiza o **MEDIX Learn** como o módulo de aprendizagem ativa da plataforma MEDIX.

A divisão aprovada do produto é:

1. **MEDIX Learn** — aprender base, semiologia e raciocínio clínico.
2. **MEDIX OSCE Ciclo Básico** — treinar atendimento e prova prática.
3. **MEDIX OSCE Clínico** — treinar evolução clínica, conduta sequencial e simulação fisiológica avançada com Pulse por baixo.

## Regra pedagógica central

> O MEDIX Learn não é uma biblioteca de PDFs.  
> Ele é uma trilha ativa para transformar fisiologia em raciocínio clínico.

Cada trilha deve seguir o mesmo arco:

```text
conceito → mecanismo → achado clínico → diferenciação → mini-caso → pergunta ativa → mapa final → OSCE
```

## Organização deste ZIP

```text
00_MATRIZ_COMPLETA_MEDIX_LEARN.md
01_RESPIRATORIO/
02_CARDIOVASCULAR/
03_INFECTOLOGIA/
04_NEUROLOGIA/
05_GASTRO_ABDOME/
06_SEMIOLOGIA_GERAL/
07_RACIOCINIO_CLINICO/
99_REFERENCIAS_E_CRITERIOS.md
```

O módulo mais detalhado neste v1.0 é **Respiratório**, com a trilha **Hipoxemia** como modelo de profundidade. As demais trilhas já estão organizadas com objetivos, blocos, mini-casos, perguntas e ponte para OSCE, para o agente implementar sem inventar a estrutura pedagógica.

## Como usar

1. A usuária faz curadoria médica do conteúdo.
2. O agente implementa as rotas e componentes apenas a partir destes documentos.
3. Novas trilhas só entram quando aprovadas.
4. O MEDIX Learn deve sempre conectar teoria → semiologia → raciocínio → OSCE.
