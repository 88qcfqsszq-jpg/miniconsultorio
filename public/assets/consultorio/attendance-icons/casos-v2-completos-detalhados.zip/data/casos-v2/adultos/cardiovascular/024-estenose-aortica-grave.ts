import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso024EstenoseAorticaGrave: CasoOSCEV2 = {
// ====== CASO 24: ESTENOSE AÓRTICA ======
id: "24",
titulo: "Estenose Aórtica Grave",
sistema: "Cardiovascular",
tema: "Valvopatia",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Diagnosticar estenose aórtica grave e reconhecer indicação de cirurgia",
dados_visiveis_ao_estudante: {
nome_paciente: "Armando Silva",
idade: 72,
sexo: "Masculino",
queixa_principal: "Síncope e falta de ar ao exercício",
historia_breve: "Episódios de tontura ao fazer esforço, não consegue mais caminhar muito",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Estenose Aórtica Grave",
diagnosticos_diferenciais: ["Insuficiência Aórtica", "Cardiomiopatia"],
sindromes_associadas: ["Tríade de Heyde"],
},
descricaoBreve: "Paciente com sopro sistólico em foco aórtico, pulso parvus et tardus, área diminuída ao ecocardiograma",
categoria: "Valvopatia",
paciente: {
id: "pac-024",
nome: "Armando Silva",
idade: 72,
sexo: "M",
queixaPrincipal: "Síncope ao exercício",
historicoDoenca: "Sopro desde a infância, agora com sintomas",
antecedentes: ["HAS", "Diabetes tipo 2"],
profissao: "Aposentado",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: ["Losartana 50mg", "Metformina 500mg"],
},
respostas_do_paciente: {
inicial: "Quando faço esforço, fico tonto e tenho medo de desmaiar",
sincope: "Sim, já desmaiei duas vezes ao fazer esforço",
dispneia: "Muita, mal consigo andar 20 metros",
angina: "Sim, dor no peito ao fazer esforço",
piora: "Piorou bastante nos últimos 6 meses",
historico: "Sempre tive um sopro, desde criança",
},
respostaPaciente: {
inicial: "Fico tonto com esforço",
sincope: "Sim",
dispneia: "Muita",
angina: "Sim",
piora: "Piorou",
historico: "Sopro desde criança",
},
sinais_vitais: {
corretos: {
pressaoArterial: "160/50 mmHg",
frequenciaCardiaca: 68,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 96,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "160/50 mmHg",
frequenciaCardiaca: 68,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 96,
},
exame_fisico: {
correto: {
inspecao: "Pulso carotídeo lento e de pequena amplitude",
palpacao: "Frêmito sistólico em foco aórtico",
ausculta: "Sopro sistólico ejetivo longo em foco aórtico irradiado para carótidas",
percussao: "Normal",
observacoes: "Pulso parvus et tardus típico",
regiao: "Precórdio",
achados_positivos: ["Sopro sistólico ejetivo"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Pulso lento e fraco (parvus et tardus)",
palpacao: "Frêmito sistólico",
ausculta: "Sopro sistólico ejetivo em aórtica",
percussao: "Normal",
observacoes: "Achados típicos de EA",
},
exame_fisico_interativo: {
cardiovascular: {
inspecao_precordial: "Pulsos carotídeos com ascensão lenta",
ausculta_cardiaca: "Sopro sistólico ejetivo longo, máximo em foco aórtico, irradiado para carótidas",
pulsos: "Pulso carotídeo com ascensão lenta e suave (parvus et tardus)",
turgencia_jugular: "Normal",
edema: "Ausente",
},
},
exames_complementares_disponiveis: [
{
nome: "Ecocardiograma",
descricao: "Avaliação de válvula aórtica",
resultado: "Área de válvula aórtica <0.8 cm², gradiente médio >50 mmHg",
valor_referencia: "EA normal >1.5 cm²",
interpretacao: "Estenose aórtica grave",
},
{
nome: "Radiografia de Tórax",
descricao: "PA e perfil",
resultado: "Possível calcificação de aorta",
valor_referencia: "Normal",
interpretacao: "Degeneração aórtica",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Estenose Aórtica Grave",
probabilidade: 95,
criterios_minimos: [
"Sopro sistólico ejetivo",
"Pulso parvus et tardus",
"Tríade: síncope, dispneia, angina",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Estenose Mitral",
criterios_exclusao: ["Sopro sistólico"],
achados_que_descartam: ["Pulso normal"],
},
],
examesIndicados: [
"Ecocardiograma",
"Radiografia de tórax",
"ECG",
"Avaliação para cirurgia",
],
conduta_esperada: {
imediata: [
"Não fazer esforço físico intenso",
"Encaminhamento para cirurgia valvular",
],
curto_prazo: [
"Avaliação pré-operatória",
"Substituição de válvula aórtica",
],
longo_prazo: ["Seguimento cardiológico pós-operatório"],
encaminhamentos: ["Cardiologia", "Cirurgia cardíaca"],
},
condutaCorreta: "Encaminhar para substituição de válvula aórtica urgentemente, evitar esforço físico intenso",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["Síncope", "Dispneia", "Angina"],
descricao: "Alto risco de morte súbita",
recomendacao: "Cirurgia urgente",
},
],
erros_criticos: [
{
erro: "Não reconhecer risco de morte súbita",
descricao: "EA grave pode causar morte súbita com exercício",
penalidade: 3,
evitavel: true,
},
{
erro: "Não encaminhar para cirurgia",
descricao: "Substituição aórtica é tratamento definitivo",
penalidade: 3,
evitavel: true,
},
],
checklist_osce: [
{
item: "Detectou sopro sistólico em aórtica",
realizado: false,
critico: true,
},
{
item: "Reconheceu pulso parvus et tardus",
realizado: false,
critico: true,
},
{
item: "Solicitou ecocardiograma",
realizado: false,
critico: true,
},
{
item: "Encaminhou para cirurgia",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de EA grave",
peso: 35,
descricao: "Achados clínicos e ecocardiografia",
pontuacao_maxima: 35,
},
{
criterio: "Reconhecimento de urgência",
peso: 25,
descricao: "Indicação de cirurgia imediata",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Síncope ao esforço",
"Dispneia",
"Angina",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Sopro sistólico aórtico",
"Pulso parvus et tardus",
"EA grave no eco",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Estenose aórtica grave"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Encaminhar cirurgião",
"Evitar esforço",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu EA grave",
"Detectou pulso parvus et tardus",
"Encaminhou para cirurgia",
],
erros_comuns: ["Achar que é angina coronária"],
orientacoes_pedagogicas: [
"EA grave: tríade = síncope + dispneia + angina ao esforço",
"Pulso parvus et tardus é caracterísitco",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer EA grave e indicar cirurgia urgente",
comunicacao: ["explicou a gravidade"],
anamnese: ["investigou síncope e exercício"],
exame_fisico: ["detectou pulso e sopro"],
exames_complementares: ["solicitou ecocardiograma"],
raciocinio: ["diagnosticou EA grave"],
conduta: ["encaminhou para cirurgia"],
soap: ["documentou EA grave"],
},
temaOSCE: "Valvopatias",
subtopicosOSCE: [
"Estenose aórtica",
"Sopro sistólico ejetivo",
"Pulso parvus et tardus",
"Ecocardiograma com área diminuída",
],
diagnosticoCorreto: "Estenose Aórtica Grave",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("24"),
} as CasoOSCEV2;
