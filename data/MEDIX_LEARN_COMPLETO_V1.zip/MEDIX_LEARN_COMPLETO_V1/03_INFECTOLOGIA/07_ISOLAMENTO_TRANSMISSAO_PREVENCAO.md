# Trilha — Isolamento, transmissão e prevenção

## Objetivo pedagógico
Ligar via de transmissão, EPI, isolamento e prevenção.

## Como essa trilha deve ensinar

A trilha deve seguir o arco:

```text
conceito → mecanismo → semiologia → raciocínio → mini-caso → pergunta ativa → erro comum → OSCE
```

## Blocos obrigatórios

1. **Microaula** — explicar o conceito central em poucas telas.
2. **Fisiologia aplicada** — mostrar o mecanismo por trás do sinal/sintoma.
3. **Semiologia** — transformar mecanismo em achado de paciente.
4. **Raciocínio clínico** — diferenciar causas comuns e causas perigosas.
5. **Mini-casos** — aplicar em cenários curtos.
6. **Questões ativas** — obrigar o aluno a justificar.
7. **Erros comuns** — corrigir atalhos mentais.
8. **Mapa final** — síntese.
9. **Ponte para OSCE** — indicar casos para treinar.

## Mini-casos sugeridos
- TB
- Influenza
- COVID
- Meningite

## Perguntas ativas-padrão

- Qual é o problema principal deste paciente?
- Qual dado muda a gravidade?
- Qual hipótese comum explica o quadro?
- Qual hipótese perigosa não pode ser esquecida?
- O que eu faria primeiro e por quê?
- Que achado do exame físico confirmaria ou enfraqueceria minha hipótese?

## Erros comuns a evitar

- Decorar diagnóstico sem mecanismo.
- Tratar número isolado sem olhar o paciente.
- Ignorar sinais de gravidade.
- Não reavaliar após intervenção.
- Confundir hipótese provável com hipótese mais perigosa.

## Ponte para OSCE

Ao final desta trilha, o aluno deve ser direcionado para um caso OSCE correspondente quando existir, iniciando pelo **MEDIX OSCE Ciclo Básico** e, quando houver evolução fisiológica, para o **MEDIX OSCE Clínico**.
