import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso039DengueComSinaisDeAlarme: CasoOSCEV2 = {
// ====== CASO 39: DENGUE COM SINAIS DE ALARME ======
id: "39",
titulo: "Dengue com Sinais de Alarme",
sistema: "Infectologia",
tema: "Arboviroses",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Reconhecer sinais de alarme em dengue e encaminhar para hospital",
dados_visiveis_ao_estudante: {
nome_paciente: "Carlos Mendes",
idade: 28,
sexo: "Masculino",
queixa_principal: "Febre que baixou, agora vômito e dor abdominal",
historia_breve: "Dengue confirmada há 3 dias, evoluindo com piora na fase crítica",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Dengue com Sinais de Alarme",
diagnosticos_diferenciais: ["Dengue hemorrágica", "Sindrome de choque dengue"],
sindromes_associadas: ["Fase crítica da dengue"],
},
descricaoBreve: "Paciente em fase crítica com vômito, dor abdominal, queda de plaquetas e hemoconcentração",
categoria: "Arboviroses",
paciente: {
id: "pac-039",
nome: "Carlos Mendes",
idade: 28,
sexo: "M",
queixaPrincipal: "Vômito e dor abdominal",
historicoDoenca: "Dengue confirmada 3 dias atrás",
antecedentes: ["Dengue confirmada"],
profissao: "Motorista",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "A febre baixou mas agora piorou, tô vomitando muito",
febre: "Febre baixou mas voltar a passar mal",
vomito: "Sim, vômito persistente, já vomitei 5 vezes",
dor_abdominal: "Dor forte no abdome, principalmente em cima",
sangramento: "Vejo umas manchinhas avermelhadas, tipo roxo",
fadiga: "Muito fraco, mal consigo sair do sofá",
frequencia_urinaria: "Urina muito pouca",
},
respostaPaciente: {
inicial: "Vômito e dor abdominal",
febre: "Baixou",
vomito: "Sim, persistente",
dor_abdominal: "Sim, intensa",
sangramento: "Manchinhas roxas",
fadiga: "Muita",
frequencia_urinaria: "Pouca",
},
sinais_vitais: {
corretos: {
pressaoArterial: "100/65 mmHg",
frequenciaCardiaca: 110,
frequenciaRespiratoria: 18,
temperatura: 37.2,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "100/65 mmHg",
frequenciaCardiaca: 110,
frequenciaRespiratoria: 18,
temperatura: 37.2,
saturacaoOxigenio: 98,
},
exame_fisico: {
correto: {
inspecao: "Paciente pálido, petéquias, equimoses, hepatomegalia",
palpacao: "Abdome doloroso difuso, sem rigidez, fígado palpável a 3cm",
ausculta: "Normal",
percussao: "Ausência de macicez em flancos",
observacoes: "Sinais de sangramento e hepatomegalia acentuada",
regiao: "Geral",
achados_positivos: ["Petéquias", "Equimoses", "Hepatomegalia"],
achados_negativos: ["Rigidez abdominal"],
},
},
exameFisicoCorreto: {
inspecao: "Petéquias, equimoses, pálido",
palpacao: "Hepatomegalia 3cm, abdome doloroso",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Sinais de alarme presentes",
},
exame_fisico_interativo: {
geral: {
coloracao: "Pálido com petéquias em MMII e equimoses em braço direito",
},
abdominal: {
dor_palpacao: "Dor difusa",
visceromegalias: "Hepatomegalia grau III",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemograma",
descricao: "Contagem de células",
resultado: "Hb 16, Ht 48%, Leucócitos 4.200, Plaquetas 75.000",
valor_referencia: "Plaquetas >150.000",
interpretacao: "Trombocitopenia com hemoconcentração",
},
{
nome: "Hematócrito",
descricao: "Mudança no hematócrito",
resultado: "Aumento de 20% em relação ao basal",
valor_referencia: "Variação <20%",
interpretacao: "Hemoconcentração = extravasamento",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Dengue com Sinais de Alarme",
probabilidade: 95,
criterios_minimos: [
"Vômito persistente",
"Dor abdominal grave",
"Trombocitopenia",
"Hemoconcentração",
"Petéquias",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Apendicite aguda",
criterios_exclusao: ["História de dengue", "Trombocitopenia"],
achados_que_descartam: ["Plaquetas baixas"],
},
],
examesIndicados: [
"Hemograma com série branca",
"Hematócrito seriado",
"Testes de coagulação",
"Ultrassom abdominal se disponível",
],
conduta_esperada: {
imediata: [
"Encaminhar para hospital URGENTEMENTE",
"Internação",
"Repouso absoluto",
],
curto_prazo: [
"Monitorização contínua",
"Soroterapia se necessário",
"Observação de sangramentos",
],
longo_prazo: [
"Monitorização de complicações",
],
encaminhamentos: ["Emergência hospitalar"],
},
condutaCorreta: "Internação urgente, monitorização contínua, soroterapia conforme necessário, observação de sangramento",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: [
"Vômito persistente",
"Dor abdominal",
"Trombocitopenia",
"Hemoconcentração",
],
descricao: "Dengue em fase crítica com risco de choque",
recomendacao: "Internação e monitorização constante",
},
],
erros_criticos: [
{
erro: "Não encaminhar para hospital",
descricao: "Risco de progressão para choque",
penalidade: 3,
evitavel: true,
},
{
erro: "Prescrever AINE",
descricao: "Aumenta risco de sangramento",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu sinais de alarme",
realizado: false,
critico: true,
},
{
item: "Solicitou hemograma urgente",
realizado: false,
critico: true,
},
{
item: "Encaminhou para hospital",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de sinais de alarme",
peso: 30,
descricao: "Risco de choque",
pontuacao_maxima: 30,
},
{
criterio: "Decisão de encaminhar",
peso: 25,
descricao: "Necessidade de internação",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Vômito persistente",
"Dor abdominal",
"Poliúria",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Petéquias",
"Hepatomegalia",
"Trombocitopenia",
"Hemoconcentração",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Dengue com sinais de alarme",
"Risco de choque",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Internação imediata",
"Monitorização",
"Soroterapia conforme necessário",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu sinais de alarme",
"Solicitou hemograma urgente",
"Encaminhou para hospital",
],
erros_comuns: ["Achar que é de baixo risco"],
orientacoes_pedagogicas: [
"Sinais de alarme dengue: vômito persistente, dor abdominal, sangramento, trombocitopenia",
"Sempre encaminhar para hospital na fase crítica",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer gravidade e encaminhar rapidamente",
comunicacao: ["explicou necessidade de internação"],
anamnese: ["investigou sinais de alarme"],
exame_fisico: ["detectou petéquias e hepatomegalia"],
exames_complementares: ["pediu hemograma urgente"],
raciocinio: ["diagnosticou sinais de alarme"],
conduta: ["encaminhou para hospital"],
soap: ["documentou urgência"],
},
temaOSCE: "Arboviroses",
subtopicosOSCE: [
"Dengue com sinais de alarme",
"Fase crítica",
"Trombocitopenia",
"Hemoconcentração",
"Emergência",
],
diagnosticoCorreto: "Dengue com Sinais de Alarme",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("39"),
} as CasoOSCEV2;
