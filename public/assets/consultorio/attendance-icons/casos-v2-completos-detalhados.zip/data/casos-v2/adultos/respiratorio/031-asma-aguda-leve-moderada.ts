import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso031AsmaAgudaLeveModerada: CasoOSCEV2 = {
// ====== CASO 31: ASMA AGUDA LEVE-MODERADA ======
id: "31",
titulo: "Asma Aguda Leve-Moderada",
sistema: "Respiratório",
tema: "Dispneia Aguda",
nivel: "iniciante",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Diagnosticar crise asmática leve-moderada e estabelecer tratamento broncodilatador",
dados_visiveis_ao_estudante: {
nome_paciente: "João Silva",
idade: 28,
sexo: "Masculino",
queixa_principal: "Falta de ar e chiado no peito",
historia_breve: "Asma desde infância, controlada com inalador, agora com crise após exposição a ácaros",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Asma Aguda Leve-Moderada",
diagnosticos_diferenciais: ["DPOC", "Anafilaxia", "Embolia Pulmonar"],
sindromes_associadas: ["Obstrução Reversível de Vias Aéreas"],
},
descricaoBreve: "Paciente com dispneia, chiado no peito, ausculta com sibilância bilateral",
categoria: "Asma",
paciente: {
id: "pac-031",
nome: "João Silva",
idade: 28,
sexo: "M",
queixaPrincipal: "Falta de ar e chiado",
historicoDoenca: "Asma desde infância, bem controlada",
antecedentes: ["Asma", "Alergias"],
profissao: "Analista de sistemas",
estado_civil: "Solteiro",
alergias: ["Ácaros", "Pólen"],
medicamentos_em_uso: ["Salbutamol PRN"],
},
respostas_do_paciente: {
inicial: "Tô com muita falta de ar e chiado no peito",
chiado: "Sim, fazendo aquele barulho chato",
tosse: "Sim, tosse seca",
aperto: "Sim, aperto no peito",
inicio: "Começou de repente há 2 horas",
gatilho: "Limpei a casa e tive contato com poeira",
inalador: "Usei o inalador mas não melhorou muito",
},
respostaPaciente: {
inicial: "Falta de ar e chiado",
chiado: "Sim",
tosse: "Sim",
aperto: "Sim",
inicio: "2 horas",
gatilho: "Poeira",
inalador: "Usei mas melhorou pouco",
},
sinais_vitais: {
corretos: {
pressaoArterial: "130/80 mmHg",
frequenciaCardiaca: 100,
frequenciaRespiratoria: 22,
temperatura: 36.8,
saturacaoOxigenio: 94,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "130/80 mmHg",
frequenciaCardiaca: 100,
frequenciaRespiratoria: 22,
temperatura: 36.8,
saturacaoOxigenio: 94,
},
exame_fisico: {
correto: {
inspecao: "Taquipneia leve, uso de musculatura acessória discreto",
palpacao: "Expansão simétrica",
ausculta: "Sibilância bilateral difusa, predomínio expiratório",
percussao: "Normal",
observacoes: "Compatível com broncoespasmo",
regiao: "Pulmões",
achados_positivos: ["Sibilância", "Taquipneia"],
achados_negativos: ["Crepitações"],
},
},
exameFisicoCorreto: {
inspecao: "Taquipneia",
palpacao: "Expansão normal",
ausculta: "Sibilância bilateral",
percussao: "Normal",
observacoes: "Asma aguda",
},
exame_fisico_interativo: {
respiratorio: {
inspecao_torax: "Taquipneia 22 ipm, expansão simétrica",
padrao_respiratorio: "Regular",
expansibilidade: "Simétrica",
ausculta_pulmonar: "Sibilância bilateral difusa, predominantemente expiratória",
musculatura_acessoria: "Uso discreto",
},
},
exames_complementares_disponiveis: [
{
nome: "Oximetria de Pulso",
descricao: "Saturação de oxigênio",
resultado: "94%",
valor_referencia: ">95%",
interpretacao: "Hipoxemia leve",
},
{
nome: "Pico de Fluxo",
descricao: "Peak flow",
resultado: "70% do predito",
valor_referencia: ">80%",
interpretacao: "Redução moderada",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Asma Aguda Leve-Moderada",
probabilidade: 95,
criterios_minimos: [
"Dispneia",
"Chiado",
"Sibilância bilateral",
"Resposta a broncodilatador",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "DPOC",
criterios_exclusao: ["Juventude", "História de asma"],
achados_que_descartam: ["Histórico de asma infantil"],
},
],
examesIndicados: [
"Oximetria",
"Peak flow",
"RX tórax se suspeita de pneumotórax",
],
conduta_esperada: {
imediata: [
"Beta-agonista inalado",
"Oxigenioterapia para manter SpO2 >90%",
"Corticóide sistêmico",
],
curto_prazo: [
"Monitorização",
"Resposta ao tratamento",
],
longo_prazo: [
"Controle de gatilhos",
"Plano de ação escrito",
],
encaminhamentos: ["Pneumologia"],
},
condutaCorreta: "Beta-agonista inalado, corticóide sistêmico, oxigenioterapia, monitorização",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["FR >20", "SpO2 94%", "Sibilância bilateral"],
descricao: "Asma leve-moderada",
recomendacao: "Tratamento ambulatorial com seguimento",
},
],
erros_criticos: [
{
erro: "Não prescrever corticóide",
descricao: "Essencial no tratamento de asma aguda",
penalidade: 2,
evitavel: true,
},
{
erro: "Não monitorizar oxigenação",
descricao: "Necessário para avaliar resposta",
penalidade: 1.5,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu crise asmática",
realizado: false,
critico: true,
},
{
item: "Avaliou gravidade",
realizado: false,
critico: true,
},
{
item: "Prescreveu beta-agonista",
realizado: false,
critico: true,
},
{
item: "Prescreveu corticóide",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de asma",
peso: 25,
descricao: "Diferenciação",
pontuacao_maxima: 25,
},
{
criterio: "Tratamento",
peso: 25,
descricao: "Beta-agonista e corticóide",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dispneia aguda",
"Chiado",
"Gatilho",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Taquipneia",
"Sibilância bilateral",
"SpO2 reduzida",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Asma aguda leve-moderada"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Beta-agonista",
"Corticóide",
"Monitorização",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu asma",
"Prescreveu beta-agonista",
"Prescreveu corticóide",
"Monitorizou",
],
erros_comuns: ["Só prescrever beta-agonista"],
orientacoes_pedagogicas: [
"Asma aguda = beta-agonista + corticóide sempre",
"Classificar como leve/moderada/grave para guiar manejo",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar asma e prescrever tratamento adequado",
comunicacao: ["explicou plano de tratamento"],
anamnese: ["investigou gatilhos"],
exame_fisico: ["detectou sibilância"],
exames_complementares: ["avaliou SpO2"],
raciocinio: ["diagnosticou asma"],
conduta: ["prescreveu medicações"],
soap: ["documentou crise"],
},
temaOSCE: "Asma",
subtopicosOSCE: [
"Asma aguda",
"Sibilância bilateral",
"Beta-agonista",
"Corticóide sistêmico",
],
diagnosticoCorreto: "Asma Aguda Leve-Moderada",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("31"),
} as CasoOSCEV2;
