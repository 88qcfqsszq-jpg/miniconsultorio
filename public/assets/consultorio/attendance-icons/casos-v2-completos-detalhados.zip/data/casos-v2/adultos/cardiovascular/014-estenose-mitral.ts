import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso014EstenoseMitral: CasoOSCEV2 = {
// ====== CASO 14: ESTENOSE MITRAL ======
id: "14",
titulo: "Estenose Mitral",
sistema: "Cardiovascular",
tema: "Valvulopatia",
nivel: "intermediario",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Diagnosticar estenose mitral pelos achados clássicos e ecocardiograma",
dados_visiveis_ao_estudante: {
nome_paciente: "Beatriz Oliveira",
idade: 52,
sexo: "Feminino",
queixa_principal: "Falta de ar ao fazer esforço",
historia_breve: "Dispneia ao esforço progressiva, história de febre reumática na infância",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Estenose Mitral Moderada",
diagnosticos_diferenciais: [
"Insuficiência Mitral",
"Insuficiência Cardíaca",
"Asma",
"DPOC",
],
sindromes_associadas: ["Síndrome reumática"],
},
descricaoBreve: "Paciente com dispneia ao esforço, sopro diastólico em ruflar, ritmo irregular",
categoria: "Valvulopatia",
paciente: {
id: "pac-014",
nome: "Beatriz Oliveira",
idade: 52,
sexo: "F",
queixaPrincipal: "Falta de ar ao fazer esforço",
historicoDoenca:
"Dispneia ao esforço progressiva, história de febre reumática na infância",
antecedentes: ["Febre reumática aos 12 anos"],
profissao: "Dona de casa",
estado_civil: "Casada",
alergias: [],
medicamentos_em_uso: ["Losartana 50mg"],
},
respostas_do_paciente: {
inicial: "Doutora, fico muito cansada quando caminho rápido.",
esforco: "Não consigo nem subir escada, fico muito sem ar.",
noite: "Às vezes acordo à noite sem conseguir respirar.",
tosse: "Tenho uma tosse que piora com esforço.",
palpitacao: "Às vezes bate acelerado, às vezes irregular.",
infancia: "Tive febre reumática quando era criança, fui internada.",
inchaço: "Meus pés incham ao final do dia.",
dor_peito: "Às vezes sinto um incômodo no peito.",
},
respostaPaciente: {
inicial: "Doutora, fico muito cansada quando caminho rápido.",
esforco: "Não consigo nem subir escada, fico muito sem ar.",
noite: "Às vezes acordo à noite sem conseguir respirar.",
tosse: "Tenho uma tosse que piora com esforço.",
palpitacao: "Às vezes bate acelerado, às vezes irregular.",
infancia: "Tive febre reumática quando era criança, fui internada.",
inchaço: "Meus pés incham ao final do dia.",
dor_peito: "Às vezes sinto um incômodo no peito.",
},
sinais_vitais: {
corretos: {
pressaoArterial: "130/85 mmHg",
frequenciaCardiaca: 92,
frequenciaRespiratoria: 20,
temperatura: 36.8,
saturacaoOxigenio: 97,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "130/85 mmHg",
frequenciaCardiaca: 92,
frequenciaRespiratoria: 20,
temperatura: 36.8,
saturacaoOxigenio: 97,
glicemia: 135,
},
exame_fisico: {
correto: {
inspecao: "Paciente normocolorada, sem cianose no repouso",
palpacao: "Ictus cordis não desviado, possível frêmito diastólico",
ausculta:
"Sopro diastólico em ruflar em foco mitral (ápex), possível estalido de abertura, desdobramento de S2",
percussao: "Normal",
observacoes:
"Achados clássicos de EM: sopro diastólico em ruflar, desdobramento de S2",
regiao: "Precórdio",
achados_positivos: [
"Sopro diastólico em ruflar",
"Desdobramento de S2",
"Possível frêmito",
],
achados_negativos: ["Sopro sistólico de regurgitação"],
},
},
exameFisicoCorreto: {
inspecao: "Paciente normocolorada",
palpacao: "Ictus não desviado",
ausculta: "Sopro diastólico em ruflar, desdobramento de S2",
percussao: "Normal",
observacoes: "Achados clássicos de estenose mitral",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Paciente em bom estado geral, normocolorada.",
},
cardiovascular: {
inspecao_precordial: "Sem abaulamentos visíveis.",
ictus: "Ictus cordis não visível, não palpável.",
ausculta_cardiaca: "Sopro diastólico em ruflar em ápex (foco mitral), desdobramento de S2.",
pulsos: "Pulsos presentes e simétricos, amplos e rítmicos.",
},
},
exames_complementares_disponiveis: [
{
nome: "ECG",
descricao: "12 derivações",
resultado: "Ondas P bifásicas em D2 (P mitrale), possível fibrilação atrial",
valor_referencia: "Normal",
interpretacao: "Sobrecarga atrial esquerda",
},
{
nome: "Radiografia de Tórax PA e Perfil",
descricao: "Avaliação cardiopulmonar",
resultado: "Silhueta cardíaca com configuração mitral (convexidade esquerda), possível congestão pulmonar",
valor_referencia: "Normal",
interpretacao: "Cardiomegalia",
},
{
nome: "Ecocardiograma",
descricao: "Ultrassom cardíaco",
resultado: "Valva mitral espessada, gradiente transvalvar 8 mmHg, área valvar 1.5-2.0 cm²",
valor_referencia: "Área valvar >2.5 cm², gradiente <5 mmHg",
interpretacao: "Estenose mitral moderada",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Estenose Mitral",
probabilidade: 90,
criterios_minimos: [
"Dispneia ao esforço",
"Sopro diastólico em ruflar",
"Desdobramento de S2",
"Ecocardiograma com área <2.5 cm²",
"Antecedente de febre reumática",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Insuficiência Mitral",
criterios_exclusao: ["Sopro sistólico"],
achados_que_descartam: ["Sopro diastólico, não sistólico"],
},
],
examesIndicados: [
"ECG",
"Radiografia de tórax",
"Ecocardiograma",
"Teste ergométrico se necessário",
],
conduta_esperada: {
imediata: [
"Diurético se congestão",
"Restrição de sal e líquido",
"Betabloqueador para controlar FC",
],
curto_prazo: [
"Ecocardiograma de seguimento",
"Profilaxia de endocardite",
"Avaliar necessidade de valvotomia",
],
longo_prazo: [
"Cirurgia de comissurotomia ou troca valvar se indicado",
"Seguimento cardiológico",
],
encaminhamentos: ["Cardiologia cirúrgica para avaliação"],
},
condutaCorreta:
"Diurético se congestão, betabloqueador, ecocardiograma, profilaxia de endocardite, considerar cirurgia",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["Dispneia ao esforço", "Área 1.5-2.0 cm²"],
descricao: "Estenose mitral moderada",
recomendacao: "Diurético, betabloqueador, seguimento com eco",
},
],
erros_criticos: [
{
erro: "Confundir sopro diastólico com sistólico",
descricao: "Diastólico = estenose; sistólico = insuficiência",
penalidade: 2,
evitavel: true,
},
{
erro: "Não solicitar ecocardiograma",
descricao: "Ecocardiograma confirma diagnóstico e gravidade",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{ item: "Investigou dispneia ao esforço", realizado: false, critico: true },
{ item: "Perguntou sobre febre reumática", realizado: false, critico: true },
{ item: "Mediu sinais vitais", realizado: false, critico: true },
{ item: "Ausculta: identificou sopro diastólico", realizado: false, critico: true },
{ item: "Solicitou ECG", realizado: false, critico: true },
{ item: "Solicitou ecocardiograma", realizado: false, critico: true },
{ item: "Prescreveu diurético e betabloqueador", realizado: false, critico: true },
],
rubrica_correcao: [
{
criterio: "Achados Clínicos",
peso: 20,
descricao: "Identificação de sopro diastólico em ruflar",
pontuacao_maxima: 20,
},
{
criterio: "Diagnóstico",
peso: 25,
descricao: "Solicitação e interpretação de ecocardiograma",
pontuacao_maxima: 25,
},
{
criterio: "Terapia",
peso: 25,
descricao: "Prescrição de diurético e betabloqueador",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dispneia ao esforço progressiva",
"Ortopneia ocasional",
"Palpitações",
"Antecedente de febre reumática",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Sinais vitais: FC pode ser irregular",
"Sopro diastólico em ruflar em ápex",
"Desdobramento de S2",
"ECG: P mitrale",
"Ecocardiograma: área <2.5 cm²",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Estenose mitral moderada", "NYHA II"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Diurético se congestão",
"Betabloqueador",
"Profilaxia de endocardite",
"Avaliação cirúrgica",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Investigou antecedente de febre reumática",
"Identificou sopro diastólico",
"Solicitou ecocardiograma",
"Prescreveu betabloqueador",
"Indicou profilaxia",
],
erros_comuns: [
"Confundir com insuficiência mitral",
"Não solicitar ecocardiograma",
"Prescrever diurético desnecessariamente",
],
orientacoes_pedagogicas: [
"Estenose mitral: sopro DIASTÓLICO em ruflar",
"Febre reumática é etiologia principal em países em desenvolvimento",
"P mitrale no ECG",
"Ecocardiograma é padrão-ouro",
"Betabloqueador controla frequência",
],
},
temaOSCE: "Valvopatias",
subtopicosOSCE: [
"Estenose mitral",
"Sopro diastólico em ruflar",
"P mitrale no ECG",
"Ecocardiograma com área <2.5 cm²",
"Febre reumática na etiologia"
],
diagnosticoCorreto: "Estenose Mitral",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("14"),
} as CasoOSCEV2;
