import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso048MielomaMultiplo: CasoOSCEV2 = {
// ====== CASO 48: MIELOMA MÚLTIPLO ======
id: "48",
titulo: "Mieloma Múltiplo",
sistema: "Hematologia",
tema: "Neoplasias hematológicas",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Diagnosticar mieloma múltiplo por achados clínicos e laboratoriais",
dados_visiveis_ao_estudante: {
nome_paciente: "José Antonio Martins",
idade: 72,
sexo: "Masculino",
queixa_principal: "Dor nas costas, anemia, fratura espontânea",
historia_breve: "Idoso com fratura vertebral sem trauma, cansaço crônico",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Mieloma Múltiplo",
diagnosticos_diferenciais: ["Osteoporose", "Metástases ósseas", "Paget"],
sindromes_associadas: ["Insuficiência renal", "Hipercalcemia"],
},
descricaoBreve: "Paciente com anemia, hipercalcemia, dor óssea, insuficiência renal",
categoria: "Neoplasias hematológicas",
paciente: {
id: "pac-048",
nome: "José Antonio Martins",
idade: 72,
sexo: "M",
queixaPrincipal: "Dor nas costas",
historicoDoenca: "Fratura vertebral há 1 mês",
antecedentes: ["Fratura espontânea"],
profissao: "Aposentado",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Dor forte nas costas, tive fratura sem cair",
dor_costas: "Muito intensa, incapacitante",
fratura: "Tive fratura de vértebra sem motivo aparente",
cansaco: "Muito cansaço",
infeccoes: "Tive infecção respiratória recentemente",
nausea: "Sim, enjoo e falta de apetite",
sede: "Muita sede",
},
respostaPaciente: {
inicial: "Dor costas e fratura",
dor_costas: "Intensa",
fratura: "Espontânea",
cansaco: "Muito",
infeccoes: "Recente",
nausea: "Sim",
sede: "Muito",
},
sinais_vitais: {
corretos: {
pressaoArterial: "125/80 mmHg",
frequenciaCardiaca: 82,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 97,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "125/80 mmHg",
frequenciaCardiaca: 82,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 97,
},
exame_fisico: {
correto: {
inspecao: "Palidez, postura encurvada",
palpacao: "Dor à palpação de costelas e coluna",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Dor óssea difusa",
regiao: "Geral",
achados_positivos: ["Palidez", "Dor óssea"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Pálido, cifose",
palpacao: "Dor óssea difusa",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Mieloma",
},
exame_fisico_interativo: {
geral: {
coloracao: "Pálido",
postura: "Cifose, dor ao movimento",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemograma",
descricao: "Série vermelha",
resultado: "Hb 9.5, RBC 4.2 × 10⁶",
valor_referencia: "Hb 13.5-17.5",
interpretacao: "Anemia normocítica",
},
{
nome: "Cálcio total",
descricao: "Cálcio sérico",
resultado: "11.5 mg/dL",
valor_referencia: "8.5-10.5 mg/dL",
interpretacao: "Hipercalcemia",
},
{
nome: "Creatinina",
descricao: "Função renal",
resultado: "2.8 mg/dL",
valor_referencia: "<1.2 mg/dL",
interpretacao: "Insuficiência renal",
},
{
nome: "Proteína total",
descricao: "Proteína sérica",
resultado: "8.5 g/dL",
valor_referencia: "6.0-8.3 g/dL",
interpretacao: "Hiperproteinemia",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Mieloma Múltiplo",
probabilidade: 90,
criterios_minimos: [
"Dor óssea difusa",
"Fratura patológica",
"Anemia",
"Insuficiência renal",
"Hipercalcemia",
"Hiperproteinemia",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Osteoporose",
criterios_exclusao: ["Anemia", "Insuficiência renal", "Hipercalcemia"],
achados_que_descartam: ["Hipercalcemia presente"],
},
],
examesIndicados: [
"Hemograma completo",
"Eletroforese de proteínas",
"Cadeias leves livres",
"Biopsia de medula óssea",
"RX de esqueleto",
],
conduta_esperada: {
imediata: [
"Internação",
"Hidratação agressiva para hipercalcemia",
"Biopsia de medula óssea",
],
curto_prazo: [
"Eletroforese de proteínas",
"Quimioterapia",
],
longo_prazo: [
"Acompanhamento oncológico",
],
encaminhamentos: ["Hematologia/Oncologia", "Internação"],
},
condutaCorreta: "Hemograma, proteínas, cálcio, creatinina, biopsia medula, hematologia/oncologia",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: [
"Hipercalcemia",
"Insuficiência renal",
"Anemia",
"Dor óssea",
],
descricao: "Mieloma em estágio avançado",
recomendacao: "Internação e quimioterapia imediata",
},
],
erros_criticos: [
{
erro: "Não investigar hipercalcemia",
descricao: "Risco de crise hipercalcêmica",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu mieloma",
realizado: false,
critico: true,
},
{
item: "Solicitou eletroforese",
realizado: false,
critico: true,
},
{
item: "Avaliou hipercalcemia",
realizado: false,
critico: true,
},
{
item: "Encaminhou hematologia",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de mieloma",
peso: 30,
descricao: "Achados clínicos e laboratoriais",
pontuacao_maxima: 30,
},
{
criterio: "Urgência do encaminhamento",
peso: 25,
descricao: "Hipercalcemia e insuficiência renal",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dor óssea difusa",
"Fratura espontânea",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Anemia",
"Hipercalcemia",
"Insuficiência renal",
"Hiperproteinemia",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["Mieloma múltiplo"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Eletroforese",
"Biopsia medula",
"Hematologia urgente",
"Tratamento de hipercalcemia",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu mieloma",
"Solicitou eletroforese",
"Avaliou cálcio",
"Encaminhou hematologia",
],
erros_comuns: ["Diagnosticar como osteoporose"],
orientacoes_pedagogicas: [
"Mieloma: dor óssea + anemia + insuficiência renal + hipercalcemia",
"Sempre pensar em mieloma em idoso com fratura patológica",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer mieloma como urgência oncológica",
comunicacao: ["explicou gravidade"],
anamnese: ["investigou dor óssea"],
exame_fisico: ["detectou dor difusa"],
exames_complementares: ["pediu proteínas e cálcio"],
raciocinio: ["diagnosticou mieloma"],
conduta: ["encaminhou hematologia"],
soap: ["documentou urgência"],
},
temaOSCE: "Neoplasias hematológicas",
subtopicosOSCE: [
"Mieloma múltiplo",
"Dor óssea",
"Hipercalcemia",
"Insuficiência renal",
"Fatura patológica",
],
diagnosticoCorreto: "Mieloma Múltiplo",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("48"),
} as CasoOSCEV2;
