import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso050CoagulacaoIntravascularDisseminada: CasoOSCEV2 = {
// ====== CASO 50: COAGULAÇÃO DISSEMINADA ======
id: "50",
titulo: "Coagulação Intravascular Disseminada",
sistema: "Hematologia",
tema: "Coagulopatias",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Reconhecer CID como emergência com achados clínicos e laboratoriais",
dados_visiveis_ao_estudante: {
nome_paciente: "Patricia Rocha",
idade: 45,
sexo: "Feminino",
queixa_principal: "Sangramento difuso, choque, confusão mental",
historia_breve: "Mulher com sepse evoluindo para choque com coagulopatia",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Coagulação Intravascular Disseminada (CID)",
diagnosticos_diferenciais: ["Trombocitopenia imune", "Hepatopatia", "Fibrinólise primária"],
sindromes_associadas: ["Choque séptico", "Insuficiência de múltiplos órgãos"],
},
descricaoBreve: "Paciente com sepse, sangramento, plaquetas baixas, INR elevado, fibrinogênio baixo",
categoria: "Coagulopatias",
paciente: {
id: "pac-050",
nome: "Patricia Rocha",
idade: 45,
sexo: "F",
queixaPrincipal: "Sangramento e choque",
historicoDoenca: "Infecção há 3 dias, piora aguda",
antecedentes: ["Sepse"],
profissao: "Enfermeira",
estado_civil: "Casada",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Tô sangrando de vários lugares, tô muito mal",
sangramento: "Sim, vomitando sangue, sangramento nasal, gengivite",
confusao: "Confusa, desorientada",
frio: "Muito frio, tremendo",
respiracao: "Falta de ar",
pressao: "Tontura, pressão muito baixa",
infeccao_anterior: "Tive infecção há dias",
},
respostaPaciente: {
inicial: "Sangramento e choque",
sangramento: "Múltiplos sítios",
confusao: "Sim",
frio: "Sim",
respiracao: "Sim",
pressao: "Muito baixa",
infeccao_anterior: "Sim",
},
sinais_vitais: {
corretos: {
pressaoArterial: "75/45 mmHg",
frequenciaCardiaca: 135,
frequenciaRespiratoria: 28,
temperatura: 40.5,
saturacaoOxigenio: 92,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "75/45 mmHg",
frequenciaCardiaca: 135,
frequenciaRespiratoria: 28,
temperatura: 40.5,
saturacaoOxigenio: 92,
},
exame_fisico: {
correto: {
inspecao: "Paciente em choque, cianose, petéquias e equimoses extensas, sangramento ativo",
palpacao: "Extremidades frias, débil, pulsos filiformes",
ausculta: "Taquicardia, hipotensão",
percussao: "Normal",
observacoes: "Sinais de CID com choque",
regiao: "Geral",
achados_positivos: [
"Sangramento difuso",
"Choque",
"Petéquias",
"Equimoses",
"Cianose",
],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Choque, sangramento, petéquias",
palpacao: "Extremidades frias",
ausculta: "Taquicardia",
percussao: "Normal",
observacoes: "CID com choque séptico",
},
exame_fisico_interativo: {
geral: {
coloracao: "Cianótico com petéquias",
consciencia: "Confuso, desorientado",
},
},
exames_complementares_disponiveis: [
{
nome: "Plaquetas",
descricao: "Contagem de plaquetas",
resultado: "35.000/mm³",
valor_referencia: ">150.000",
interpretacao: "Trombocitopenia",
},
{
nome: "Fibrinogênio",
descricao: "Nível de fibrinogênio",
resultado: "85 mg/dL",
valor_referencia: ">200 mg/dL",
interpretacao: "Hipofibrinogenemia",
},
{
nome: "INR",
descricao: "Coagulação",
resultado: "4.2",
valor_referencia: "<1.1",
interpretacao: "Coagulopatia severa",
},
{
nome: "D-dímero",
descricao: "Fibrinólise",
resultado: ">10.000 ng/mL",
valor_referencia: "<500 ng/mL",
interpretacao: "Fibrinólise massiva",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Coagulação Intravascular Disseminada",
probabilidade: 98,
criterios_minimos: [
"Sangramento difuso",
"Trombocitopenia",
"Hipofibrinogenemia",
"INR elevado",
"D-dímero massivo",
"Sepse",
"Choque",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Hepatopatia",
criterios_exclusao: ["Sepse aguda", "D-dímero extremamente elevado"],
achados_que_descartam: ["Contexto clínico de sepse"],
},
],
examesIndicados: [
"Hemograma com plaquetas",
"Coagulação (TP, TTPa)",
"Fibrinogênio",
"D-dímero",
"Produtos de degradação de fibrina",
"Testes de sepse",
],
conduta_esperada: {
imediata: [
"CTI",
"Suporte de choque",
"Antibióticos de amplo espectro",
],
curto_prazo: [
"Transfusão de componentes",
"Tratamento de causa de CID",
],
longo_prazo: [
"Suporte de órgão",
],
encaminhamentos: ["CTI", "Hematologia", "Infectologia"],
},
condutaCorreta: "CTI urgente, suporte hemodinâmico, antibióticos, transfusão de componentes, testes de coagulação",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: [
"Choque",
"Sangramento difuso",
"Coagulopatia severa",
"Confusão mental",
],
descricao: "CID com risco de morte iminente",
recomendacao: "CTI com suporte máximo",
},
],
erros_criticos: [
{
erro: "Não encaminhar para CTI",
descricao: "Risco imediato de morte",
penalidade: 3,
evitavel: true,
},
{
erro: "Transfundir plaquetas sem tratar causa",
descricao: "Consumidas rapidamente",
penalidade: 1.5,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu CID",
realizado: false,
critico: true,
},
{
item: "Solicitou testes de coagulação",
realizado: false,
critico: true,
},
{
item: "Encaminhou CTI",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de CID",
peso: 35,
descricao: "Achados clínicos e laboratoriais",
pontuacao_maxima: 35,
},
{
criterio: "Urgência e conduta",
peso: 30,
descricao: "CTI imediato",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Sangramento difuso",
"Sepse anterior",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Choque",
"Petéquias",
"Sangramento ativo",
"Coagulopatia severa",
"D-dímero massivo",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Coagulação intravascular disseminada",
"Choque séptico",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"CTI imediato",
"Suporte hemodinâmico",
"Antibióticos",
"Transfusão",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu CID",
"Solicitou testes de coagulação",
"Encaminhou CTI",
],
erros_comuns: ["Achar que é trombocitopenia imune"],
orientacoes_pedagogicas: [
"CID: sangramento + coagulopatia + contexto de sepse/trauma/malignidade",
"D-dímero é o teste mais sensível",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer CID como emergência máxima",
comunicacao: ["explicou urgência crítica"],
anamnese: ["investigou contexto de sepse"],
exame_fisico: ["detectou sangramento difuso"],
exames_complementares: ["pediu coagulação"],
raciocinio: ["diagnosticou CID"],
conduta: ["encaminhou CTI"],
soap: ["documentou emergência"],
},
temaOSCE: "Coagulopatias",
subtopicosOSCE: [
"CID",
"Sangramento difuso",
"Coagulopatia",
"Choque séptico",
"Emergência máxima",
],
diagnosticoCorreto: "Coagulação Intravascular Disseminada",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("50"),
} as CasoOSCEV2;
