import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso032CriseAsmaticaGrave: CasoOSCEV2 = {
// ====== CASO 32: CRISE ASMÁTICA GRAVE ======
id: "32",
titulo: "Crise Asmática Grave",
sistema: "Respiratório",
tema: "Dispneia Aguda",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Reconhecer crise asmática grave como emergência e instituir manejo apropriado",
dados_visiveis_ao_estudante: {
nome_paciente: "Marina Costa",
idade: 35,
sexo: "Feminino",
queixa_principal: "Falta de ar muito intensa, chiado intenso",
historia_breve: "Crise asmática que começou ontem, piorou muito hoje, inaladores não controlaram",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Crise Asmática Grave (Status Asthmaticus)",
diagnosticos_diferenciais: ["Anafilaxia", "Pneumotórax", "Embolia Pulmonar"],
sindromes_associadas: ["Insuficiência Respiratória"],
},
descricaoBreve: "Paciente em insuficiência respiratória, com fadiga muscular, silêncio auscultório, redução grave de pico de fluxo",
categoria: "Asma",
paciente: {
id: "pac-032",
nome: "Marina Costa",
idade: 35,
sexo: "F",
queixaPrincipal: "Falta de ar intensa",
historicoDoenca: "Asma desde infância, crises frequentes",
antecedentes: ["Asma", "Alergias", "GERD"],
profissao: "Enfermeira",
estado_civil: "Solteira",
alergias: ["Vários"],
medicamentos_em_uso: ["Salbutamol", "Fluticasona"],
},
respostas_do_paciente: {
inicial: "Não consigo respirar, tô morrendo de falta de ar",
respiracao: "Muito ruim, tenho que fazer esforço grande",
chiado: "Não tô mais ouvindo chiado, tá muito pior",
sentado: "Só consigo respirar sentada ou em pé",
fadiga: "Estou muito cansada, os pulmões estão doendo",
inaladores: "Usei vários mas não melhorou",
confusao: "Tô confusa, tonteada",
},
respostaPaciente: {
inicial: "Não consigo respirar",
respiracao: "Muito ruim",
chiado: "Não tô ouvindo",
sentado: "Sim",
fadiga: "Muita",
inaladores: "Não ajudaram",
confusao: "Sim",
},
sinais_vitais: {
corretos: {
pressaoArterial: "160/100 mmHg",
frequenciaCardiaca: 130,
frequenciaRespiratoria: 32,
temperatura: 37.2,
saturacaoOxigenio: 85,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "160/100 mmHg",
frequenciaCardiaca: 130,
frequenciaRespiratoria: 32,
temperatura: 37.2,
saturacaoOxigenio: 85,
},
exame_fisico: {
correto: {
inspecao: "Taquipneia severa, uso intenso de musculatura acessória, sudorese profusa, agitação",
palpacao: "Expansão torácica reduzida, assimétrica",
ausculta: "Silêncio auscultório bilateral (pulmão silencioso = sinal grave), ausência de sibilos",
percussao: "Normal",
observacoes: "Sinais de insuficiência respiratória grave - EMERGÊNCIA",
regiao: "Pulmões",
achados_positivos: ["Taquipneia severa"],
achados_negativos: ["Sibilos"],
},
},
exameFisicoCorreto: {
inspecao: "Taquipneia severa, fadiga",
palpacao: "Expansão reduzida",
ausculta: "Silêncio auscultório",
percussao: "Normal",
observacoes: "Emergência respiratória",
},
exame_fisico_interativo: {
respiratorio: {
inspecao_torax: "Taquipneia 32 ipm, expansão torácica muito reduzida",
padrao_respiratorio: "Rápido e superficial",
expansibilidade: "Muito reduzida",
fremito_toracovocal: "Diminuído",
ausculta_pulmonar: "Silêncio auscultório bilateral (ausência de ruídos respiratórios)",
musculatura_acessoria: "Uso intenso de esterno-cleidomastoideo e escalenos",
},
},
exames_complementares_disponiveis: [
{
nome: "Oximetria de Pulso",
descricao: "Saturação de oxigênio",
resultado: "85%",
valor_referencia: ">95%",
interpretacao: "Hipoxemia grave",
},
{
nome: "Pico de Fluxo",
descricao: "Peak flow",
resultado: "<40% do predito ou não consegue medir",
valor_referencia: ">80%",
interpretacao: "Obstrução severa",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Crise Asmática Grave (Status Asthmaticus)",
probabilidade: 98,
criterios_minimos: [
"Dispneia severa em repouso",
"Silêncio auscultório",
"SpO2 <90%",
"Fadiga muscular",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Anafilaxia",
criterios_exclusao: ["Ausência de urticária, angioedema"],
achados_que_descartam: ["História compatível com asma"],
},
],
examesIndicados: [
"Oximetria urgente",
"ABG se disponível",
"RX tórax para descartar pneumotórax",
],
conduta_esperada: {
imediata: [
"Encaminhar para emergência/UTI URGENTEMENTE",
"Oxigenioterapia agressiva (máscara não-reinalante)",
"Broncodilatador inalado contínuo ou IV",
"Corticóide IV",
"Possível intubação",
],
curto_prazo: [
"Monitorização em UTI",
"Suporte respiratório",
"Investigação de causa desencadeante",
],
longo_prazo: [
"Controle de asma",
"Plano de ação",
],
encaminhamentos: ["Emergência", "UTI", "Pneumologia"],
},
condutaCorreta: "Emergência respiratória - oxigenioterapia agressiva, broncodilatadores, corticóide IV, considerar intubação",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: [
"SpO2 <90%",
"Silêncio auscultório",
"Taquipneia >30",
"Fadiga muscular",
"Confusão mental",
],
descricao: "Insuficiência respiratória iminente, risco de parada cardiorrespiratória",
recomendacao: "Intubação e ventilação mecânica",
},
],
erros_criticos: [
{
erro: "Não reconhecer como emergência",
descricao: "Silêncio auscultório é sinal ominoso",
penalidade: 3,
evitavel: true,
},
{
erro: "Atrasar oxigenioterapia e encaminhamento para UTI",
descricao: "Paciente pode descompensar rapidamente",
penalidade: 3,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu asma grave",
realizado: false,
critico: true,
},
{
item: "Iniciou oxigenioterapia agressiva",
realizado: false,
critico: true,
},
{
item: "Prescreveu broncodilatador",
realizado: false,
critico: true,
},
{
item: "Prescreveu corticóide IV",
realizado: false,
critico: true,
},
{
item: "Encaminhou para UTI",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de emergência",
peso: 35,
descricao: "Silêncio auscultório e hipoxemia",
pontuacao_maxima: 35,
},
{
criterio: "Manejo apropriado",
peso: 30,
descricao: "Oxigenação e encaminhamento",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dispneia severa",
"Falha de resposta a inaladores",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Taquipneia 32",
"SpO2 85%",
"Silêncio auscultório",
"Fadiga muscular",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Status asthmaticus",
"Insuficiência respiratória iminente",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Oxigenioterapia agressiva",
"Broncodilatadores IV/contínuo",
"Corticóide IV",
"UTI",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu gravidade",
"Iniciou oxigenioterapia agressiva",
"Prescreveu medicações IV",
"Encaminhou UTI",
],
erros_comuns: [
"Achar que apenas inaladores resolverão",
"Não reconhecer silêncio auscultório como grave",
],
orientacoes_pedagogicas: [
"Silêncio auscultório em asma = pulmão muito obstruído = EMERGÊNCIA",
"Status asthmaticus requer UTI e suporte avançado",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer asma grave como emergência respiratória e instituir manejo apropriado",
comunicacao: ["explicou gravidade à paciente"],
anamnese: ["investigou causa desencadeante"],
exame_fisico: ["reconheceu silêncio auscultório"],
exames_complementares: ["avaliou SpO2 urgentemente"],
raciocinio: ["diagnosticou status asthmaticus"],
conduta: ["iniciou oxigenioterapia agressiva e medicações"],
soap: ["documentou emergência respiratória"],
},
temaOSCE: "Asma",
subtopicosOSCE: [
"Asma grave",
"Status asthmaticus",
"Silêncio auscultório",
"Insuficiência respiratória",
"Emergência",
],
diagnosticoCorreto: "Crise Asmática Grave (Status Asthmaticus)",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("32"),
} as CasoOSCEV2;
