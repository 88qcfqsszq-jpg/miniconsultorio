# MEDIX Learn — Infectologia

## Objetivo
Ensinar o aluno a raciocinar sobre febre, foco infeccioso, gravidade, sepse, transmissão e uso inicial responsável de antimicrobianos.

## Trilhas
1. Febre
2. Sepse e sinais de gravidade
3. Infecção respiratória
4. Infecção urinária
5. Dengue e arboviroses
6. Antibiótico: quando pensar, quando não pensar
7. Isolamento, transmissão e prevenção
