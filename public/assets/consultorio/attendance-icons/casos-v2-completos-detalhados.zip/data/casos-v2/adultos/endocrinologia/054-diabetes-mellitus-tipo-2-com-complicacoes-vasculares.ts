import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso054DiabetesMellitusTipo2Com: CasoOSCEV2 = {
// ====== CASO 54: DIABETES MELLITUS COM COMPLICAÇÕES VASCULARES ======
id: "54",
titulo: "Diabetes Mellitus Tipo 2 com Complicações Vasculares",
sistema: "Endocrinologia",
tema: "Casos Integradores",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 13,
objetivo_pedagogico: "Reconhecer diabetes com complicações microvasculares e macrovasculares",
dados_visiveis_ao_estudante: {
nome_paciente: "Fernando Oliveira",
idade: 62,
sexo: "Masculino",
queixa_principal: "Cansaço, formigamento nos pés, dificuldade visual",
historia_breve: "Diabético mal controlado com múltiplas complicações",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Diabetes Mellitus Tipo 2 com Neuropatia e Retinopatia",
diagnosticos_diferenciais: ["Polineuropatia por outra causa", "Catarata", "Glaucoma"],
sindromes_associadas: ["Retinopatia diabética", "Nefropatia diabética", "Neuropatia periférica"],
},
descricaoBreve: "Paciente diabético com polineuropatia, retinopatia, proteinúria e glicemia descontrolada",
categoria: "Casos Integradores",
paciente: {
id: "pac-054",
nome: "Fernando Oliveira",
idade: 62,
sexo: "M",
queixaPrincipal: "Cansaço e complicações",
historicoDoenca: "Diabetes há 15 anos mal controlado",
antecedentes: ["Diabetes tipo 2", "Hipertensão", "Dislipidemia"],
profissao: "Vendedor",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: ["Metformina"],
},
respostas_do_paciente: {
inicial: "Tenho diabetes há muito tempo, agora tô com complicações",
glicemia: "Nunca controlei bem, acima de 200",
visao: "Visão embaçada, ficou pior",
formigamento: "Nos pés, principalmente à noite",
cansaco: "Muito cansaço",
hipertensao: "Pressão alta também",
sangue_urina: "Às vezes vejo sangue na urina",
},
respostaPaciente: {
inicial: "Diabetes com complicações",
glicemia: "Descontrolada",
visao: "Embaçada",
formigamento: "Sim",
cansaco: "Muita",
hipertensao: "Sim",
sangue_urina: "Às vezes",
},
sinais_vitais: {
corretos: {
pressaoArterial: "160/95 mmHg",
frequenciaCardiaca: 88,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 97,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "160/95 mmHg",
frequenciaCardiaca: 88,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 97,
},
exame_fisico: {
correto: {
inspecao: "Paciente obeso, úlcera em pé direito",
palpacao: "Redução de sensibilidade em MMII, pulsos palpáveis",
ausculta: "Normal",
percussao: "Reflexos diminuídos em MMII",
observacoes: "Neuropatia periférica com úlcera diabética",
regiao: "Geral",
achados_positivos: ["Neuropatia", "Úlcera", "Obesidade"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Obeso, úlcera em pé",
palpacao: "Sensibilidade reduzida",
ausculta: "Normal",
percussao: "Reflexos diminuídos",
observacoes: "Neuropatia diabética",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Sobrepeso/obeso",
consciencia: "Alerta",
},
membros: {
edema: "Polineuropatia sensitiva simétrica",
mobilidade: "Grau 2-3/5 MMII, 4/5 MMSS",
},
},
exames_complementares_disponiveis: [
{
nome: "Glicemia em jejum",
descricao: "Glicose sanguínea",
resultado: "280 mg/dL",
valor_referencia: "<100 mg/dL",
interpretacao: "Hiperglicemia severa",
},
{
nome: "HbA1c",
descricao: "Controle glicêmico",
resultado: "10.5%",
valor_referencia: "<5.7%",
interpretacao: "Controle ruim",
},
{
nome: "Proteinúria",
descricao: "Proteína em urina",
resultado: "3+ (proteinúria nefrótica)",
valor_referencia: "Negativa",
interpretacao: "Nefropatia diabética avançada",
},
{
nome: "Creatinina",
descricao: "Função renal",
resultado: "2.1 mg/dL",
valor_referencia: "<1.2 mg/dL",
interpretacao: "Insuficiência renal",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Diabetes Mellitus Tipo 2 com Complicações",
probabilidade: 98,
criterios_minimos: [
"Glicemia elevada",
"HbA1c >7%",
"Neuropatia",
"Proteinúria",
"Retinopatia",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Polineuropatia por outra causa",
criterios_exclusao: ["Diabetes confirmado", "Glicemia elevada"],
achados_que_descartam: ["História de diabetes"],
},
],
examesIndicados: [
"Glicemia, HbA1c",
"Microalbuminúria/proteinúria",
"Creatinina e TFG",
"Lipidograma",
"Retinoscopia",
],
conduta_esperada: {
imediata: [
"Insulina se glicemia >250",
"Controle de pressão arterial",
],
curto_prazo: [
"Otimização de hipoglicemiantes",
"Cuidado de ferida",
"Endocrinologia",
],
longo_prazo: [
"Prevenção de complicações",
"Reabilitação vascular",
],
encaminhamentos: ["Endocrinologia", "Oftalmologia", "Angiologia"],
},
condutaCorreta: "Insulina, losartana, estatina, controle glicêmico agressivo, múltiplos especialistas",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["Glicemia >250", "Proteinúria nefrótica", "Neuropatia com úlcera"],
descricao: "Diabetes com complicações severas",
recomendacao: "Hospitalização e intensificação de tratamento",
},
],
erros_criticos: [
{
erro: "Não investigar complicações vasculares",
descricao: "Essencial para prognóstico",
penalidade: 2,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu diabetes descompensado",
realizado: false,
critico: true,
},
{
item: "Investigou neuropatia",
realizado: false,
critico: true,
},
{
item: "Avaliou função renal",
realizado: false,
critico: true,
},
{
item: "Solicitou retinoscopia",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de complicações",
peso: 30,
descricao: "Neuropatia, nefropatia, retinopatia",
pontuacao_maxima: 30,
},
{
criterio: "Conduta multidisciplinar",
peso: 25,
descricao: "Encaminhamentos apropriados",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Diabetes mal controlado",
"Complicações",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Glicemia 280",
"HbA1c 10.5%",
"Neuropatia",
"Proteinúria nefrótica",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Diabetes tipo 2 com complicações",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Insulina",
"Pressão arterial",
"Múltiplos especialistas",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu complicações",
"Investigou neuropatia",
"Avaliou renal",
"Encaminhou oftalmologia",
],
erros_comuns: ["Focar apenas em glicemia"],
orientacoes_pedagogicas: [
"Diabetes: sempre investigar complicações",
"Retinopatia, nefropatia, neuropatia são as 3 principais",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer complicações multissistêmicas",
comunicacao: ["explicou importância do controle"],
anamnese: ["investigou complicações"],
exame_fisico: ["detectou neuropatia"],
exames_complementares: ["pediu múltiplos exames"],
raciocinio: ["diagnosticou complicações"],
conduta: ["prescreveu múltiplos fármacos"],
soap: ["documentou integradoramente"],
},
temaOSCE: "Casos Integradores",
subtopicosOSCE: [
"Diabetes descompensado",
"Neuropatia",
"Nefropatia",
"Retinopatia",
"Complicações vasculares",
],
diagnosticoCorreto: "Diabetes Mellitus Tipo 2 com Complicações Microvasculares e Macrovasculares",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("54"),
} as CasoOSCEV2;
