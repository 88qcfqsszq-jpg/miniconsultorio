import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso033DpocEstavel: CasoOSCEV2 = {
// ====== CASO 33: DPOC ESTÁVEL ======
id: "33",
titulo: "DPOC Estável",
sistema: "Respiratório",
tema: "Doença Obstrutiva",
nivel: "iniciante",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Diagnosticar DPOC estável e orientar manejo de manutenção",
dados_visiveis_ao_estudante: {
nome_paciente: "Gilson Andrade",
idade: 65,
sexo: "Masculino",
queixa_principal: "Tosse crônica e falta de ar",
historia_breve: "Fumante de 40 anos-maço, tosse diária com catarro, limitação aos esforços",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "DPOC Estável Gold II",
diagnosticos_diferenciais: ["Asma", "Cardiopatia", "Bronquiectasia"],
sindromes_associadas: ["Obstrução Crônica de Vias Aéreas"],
},
descricaoBreve: "Paciente com tosse crônica, sibilância leve, tórax em tonel, baqueteamento",
categoria: "DPOC",
paciente: {
id: "pac-033",
nome: "Gilson Andrade",
idade: 65,
sexo: "M",
queixaPrincipal: "Tosse crônica",
historicoDoenca: "Fumante 40 anos, tosse há 10 anos",
antecedentes: ["Tabagismo", "DPOC"],
profissao: "Aposentado",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: ["Salbutamol", "Fluticasona/Salmeterol"],
},
respostas_do_paciente: {
inicial: "Tô com tosse constante, sou fumante há muitos anos",
tosse: "Sim, diária, com catarro amarelado",
respiracao: "Fico cansado ao subir escada",
historico: "Fumava 2 maços por dia, agora fumei menos",
catarro: "Toss todo dia, principalmente de manhã",
fumaca: "Piora quando respiro fumaça ou poluição",
},
respostaPaciente: {
inicial: "Tosse crônica",
tosse: "Sim, diária",
respiracao: "Cansaço ao esforço",
historico: "Fumante 40 anos",
catarro: "Amarelado",
fumaca: "Piora",
},
sinais_vitais: {
corretos: {
pressaoArterial: "135/85 mmHg",
frequenciaCardiaca: 82,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 92,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "135/85 mmHg",
frequenciaCardiaca: 82,
frequenciaRespiratoria: 18,
temperatura: 36.8,
saturacaoOxigenio: 92,
},
exame_fisico: {
correto: {
inspecao: "Tórax em tonel, leve uso de musculatura acessória, baqueteamento digital",
palpacao: "Expansão torácica diminuída",
ausculta: "Murmúrio vesicular reduzido bilateral, sibilos esparsos, roncos",
percussao: "Hipersonoro",
observacoes: "Achados típicos de DPOC",
regiao: "Pulmões",
achados_positivos: ["MV reduzido", "Sibilos", "Roncos"],
achados_negativos: ["Crepitações"],
},
},
exameFisicoCorreto: {
inspecao: "Tórax em tonel",
palpacao: "Expansão reduzida",
ausculta: "MV reduzido, sibilos, roncos",
percussao: "Hipersonoro",
observacoes: "DPOC típica",
},
exame_fisico_interativo: {
respiratorio: {
inspecao_torax: "Tórax em tonel, diâmetro AP aumentado",
padrao_respiratorio: "Frequência normal, padrão pursed-lips positive",
expansibilidade: "Reduzida bilateralmente",
ausculta_pulmonar: "MV reduzido bilateralmente, sibilos e roncos esparsos",
musculatura_acessoria: "Leve uso",
},
geral: {
estado_geral: "Baqueteamento digital bilateral",
},
},
exames_complementares_disponiveis: [
{
nome: "Espirometria",
descricao: "Avaliação de função pulmonar",
resultado: "FEV1 65% do predito, FEV1/FVC 0.62",
valor_referencia: "FEV1 >80%, FEV1/FVC >0.70",
interpretacao: "DPOC GOLD II (moderada)",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "DPOC Estável",
probabilidade: 95,
criterios_minimos: [
"Histórico de tabagismo",
"Tosse crônica",
"Obstrução em espirometria",
"Tórax em tonel",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Asma",
criterios_exclusao: ["História de tabagismo de 40 anos"],
achados_que_descartam: ["Baqueteamento"],
},
],
examesIndicados: [
"Espirometria",
"RX tórax",
"TC se suspeita de bronquiectasia",
],
conduta_esperada: {
imediata: [
"Cessar tabagismo",
"Broncodilatadores",
],
curto_prazo: [
"Espirometria",
"Vacinação",
],
longo_prazo: [
"Broncodilatadores contínuos",
"Reabilitação pulmonar",
],
encaminhamentos: ["Pneumologia"],
},
condutaCorreta: "Espirometria, broncodilatadores, cessação de tabagismo, reabilitação pulmonar",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["FEV1 50-79%", "Sintomas ao esforço"],
descricao: "DPOC moderada",
recomendacao: "Medicações broncodilatadoras",
},
],
erros_criticos: [
{
erro: "Não solicitar espirometria",
descricao: "Confirmação diagnóstica necessária",
penalidade: 1.5,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu DPOC",
realizado: false,
critico: true,
},
{
item: "Perguntou sobre tabagismo",
realizado: false,
critico: true,
},
{
item: "Solicitou espirometria",
realizado: false,
critico: true,
},
{
item: "Orientou cessação de tabagismo",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de DPOC",
peso: 25,
descricao: "Achados clínicos",
pontuacao_maxima: 25,
},
{
criterio: "Manejo",
peso: 20,
descricao: "Medicações e cessação",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Tosse crônica",
"História de tabagismo",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Tórax em tonel",
"MV reduzido",
"Obstrução em espirometria",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["DPOC"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Broncodilatadores",
"Cessação tabagismo",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu DPOC",
"Pesquisou tabagismo",
"Solicitou espirometria",
"Orientou cessação",
],
erros_comuns: ["Confundir com asma"],
orientacoes_pedagogicas: [
"DPOC: tabagismo + tosse crônica + obstrução não reversível",
"Baqueteamento é sinal de DPOC, não de asma",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar DPOC e orientar sobre fatores de risco",
comunicacao: ["explicou importância de cessar tabagismo"],
anamnese: ["investigou tabagismo"],
exame_fisico: ["detectou tórax em tonel"],
exames_complementares: ["pediu espirometria"],
raciocinio: ["diagnosticou DPOC"],
conduta: ["prescreveu medicações"],
soap: ["documentou DPOC"],
},
temaOSCE: "Doença Obstrutiva",
subtopicosOSCE: [
"DPOC",
"Tabagismo",
"Tórax em tonel",
"Obstrução não reversível",
"Baqueteamento",
],
diagnosticoCorreto: "DPOC Estável",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("33"),
} as CasoOSCEV2;
