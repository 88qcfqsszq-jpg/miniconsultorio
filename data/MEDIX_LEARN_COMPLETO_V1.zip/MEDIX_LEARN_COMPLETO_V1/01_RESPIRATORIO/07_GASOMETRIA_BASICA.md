# Trilha Respiratório — Gasometria Básica

## Papel dentro do MEDIX Learn
Trilha para ensinar oxigenação, ventilação e distúrbios ácido-base sem começar por fórmulas complexas.

## Objetivo pedagógico
Fazer o aluno interpretar gasometria básica com foco clínico: pH, PaCO₂, HCO₃⁻, PaO₂ e SaO₂.

## Competências ao final
- Identificar acidemia/alcalemia.
- Diferenciar distúrbio respiratório de metabólico.
- Reconhecer hipoxemia na gasometria.
- Relacionar PaCO₂ com ventilação.
- Entender hipercapnia em DPOC/fadiga.

## Sequência didática padrão
1. **Microaula** — conceito central em linguagem simples.
2. **Fisiologia aplicada** — mecanismo que explica o sinal/sintoma.
3. **Semiologia** — como o mecanismo aparece no paciente.
4. **Raciocínio clínico** — como diferenciar causas próximas.
5. **Mini-casos** — aplicação curta, com pergunta e feedback.
6. **Questões ativas** — perguntas que obrigam o aluno a pensar.
7. **Erros comuns** — atalhos mentais perigosos.
8. **Mapa final** — síntese visual/textual.
9. **Ponte para OSCE** — para onde o aluno vai treinar depois.

## Blocos obrigatórios da trilha
- pH: acidemia e alcalemia.
- PaCO₂: componente respiratório.
- HCO₃⁻: componente metabólico.
- PaO₂/SaO₂: oxigenação.
- Acidose respiratória, alcalose respiratória, acidose metabólica.
- Compensação: noção inicial.
- DPOC e retenção de CO₂.

## Mini-casos sugeridos
- DPOC hipercápnico.
- Crise asmática grave com fadiga.
- Sepse com acidose metabólica.
- Ansiedade/hiperventilação com alcalose respiratória.

## Questões ativas-base
1. PaCO₂ alta indica problema de quê?
2. SpO₂ normal exclui acidose?
3. O que muda em DPOC com retenção de CO₂?

## Erros comuns a corrigir
- Confundir PaO₂ com SpO₂.
- Interpretar pH isolado.
- Não olhar PaCO₂.
- Achar que oxigênio corrige hipercapnia.

## Ponte para OSCE
OSCE Ciclo Básico: interpretação inicial de exames. OSCE Clínico: DPOC/asma grave com evolução gasométrica.
