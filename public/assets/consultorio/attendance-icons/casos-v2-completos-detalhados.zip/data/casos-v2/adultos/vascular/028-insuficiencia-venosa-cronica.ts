import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso028InsuficienciaVenosaCronica: CasoOSCEV2 = {
// ====== CASO 28: INSUFICIÊNCIA VENOSA CRÔNICA ======
id: "28",
titulo: "Insuficiência Venosa Crônica",
sistema: "Vascular",
tema: "Vasculopatia Periférica",
nivel: "iniciante",
tipo_estacao: "integrada",
tempo_osce_minutos: 10,
objetivo_pedagogico: "Diagnosticar insuficiência venosa crônica e orientar manejo conservador",
dados_visiveis_ao_estudante: {
nome_paciente: "Conceição Oliveira",
idade: 58,
sexo: "Feminino",
queixa_principal: "Inchaço nas pernas e veias dilatadas",
historia_breve: "Inchaço progressivo ao longo do dia, varizes visíveis há muitos anos",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Insuficiência Venosa Crônica Classe II-III",
diagnosticos_diferenciais: ["Linfedema", "Insuficiência cardíaca", "TVP"],
sindromes_associadas: ["Síndrome Pós-Trombótica"],
},
descricaoBreve: "Paciente com varizes, edema depressível, pigmentação, lipodermatosclerose",
categoria: "Vascular",
paciente: {
id: "pac-028",
nome: "Conceição Oliveira",
idade: 58,
sexo: "F",
queixaPrincipal: "Inchaço nas pernas",
historicoDoenca: "Edema progressivo, varizes há muitos anos",
antecedentes: ["Múltiplas gestações", "Obesidade"],
profissao: "Vendedora",
estado_civil: "Casada",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Minhas pernas incharam muito, especialmente no final do dia",
inchaço: "Sim, edema que piora ao longo do dia",
varizes: "Sim, tenho varizes há muitos anos",
dor: "Dor e peso nas pernas ao final do dia",
historico: "Problemas começaram após gestações",
coceira: "Às vezes fico com coceira nos tornozelos",
},
respostaPaciente: {
inicial: "Inchaço nas pernas",
inchaço: "Sim, piora ao dia",
varizes: "Sim",
dor: "Sim, peso",
historico: "Após gestações",
coceira: "Às vezes",
},
sinais_vitais: {
corretos: {
pressaoArterial: "130/80 mmHg",
frequenciaCardiaca: 70,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 98,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "130/80 mmHg",
frequenciaCardiaca: 70,
frequenciaRespiratoria: 16,
temperatura: 36.8,
saturacaoOxigenio: 98,
},
exame_fisico: {
correto: {
inspecao: "Varizes visíveis bilateralmente, edema maleolar, hiperpigmentação marrom nos tornozelos",
palpacao: "Edema com cacifo, endurecimento de pele em tornozelos",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Achados sugestivos de IVC avançada",
regiao: "Membros inferiores",
achados_positivos: ["Varizes", "Edema", "Pigmentação"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Varizes, edema, hiperpigmentação",
palpacao: "Edema com cacifo",
ausculta: "Normal",
percussao: "Normal",
observacoes: "Sinais de IVC",
},
exame_fisico_interativo: {
membros: {
edema: "Bilateral, maleolar, com cacifo",
varizes: "Visíveis e palpáveis",
temperatura: "Normal",
mobilidade: "Normal",
},
},
exames_complementares_disponiveis: [
{
nome: "Ultrassom Venoso Duplex",
descricao: "Avaliação de fluxo venoso",
resultado: "Refluxo venoso profundo e superficial",
valor_referencia: "Sem refluxo",
interpretacao: "IVC com refluxo bidirecional",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Insuficiência Venosa Crônica",
probabilidade: 95,
criterios_minimos: [
"Varizes",
"Edema",
"Hiperpigmentação",
"Lipodermatosclerose",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Linfedema",
criterios_exclusao: ["Varizes presentes"],
achados_que_descartam: ["Fluxo venoso normal"],
},
],
examesIndicados: ["Ultrassom venoso duplex"],
conduta_esperada: {
imediata: [
"Elevação de membros",
"Meias de compressão",
],
curto_prazo: [
"Redução de peso",
"Atividade física",
],
longo_prazo: [
"Acompanhamento angiológico",
"Possível procedimento ablativo",
],
encaminhamentos: ["Angiologia"],
},
condutaCorreta: "Meias de compressão, elevação de membros, ultrassom venoso, possível ablação",
criterios_de_gravidade: [
{
severidade: "moderada",
sinais: ["Pigmentação", "Lipodermatosclerose"],
descricao: "Risco de úlcera venosa",
recomendacao: "Acompanhamento especializado",
},
],
erros_criticos: [
{
erro: "Não prescrever compressão",
descricao: "Essencial no manejo da IVC",
penalidade: 1.5,
evitavel: true,
},
],
checklist_osce: [
{
item: "Inspecionou varizes",
realizado: false,
critico: true,
},
{
item: "Avaliou edema",
realizado: false,
critico: true,
},
{
item: "Solicitou ultrassom venoso",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de IVC",
peso: 25,
descricao: "Achados clínicos",
pontuacao_maxima: 25,
},
{
criterio: "Manejo apropriado",
peso: 20,
descricao: "Compressão e seguimento",
pontuacao_maxima: 20,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Inchaço progressivo",
"Varizes",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Varizes visíveis",
"Edema com cacifo",
"Hiperpigmentação",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: ["IVC"],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Compressão",
"Ultrassom venoso",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu IVC",
"Prescreveu compressão",
"Solicitou ultrassom",
],
erros_comuns: ["Não pesquisar TVP prévia"],
orientacoes_pedagogicas: [
"IVC: varizes + edema + pigmentação",
"Sempre fazer ultrassom para descartar TVP",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Diagnosticar IVC e instituir compressão",
comunicacao: ["explicou natureza crônica"],
anamnese: ["investigou piora"],
exame_fisico: ["detectou varizes e edema"],
exames_complementares: ["pediu ultrassom"],
raciocinio: ["diagnosticou IVC"],
conduta: ["prescreveu compressão"],
soap: ["documentou IVC"],
},
temaOSCE: "Vasculopatia Periférica",
subtopicosOSCE: [
"Insuficiência venosa crônica",
"Varizes",
"Edema crônico",
"Lipodermatosclerose",
],
diagnosticoCorreto: "Insuficiência Venosa Crônica",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("28"),
} as CasoOSCEV2;
