import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso020InfartoAgudoDoMiocardioCom: CasoOSCEV2 = {
// ====== CASO 20: IAM COM SUPRA DE ST E TROMBÓLISE ======
id: "20",
titulo: "Infarto Agudo do Miocárdio com Supra de ST - Necessidade de Trombólise",
sistema: "Cardiovascular",
tema: "Síndrome Coronariana Aguda",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Reconhecer IAMCSST, avaliar tempo de sintoma, indicar trombólise quando angioplastia indisponível",
dados_visiveis_ao_estudante: {
nome_paciente: "Roberto Santos",
idade: 56,
sexo: "Masculino",
queixa_principal: "Dor torácica súbita há 90 minutos",
historia_breve: "Dor súbita enquanto dormia, sintomas típicos, paciente em região sem angioplastia disponível",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Infarto Agudo do Miocárdio com Supra de ST - Parede Anterior",
diagnosticos_diferenciais: ["Dissecção aórtica", "Embolia pulmonar", "Pericardite"],
sindromes_associadas: ["Síndrome Coronariana Aguda"],
},
descricaoBreve: "Paciente com dor típica, ECG com supra de ST, troponina ainda pode estar normal inicialmente, necessidade de reperfusão urgente",
categoria: "SCA",
paciente: {
id: "pac-020",
nome: "Roberto Santos",
idade: 56,
sexo: "M",
queixaPrincipal: "Dor torácica súbita",
historicoDoenca: "Acordou com dor súbita, está em pequena cidade sem angioplastia 24h",
antecedentes: ["HAS", "Diabetes tipo 2", "Ex-tabagista"],
profissao: "Fazendeiro",
estado_civil: "Casado",
alergias: [],
medicamentos_em_uso: ["Metformina 500mg", "Losartana 50mg"],
},
respostas_do_paciente: {
inicial: "Acordei com uma dor muito forte no peito, nunca senti algo assim",
dor: "Dor intensa, no meio do peito, irradia pro braço e pescoco",
intensidade: "9 em 10, pior dor da minha vida",
inicio: "Começou há uns 90 minutos quando acordei",
suor: "Sim, suei muito, sigo suado",
respiracao: "Sim, muita falta de ar",
nausea: "Sim, vomitei uma vez",
panico: "Tenho certeza que vou morrer",
},
respostaPaciente: {
inicial: "Acordei com uma dor muito forte no peito",
dor: "Dor intensa, irradia pro braço",
intensidade: "9",
inicio: "90 minutos atrás",
suor: "Sim",
respiracao: "Sim, muita",
nausea: "Sim, vomitei",
panico: "Tenho certeza que vou morrer",
},
sinais_vitais: {
corretos: {
pressaoArterial: "170/100 mmHg",
frequenciaCardiaca: 108,
frequenciaRespiratoria: 24,
temperatura: 36.9,
saturacaoOxigenio: 93,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "170/100 mmHg",
frequenciaCardiaca: 108,
frequenciaRespiratoria: 24,
temperatura: 36.9,
saturacaoOxigenio: 93,
glicemia: 145,
},
exame_fisico: {
correto: {
inspecao: "Paciente em grande desconforto, diaforese profusa, palidez acentuada, ansiedade severa",
palpacao: "Sensibilidade precordial importante",
ausculta: "Taquicardia, possível B3, sem sopros ou arritmias evidentes",
percussao: "Normal",
observacoes: "Paciente em risco iminente de morte, necessário reperfusão URGENTE",
regiao: "Precórdio",
achados_positivos: ["Taquicardia", "Diaforese profusa", "Palidez acentuada"],
achados_negativos: ["Sopros", "Arritmias"],
},
},
exameFisicoCorreto: {
inspecao: "Grande desconforto, diaforese profusa, palidez acentuada",
palpacao: "Sensibilidade precordial",
ausculta: "Taquicardia sem sopros",
percussao: "Normal",
observacoes: "Sinais de infarto extenso, emergência absoluta",
},
exame_fisico_interativo: {
geral: {
estado_geral: "Paciente em grande desconforto, diaforético, pálido, ansioso",
consciencia: "Lúcido mas em pânico",
},
cardiovascular: {
inspecao_precordial: "Diaforese evidente, palidez acentuada",
ausculta_cardiaca: "Bulhas hipofonéticas, FC 108 bpm, ritmo regular, possível B3",
pulsos: "Presentes mas finos",
turgencia_jugular: "Leve elevação",
edema: "Ausente",
},
},
exames_complementares_disponiveis: [
{
nome: "ECG (Eletrocardiograma)",
descricao: "12 derivações - URGENTE",
resultado: "Elevação de ST >3mm em V1-V3, depressão recíproca em D2, D3, aVF",
valor_referencia: "Segmento ST isoelétrico",
interpretacao: "IAMCSST anterior - Grande onda, indicação para reperfusão imediata",
},
{
nome: "Troponina I",
descricao: "Biomarcador cardíaco",
resultado: "0.8 ng/mL ou ainda <0.04 ng/mL se muito precoce",
valor_referencia: "<0.04 ng/mL",
interpretacao: "Troponina pode estar em subida se muito precoce",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Infarto Agudo do Miocárdio com Supra de ST",
probabilidade: 98,
criterios_minimos: [
"Dor isquêmica típica com duração >30 min",
"Elevação de ST >=1mm em 2 derivações contíguas",
"Necessidade de reperfusão em <120 minutos",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Dissecção aórtica",
criterios_exclusao: ["ECG com supra localizado"],
achados_que_descartam: ["Elevação focal de ST"],
},
],
examesIndicados: [
"ECG IMEDIATO",
"Troponina",
"Hemograma",
"Creatinina",
"Eletrólitos",
"Coagulograma",
],
conduta_esperada: {
imediata: [
"Chamar Cardiologia URGENTE",
"Monitorização cardíaca contínua",
"Oxigenioterapia para manter SpO2 >94%",
"Acesso venoso",
"Aspirina 500mg",
"Clopidogrel ou ticagrelor conforme protocolo",
"Heparina",
"Codeína ou Morfina para dor",
"Nitroglicerina se PA sistólica >90 mmHg",
"Avaliar candidatura à trombólise se angioplastia não disponível em <120min",
],
curto_prazo: [
"Se angioplastia disponível em <120min: transferência emergencial",
"Se angioplastia >120min: indicar trombólise imediatamente",
"Internação em UTI/UCO",
"Monitorização hemodinâmica",
],
longo_prazo: [
"Revascularização complementar se necessário",
"Reabilitação cardíaca",
"Modificação de fatores de risco",
],
encaminhamentos: ["Cardiologia", "Serviço de Hemodinâmica", "UTI/UCO"],
},
condutaCorreta: "IAMCSST = EMERGÊNCIA - Reperfusão urgente: angioplastia se <120min, senão trombólise imediata",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: [
"Elevação de ST extensa",
"Hipoxemia",
"Taquicardia",
"Instabilidade hemodinâmica",
],
descricao: "Paciente em risco iminente de morte, necessário reperfusão URGENTE",
recomendacao: "Transferência emergencial ou trombólise IMEDIATA",
},
],
erros_criticos: [
{
erro: "Atrasar ECG ou não reconhecer supra de ST",
descricao: "ECG é essencial para diagnosticar IAMCSST",
penalidade: 3,
evitavel: true,
},
{
erro: "Não indicar reperfusão em tempo hábil",
descricao: "Tempo é crítico - reperfusão em <120min melhora mortalidade",
penalidade: 3,
evitavel: true,
},
],
checklist_osce: [
{
item: "Solicitou ECG IMEDIATAMENTE",
realizado: false,
critico: true,
},
{
item: "Interpretou ECG corretamente - reconheceu elevação de ST",
realizado: false,
critico: true,
},
{
item: "Reconheceu como emergência que requer reperfusão",
realizado: false,
critico: true,
},
{
item: "Avaliou tempo de sintoma e disponibilidade de angioplastia",
realizado: false,
critico: true,
},
{
item: "Indicou trombólise se angioplastia indisponível em tempo",
realizado: false,
critico: true,
},
{
item: "Iniciou antitrombóticos apropriados",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento como emergência",
peso: 35,
descricao: "IAMCSST = risco de morte iminente",
pontuacao_maxima: 35,
},
{
criterio: "Decisão de reperfusão apropriada",
peso: 30,
descricao: "Angioplastia ou trombólise em tempo hábil",
pontuacao_maxima: 30,
},
{
criterio: "Manejo inicial apropriado",
peso: 15,
descricao: "Antitrombóticos, analgesia, oxigenioterapia",
pontuacao_maxima: 15,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dor isquêmica típica com duração >30 min",
"Tempo exato do início",
"Sintomas de alarme",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Sinais vitais com instabilidade",
"ECG com elevação de ST",
"Troponina",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"IAMCSST",
"Avaliação de tempo para reperfusão",
"Elegibilidade para trombólise",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Reperfusão urgente",
"Angioplastia ou trombólise conforme disponibilidade",
"Antitrombóticos",
"Suporte hemodinâmico",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu IAMCSST",
"Interpretou ECG corretamente",
"Indicou reperfusão urgente",
"Avaliou elegibilidade para trombólise",
"Iniciou antitrombóticos",
],
erros_comuns: [
"Atrasar ECG",
"Não reconhecer urgência",
"Atrasar indicação de reperfusão",
"Não estar familiarizado com protocolos de trombólise",
],
orientacoes_pedagogicas: [
"IAMCSST = EMERGÊNCIA = Reperfusão em <120 minutos salva vidas",
"Tempo door-to-balloon <90 min, door-to-needle <30 min",
"Protocolo: angioplastia preferida, trombólise se indisponível em tempo",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer IAMCSST como emergência, indicar reperfusão apropriada (angioplastia ou trombólise) em tempo hábil",
comunicacao: [
"demonstrou senso de urgência",
"tranquilizou o paciente apesar da gravidade",
"explicou necessidade de procedimento emergencial",
],
anamnese: [
"perguntou hora exata do início",
"investigou sintomas de alarme",
"investigou contraindicações a trombólise",
],
exame_fisico: [
"reconheceu sinais de choque cardiogênico",
"avaliou risco de complicações",
],
exames_complementares: [
"solicitou ECG URGENTE",
"interpretou corretamente",
"solicitou troponina e testes laboratoriais",
],
raciocinio: [
"diagnosticou IAMCSST",
"reconheceu urgência absoluta",
"avaliou tempo e disponibilidade para reperfusão",
],
conduta: [
"indicou reperfusão apropriada",
"iniciou antitrombóticos",
"não adiou procedimento",
],
soap: [
"documentou tempo exato",
"registrou critérios de IAMCSST",
"planejou reperfusão",
],
},
temaOSCE: "Síndrome Coronariana Aguda",
subtopicosOSCE: [
"IAMCSST",
"Elevação de ST",
"Reperfusão urgente",
"Trombólise",
"Door-to-balloon time",
"Emergência coronariana",
],
diagnosticoCorreto: "Infarto Agudo do Miocárdio com Supra de ST",,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("20"),
} as CasoOSCEV2;
