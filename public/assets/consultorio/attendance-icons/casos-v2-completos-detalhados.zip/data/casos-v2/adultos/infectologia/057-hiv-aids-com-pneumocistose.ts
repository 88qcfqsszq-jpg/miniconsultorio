import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso057HivAidsComPneumocistose: CasoOSCEV2 = {
// ====== CASO 57: HIV/AIDS COM INFECÇÃO OPORTUNISTA ======
id: "57",
titulo: "HIV/AIDS com Pneumocistose",
sistema: "Infectologia",
tema: "Casos Integradores",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 13,
objetivo_pedagogico: "Reconhecer AIDS com infecção oportunista e desempenho clinicamente",
dados_visiveis_ao_estudante: {
nome_paciente: "Daniel Lima",
idade: 38,
sexo: "Masculino",
queixa_principal: "Falta de ar progressiva, tosse seca, febre",
historia_breve: "Paciente HIV+ não aderente ao tratamento",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "HIV/AIDS com Pneumonia por Pneumocystis jirovecii",
diagnosticos_diferenciais: ["Tuberculose", "Criptococose", "Citomegalovírus"],
sindromes_associadas: ["Imunossupressão severa"],
},
descricaoBreve: "Paciente com CD4 <50, dispneia, hipoxemia, infiltrados intersticiais",
categoria: "Casos Integradores",
paciente: {
id: "pac-057",
nome: "Daniel Lima",
idade: 38,
sexo: "M",
queixaPrincipal: "Dispneia",
historicoDoenca: "HIV há 10 anos, sem adesão a TARV",
antecedentes: ["HIV", "Falta de adesão"],
profissao: "Desempregado",
estado_civil: "Solteiro",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Não consigo respirar, tenho tosse seca e febre",
respiracao: "Falta de ar com esforço mínimo",
tosse: "Tosse seca, persistente",
febre: "Febre à tarde",
cansaco: "Muito cansaço",
perda_peso: "Perdi muito peso",
hiv: "Tenho HIV mas parei o tratamento",
},
respostaPaciente: {
inicial: "Dispneia e tosse",
respiracao: "Muito",
tosse: "Seca",
febre: "Sim",
cansaco: "Muita",
perda_peso: "Sim",
hiv: "Sem TARV",
},
sinais_vitais: {
corretos: {
pressaoArterial: "105/65 mmHg",
frequenciaCardiaca: 110,
frequenciaRespiratoria: 28,
temperatura: 38.8,
saturacaoOxigenio: 88,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "105/65 mmHg",
frequenciaCardiaca: 110,
frequenciaRespiratoria: 28,
temperatura: 38.8,
saturacaoOxigenio: 88,
},
exame_fisico: {
correto: {
inspecao: "Paciente emagrecido, taquipneico, cianose periférica",
palpacao: "Expansão reduzida",
ausculta: "MV diminuído bilateral, crepitações finas",
percussao: "Normal",
observacoes: "Pneumocystis jirovecii pneumonia",
regiao: "Pulmões",
achados_positivos: ["Taquipneia", "Hipoxemia", "Crepitações"],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Emagrecido, taquipneico",
palpacao: "Expansão reduzida",
ausculta: "MV diminuído, crepitações",
percussao: "Normal",
observacoes: "Pneumocystis",
},
exame_fisico_interativo: {
respiratorio: {
inspecao_torax: "Taquipneia 28, cianose",
padrao_respiratorio: "Rápido",
expansibilidade: "Reduzida",
ausculta_pulmonar: "MV diminuído bilateral com crepitações finas",
musculatura_acessoria: "Uso discreto",
},
},
exames_complementares_disponiveis: [
{
nome: "CD4",
descricao: "Contagem de CD4",
resultado: "28 células/mm³",
valor_referencia: ">500 células/mm³",
interpretacao: "AIDS com imunossupressão severa",
},
{
nome: "Carga viral HIV",
descricao: "Carga viral",
resultado: ">100.000 cópias/mL",
valor_referencia: "Indetectável com TARV",
interpretacao: "Viremia ativa",
},
{
nome: "RX de tórax",
descricao: "Infiltrados pulmonares",
resultado: "Infiltrados intersticiais bilaterais",
valor_referencia: "Normal",
interpretacao: "Compatível com PCP",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "HIV/AIDS com Pneumocystis jirovecii Pneumonia",
probabilidade: 95,
criterios_minimos: [
"CD4 <50",
"Dispneia",
"Crepitações",
"Infiltrados intersticiais",
"SpO2 baixa",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Tuberculose",
criterios_exclusao: ["Infiltrados intersticiais não cavitários"],
achados_que_descartam: ["RX sem caverna"],
},
],
examesIndicados: [
"CD4, carga viral",
"RX tórax",
"LDH (marcador de PCP)",
"Teste de oxigenação com exercício",
"Esputo induzido ou broncoscopia se suspeita de PCP",
],
conduta_esperada: {
imediata: [
"Internação",
"Oxigenioterapia",
"TMP-SMX para PCP",
"TARV iniciador de segunda linha",
],
curto_prazo: [
"Profilaxia de infecções oportunistas",
"Recuperação imunológica",
],
longo_prazo: [
"TARV indefinida",
],
encaminhamentos: ["Infectologia", "Internação"],
},
condutaCorreta: "CD4/CV, RX, TMP-SMX, TARV nova, oxigenioterapia, internação, infectologia",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: ["CD4 <50", "SpO2 <90%", "Pneumocystis"],
descricao: "AIDS com pneumonia oportunista",
recomendacao: "Internação e tratamento agressivo",
},
],
erros_criticos: [
{
erro: "Não reconhecer AIDS",
descricao: "Necessário para diagnóstico e tratamento",
penalidade: 3,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu AIDS",
realizado: false,
critico: true,
},
{
item: "Solicitou CD4 e carga viral",
realizado: false,
critico: true,
},
{
item: "Diagnosticou Pneumocystis",
realizado: false,
critico: true,
},
{
item: "Encaminhou infectologia",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de AIDS",
peso: 30,
descricao: "CD4 <50",
pontuacao_maxima: 30,
},
{
criterio: "Diagnóstico de infecção oportunista",
peso: 25,
descricao: "Pneumocystis",
pontuacao_maxima: 25,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Dispneia",
"HIV sem TARV",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"CD4 28",
"SpO2 88%",
"Crepitações",
"Infiltrados intersticiais",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"AIDS com Pneumocystis",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"TMP-SMX",
"TARV",
"Infectologia",
"Internação",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu AIDS",
"Solicitou CD4",
"Diagnosticou Pneumocystis",
"Encaminhou infectologia",
],
erros_comuns: ["Não pensar em AIDS"],
orientacoes_pedagogicas: [
"AIDS: CD4 <200 = risco de PCP",
"PCP: dispneia + crepitações + infiltrados intersticiais",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer AIDS e infecção oportunista",
comunicacao: ["explicou importância de TARV"],
anamnese: ["investigou status HIV"],
exame_fisico: ["detectou sinais respiratórios"],
exames_complementares: ["pediu CD4"],
raciocinio: ["diagnosticou PCP"],
conduta: ["prescreveu TMP-SMX"],
soap: ["documentou AIDS"],
},
temaOSCE: "Casos Integradores",
subtopicosOSCE: [
"HIV/AIDS",
"CD4 <50",
"Pneumocystis",
"Infecção oportunista",
"Emergência",
],
diagnosticoCorreto: "HIV/AIDS com Pneumonia por Pneumocystis jirovecii",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("57"),
} as CasoOSCEV2;
