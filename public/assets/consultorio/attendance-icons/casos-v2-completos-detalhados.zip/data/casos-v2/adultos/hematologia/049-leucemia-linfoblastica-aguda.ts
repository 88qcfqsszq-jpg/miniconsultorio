import { CasoOSCEV2 } from "@/types/caso-osce-v2";
import { buildFonteExamesLaboratoriais } from "../../shared/laboratorios";

export const caso049LeucemiaLinfoblasticaAguda: CasoOSCEV2 = {
// ====== CASO 49: LEUCEMIA LINFOBLÁSTICA AGUDA ======
id: "49",
titulo: "Leucemia Linfoblástica Aguda",
sistema: "Hematologia",
tema: "Neoplasias hematológicas",
nivel: "avancado",
tipo_estacao: "integrada",
tempo_osce_minutos: 12,
objetivo_pedagogico: "Reconhecer leucemia aguda por apresentação clínica e laboratorial",
dados_visiveis_ao_estudante: {
nome_paciente: "Lucas Souza",
idade: 8,
sexo: "Masculino",
queixa_principal: "Febre, hematomas, sangramento gengival",
historia_breve: "Criança com sintomas agudos há 2 semanas",
},
dados_ocultos_do_sistema: {
diagnostico_principal: "Leucemia Linfoblástica Aguda",
diagnosticos_diferenciais: ["Leucemia mieloblástica", "Mononucleose infecciosa", "Sepse"],
sindromes_associadas: ["Pancitopenia", "Coagulopatia"],
},
descricaoBreve: "Criança com febre, hematomas, sangramento e blastocitose",
categoria: "Neoplasias hematológicas",
paciente: {
id: "pac-049",
nome: "Lucas Souza",
idade: 8,
sexo: "M",
queixaPrincipal: "Febre e sangramento",
historicoDoenca: "Sintomas há 2 semanas",
antecedentes: [],
profissao: "Estudante",
estado_civil: "Solteiro",
alergias: [],
medicamentos_em_uso: [],
},
respostas_do_paciente: {
inicial: "Tô com muita febre, sangra quando escovo e tem roxo no corpo",
febre: "Febre alta, aparece e desaparece",
petequias: "Sim, muchísimas manchinhas roxas",
sangramento: "Sangra muito ao escovar os dentes",
cansaco: "Muito cansado, não quer brincar",
infeccoes: "Teve vários resfriados seguidos",
dor: "Dor nos ossos e articulações",
},
respostaPaciente: {
inicial: "Febre e sangramento",
febre: "Sim",
petequias: "Muitas",
sangramento: "Gengival",
cansaco: "Muito",
infeccoes: "Várias",
dor: "Ossos e articulações",
},
sinais_vitais: {
corretos: {
pressaoArterial: "100/60 mmHg",
frequenciaCardiaca: 120,
frequenciaRespiratoria: 24,
temperatura: 39.2,
saturacaoOxigenio: 96,
},
},
sinaisVitaisCorretos: {
pressaoArterial: "100/60 mmHg",
frequenciaCardiaca: 120,
frequenciaRespiratoria: 24,
temperatura: 39.2,
saturacaoOxigenio: 96,
},
exame_fisico: {
correto: {
inspecao: "Criança febril, pálida, múltiplas petéquias",
palpacao: "Hepatomegalia e esplenomegalia, linfadenopatia cervical",
ausculta: "Taquicardia",
percussao: "Normal",
observacoes: "Sinais de neoplasia hematológica",
regiao: "Geral",
achados_positivos: [
"Febre",
"Petéquias",
"Hepatomegalia",
"Esplenomegalia",
"Linfadenopatia",
],
achados_negativos: [],
},
},
exameFisicoCorreto: {
inspecao: "Pálida, petéquias",
palpacao: "Hepatomegalia, esplenomegalia, linfonodos",
ausculta: "Taquicardia",
percussao: "Normal",
observacoes: "Leucemia",
},
exame_fisico_interativo: {
geral: {
coloracao: "Pálido com petéquias",
consciencia: "Alerta mas aparentando mal",
},
},
exames_complementares_disponiveis: [
{
nome: "Hemograma",
descricao: "Série branca",
resultado: "WBC 85.000/mm³, Blastocitos 90%",
valor_referencia: "WBC <11.000",
interpretacao: "Leucocitose com blastocitose",
},
{
nome: "Plaquetas",
descricao: "Contagem de plaquetas",
resultado: "25.000/mm³",
valor_referencia: ">150.000",
interpretacao: "Trombocitopenia severa",
},
{
nome: "Hemoglobina",
descricao: "Série vermelha",
resultado: "Hb 7.5 g/dL",
valor_referencia: "12-15 g/dL",
interpretacao: "Anemia severa",
},
],
hipoteses_diagnosticas_esperadas: [
{
diagnostico: "Leucemia Linfoblástica Aguda",
probabilidade: 95,
criterios_minimos: [
"Febre",
"Pancitopenia",
"Blastocitose",
"Hepatosplenomegalia",
"Linfadenopatia",
],
},
],
diagnosticos_diferenciais: [
{
diagnostico: "Mononucleose infecciosa",
criterios_exclusao: ["Blastocitos 90%"],
achados_que_descartam: ["Blastocitose severa"],
},
],
examesIndicados: [
"Hemograma completo",
"Biopsia de medula óssea",
"Testes de coagulação",
"Citometria de fluxo",
"Testes genéticos (Philadelphia, translocações)",
],
conduta_esperada: {
imediata: [
"Internação em oncologia pediátrica",
"Biopsia de medula óssea",
"Quimioterapia imediata",
],
curto_prazo: [
"Suporte transfusional",
"Prevenção de tumor lysis syndrome",
],
longo_prazo: [
"Protocolo de quimioterapia",
],
encaminhamentos: ["Oncologia pediátrica", "Internação imediata"],
},
condutaCorreta: "Hemograma urgente, biopsia medula, coagulação, internação oncologia pediátrica",
criterios_de_gravidade: [
{
severidade: "grave",
sinais: [
"Blastocitose >50%",
"Pancitopenia",
"Febre",
"Coagulopatia",
],
descricao: "Leucemia aguda com risco de morte",
recomendacao: "Quimioterapia imediata",
},
],
erros_criticos: [
{
erro: "Não reconhecer urgência",
descricao: "Prognóstico depende de início rápido",
penalidade: 3,
evitavel: true,
},
],
checklist_osce: [
{
item: "Reconheceu leucemia",
realizado: false,
critico: true,
},
{
item: "Solicitou hemograma urgente",
realizado: false,
critico: true,
},
{
item: "Encaminhou oncologia pediátrica",
realizado: false,
critico: true,
},
],
rubrica_correcao: [
{
criterio: "Reconhecimento de leucemia",
peso: 35,
descricao: "Achados clínicos e blastocitose",
pontuacao_maxima: 35,
},
{
criterio: "Urgência",
peso: 30,
descricao: "Encaminhamento imediato",
pontuacao_maxima: 30,
},
],
modelo_soap: {
subjetivo: {
secao: "S",
componentes_obrigatorios: [
"Febre",
"Sangramento",
"Cansaço",
],
},
objetivo: {
secao: "O",
componentes_obrigatorios: [
"Petéquias",
"Hepatosplenomegalia",
"WBC 85.000",
"Blastocitos 90%",
"Plaquetas baixas",
],
},
avaliacao: {
secao: "A",
componentes_obrigatorios: [
"Leucemia linfoblástica aguda",
],
},
plano: {
secao: "P",
componentes_obrigatorios: [
"Internação imediata",
"Biopsia medula",
"Quimioterapia",
"Oncologia pediátrica",
],
},
},
feedback_modelo: {
acertos_esperados: [
"Reconheceu leucemia",
"Solicitou hemograma urgente",
"Encaminhou oncologia",
],
erros_comuns: ["Achar que é infecção"],
orientacoes_pedagogicas: [
"Leucemia: febre + petéquias + blastocitose",
"Urgência máxima em pediatria",
],
},
checklist_oculto_examinador: {
oQueProfessorQuer: "Reconhecer leucemia como emergência pediátrica máxima",
comunicacao: ["explicou urgência aos pais"],
anamnese: ["investigou sintomas sistêmicos"],
exame_fisico: ["detectou organomegalias"],
exames_complementares: ["pediu hemograma"],
raciocinio: ["diagnosticou leucemia"],
conduta: ["encaminhou oncologia"],
soap: ["documentou emergência"],
},
temaOSCE: "Neoplasias hematológicas",
subtopicosOSCE: [
"Leucemia linfoblástica aguda",
"Blastocitose",
"Pancitopenia",
"Hepatosplenomegalia",
"Emergência pediátrica",
],
diagnosticoCorreto: "Leucemia Linfoblástica Aguda",
ativo: false,,

  fonte_exames_laboratoriais: buildFonteExamesLaboratoriais("49"),
} as CasoOSCEV2;
